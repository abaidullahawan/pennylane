-- MySQL dump 10.13  Distrib 5.7.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: alarsh_production
-- ------------------------------------------------------
-- Server version	5.7.37-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iban_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(15,5) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_accounts_on_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,'Company Cash','','',0.00000,'2021-08-31 14:04:23','2021-09-21 21:25:53',NULL,NULL),(2,'Adeel Card','American Express','',-2843.00000,'2021-09-14 22:45:51','2021-09-29 19:31:24',NULL,194),(3,'Kuldip Singh','American Express','',0.00000,'2021-09-14 22:46:14','2021-09-14 22:46:14',NULL,NULL),(4,'Abdul Card','American Express','',-10.00000,'2021-09-14 22:46:34','2021-09-14 23:36:42',NULL,194),(5,'Mohammed Card','American Express','',0.00000,'2021-09-21 21:15:22','2021-09-21 21:15:22',NULL,NULL);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;

--
-- Table structure for table `active_storage_attachments`
--

DROP TABLE IF EXISTS `active_storage_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `active_storage_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `record_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `record_id` int(11) NOT NULL,
  `blob_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_active_storage_attachments_uniqueness` (`record_type`,`record_id`,`name`,`blob_id`),
  KEY `index_active_storage_attachments_on_blob_id` (`blob_id`),
  CONSTRAINT `fk_rails_c3b3935057` FOREIGN KEY (`blob_id`) REFERENCES `active_storage_blobs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `active_storage_attachments`
--

/*!40000 ALTER TABLE `active_storage_attachments` DISABLE KEYS */;
INSERT INTO `active_storage_attachments` VALUES (1,'logo_images','PosSetting',1,1,'2021-09-06 21:43:46');
/*!40000 ALTER TABLE `active_storage_attachments` ENABLE KEYS */;

--
-- Table structure for table `active_storage_blobs`
--

DROP TABLE IF EXISTS `active_storage_blobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `active_storage_blobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` text COLLATE utf8mb4_unicode_ci,
  `byte_size` bigint(20) NOT NULL,
  `checksum` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `service_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_active_storage_blobs_on_key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `active_storage_blobs`
--

/*!40000 ALTER TABLE `active_storage_blobs` DISABLE KEYS */;
INSERT INTO `active_storage_blobs` VALUES (1,'W8pMLvXpRZgSmcLqHGGHY2qX','WhatsApp Image 2021-09-06 at 12.43.01 PM.jpeg','image/jpeg','{\"identified\":true}',15205,'PWamx2IQgiW/Kal1P+8dDA==','2021-09-06 21:43:46','amazon');
/*!40000 ALTER TABLE `active_storage_blobs` ENABLE KEYS */;

--
-- Table structure for table `active_storage_variant_records`
--

DROP TABLE IF EXISTS `active_storage_variant_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `active_storage_variant_records` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blob_id` bigint(20) NOT NULL,
  `variation_digest` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_active_storage_variant_records_uniqueness` (`blob_id`,`variation_digest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `active_storage_variant_records`
--

/*!40000 ALTER TABLE `active_storage_variant_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `active_storage_variant_records` ENABLE KEYS */;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activities` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `trackable_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trackable_id` bigint(20) DEFAULT NULL,
  `owner_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner_id` bigint(20) DEFAULT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameters` text COLLATE utf8mb4_unicode_ci,
  `recipient_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recipient_id` bigint(20) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_activities_on_trackable_type_and_trackable_id` (`trackable_type`,`trackable_id`),
  KEY `index_activities_on_owner_type_and_owner_id` (`owner_type`,`owner_id`),
  KEY `index_activities_on_recipient_type_and_recipient_id` (`recipient_type`,`recipient_id`),
  KEY `index_activities_on_trackable_id_and_trackable_type` (`trackable_id`,`trackable_type`),
  KEY `index_activities_on_owner_id_and_owner_type` (`owner_id`,`owner_type`),
  KEY `index_activities_on_recipient_id_and_recipient_type` (`recipient_id`,`recipient_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;

--
-- Table structure for table `ar_internal_metadata`
--

DROP TABLE IF EXISTS `ar_internal_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ar_internal_metadata` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ar_internal_metadata`
--

/*!40000 ALTER TABLE `ar_internal_metadata` DISABLE KEYS */;
INSERT INTO `ar_internal_metadata` VALUES ('environment','production','2021-08-31 19:00:37','2021-08-31 19:00:37');
/*!40000 ALTER TABLE `ar_internal_metadata` ENABLE KEYS */;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES (1,'New York','','2021-08-31 14:04:22','2021-08-31 23:47:30');
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;

--
-- Table structure for table `compaign_entries`
--

DROP TABLE IF EXISTS `compaign_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compaign_entries` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `compaign_id` bigint(20) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_compaign_entries_on_compaign_id` (`compaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compaign_entries`
--

/*!40000 ALTER TABLE `compaign_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `compaign_entries` ENABLE KEYS */;

--
-- Table structure for table `compaigns`
--

DROP TABLE IF EXISTS `compaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compaigns` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compaigns`
--

/*!40000 ALTER TABLE `compaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `compaigns` ENABLE KEYS */;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `office` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `sys_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_contacts_on_country_id` (`country_id`),
  KEY `index_contacts_on_city_id` (`city_id`),
  KEY `index_contacts_on_sys_user_id` (`sys_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES (1,'1124 31st Ave #15D LIC NY 11106 ','','Euro TI Inc. ','917-578-4400','','gianniredzic@gmail.com','',0,1,1,1,'2021-09-01 00:18:28','2021-09-01 00:18:28'),(2,'524 North Avenue, New Rochelle, NY 10801','','Pelican Management, Inc.','914-424-3599','','bgoldfarb@goldprop.com ','',0,1,1,2,'2021-09-01 00:23:54','2021-09-01 00:23:54'),(3,'386 14th Street, Brooklyn, NY 11215','','NYC Rock Inc. General Contracting','212-213-9090 / 718-788-1030','718-232-0333','nycrockinc@aol.com','',0,1,1,3,'2021-09-01 00:26:36','2021-09-01 00:26:36'),(4,'115 SOUTH 5TH AVE\r\nMOUNT VERNON, NY 10550		\r\n','',' SACRED HEART CHURCH','929-260-8766   ','','claudius.compton@use.salvationarmy.org  ','',0,1,1,4,'2021-09-01 00:29:30','2021-09-01 00:29:30'),(5,'346 PARK AVENUE SOUTH 3RD FL\r\nNEW YORK, NY 10010	\r\n','',' TRI-HILL MANAGEMENT LLC ','(646) 396-5752  / 516-313-7627','','doron@trihill.com 	','',0,1,1,5,'2021-09-01 00:31:03','2021-09-01 00:31:03');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'United States Of America','','2021-08-31 14:04:22','2021-08-31 23:47:05');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;

--
-- Table structure for table `crontests`
--

DROP TABLE IF EXISTS `crontests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crontests` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crontests`
--

/*!40000 ALTER TABLE `crontests` DISABLE KEYS */;
/*!40000 ALTER TABLE `crontests` ENABLE KEYS */;

--
-- Table structure for table `daily_books`
--

DROP TABLE IF EXISTS `daily_books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_books` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `book_date` datetime DEFAULT NULL,
  `total_paid` float DEFAULT NULL,
  `total_remaining` float DEFAULT NULL,
  `department_id` bigint(20) DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `wage_rate` float DEFAULT '0',
  `quantity` float DEFAULT '0',
  `amount` float DEFAULT '0',
  `status` int(11) DEFAULT NULL,
  `extra` int(11) DEFAULT '0',
  `coverge_rate` float DEFAULT '0',
  `wage_debit` float DEFAULT '0',
  `brick_rohra` int(11) DEFAULT '0',
  `tile_rohra` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_daily_books_on_department_id` (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_books`
--

/*!40000 ALTER TABLE `daily_books` DISABLE KEYS */;
/*!40000 ALTER TABLE `daily_books` ENABLE KEYS */;

--
-- Table structure for table `daily_sales`
--

DROP TABLE IF EXISTS `daily_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale` decimal(10,0) DEFAULT NULL,
  `cash_out` decimal(10,0) DEFAULT NULL,
  `shift` int(11) DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_sales`
--

/*!40000 ALTER TABLE `daily_sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `daily_sales` ENABLE KEYS */;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;

--
-- Table structure for table `expense_entries`
--

DROP TABLE IF EXISTS `expense_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` float DEFAULT NULL,
  `expense_id` int(11) DEFAULT NULL,
  `expense_type_id` int(11) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `expenseable_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expenseable_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_expense_entries_on_expense_id` (`expense_id`),
  KEY `index_expense_entries_on_expense_type_id` (`expense_type_id`),
  KEY `index_expense_entries_on_account_id` (`account_id`),
  KEY `index_expense_entries_on_expenseable_type_and_expenseable_id` (`expenseable_type`,`expenseable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense_entries`
--

/*!40000 ALTER TABLE `expense_entries` DISABLE KEYS */;
INSERT INTO `expense_entries` VALUES (1,86.32,1,3,1,'',NULL,'2021-09-01 00:00:00','2021-09-07 21:37:01',NULL,NULL),(2,290,2,6,1,'Garbage from morris site',NULL,'2021-09-01 00:00:00','2021-09-07 21:38:46',NULL,NULL),(3,17.16,3,2,1,'Aurora Deli',NULL,'2021-09-01 00:00:00','2021-09-07 21:39:40',NULL,NULL),(4,209.26,4,7,1,'united building supply',NULL,'2021-09-03 00:00:00','2021-09-07 21:43:33',NULL,NULL),(5,16,5,2,1,'',NULL,'2021-09-03 00:00:00','2021-09-07 21:45:05',NULL,NULL),(6,2.99,6,7,1,'Five boro building supply',NULL,'2021-09-02 00:00:00','2021-09-07 21:46:21',NULL,NULL),(7,189.44,7,7,1,'Five boro building supply',NULL,'2021-09-02 00:00:00','2021-09-07 21:47:11',NULL,NULL),(8,26.91,8,2,1,'1115 Astor Ave',NULL,'2021-09-03 00:00:00','2021-09-07 21:48:13',NULL,NULL),(9,74.84,9,7,1,'Metro Building ',NULL,'2021-09-02 00:00:00','2021-09-07 21:49:10',NULL,NULL),(10,21.22,10,2,1,'Gourmet Delight ',NULL,'2021-09-04 00:00:00','2021-09-07 21:50:33',NULL,NULL),(11,909.81,11,7,1,'Home Depot',NULL,'2021-09-04 00:00:00','2021-09-07 21:51:33',NULL,NULL),(12,27.16,12,7,1,'United Building Supply',NULL,'2021-09-06 00:00:00','2021-09-07 21:55:22',NULL,NULL),(13,631.39,13,7,1,'united Building material',NULL,'2021-09-06 00:00:00','2021-09-07 21:56:13',NULL,NULL),(14,21.32,14,2,1,'',NULL,'2021-09-06 00:00:00','2021-09-07 21:57:42',NULL,NULL),(15,19.76,15,2,1,'',NULL,'2021-09-06 00:00:00','2021-09-07 21:58:27',NULL,NULL),(16,72,16,7,1,'',NULL,'2021-09-07 21:59:27','2021-09-07 21:59:27',NULL,NULL),(17,14.56,17,2,1,'',NULL,'2021-09-07 22:00:02','2021-09-07 22:00:02',NULL,NULL),(18,13.52,18,2,1,'',NULL,'2021-09-07 22:00:31','2021-09-07 22:00:31',NULL,NULL),(19,600.09,19,7,2,'CASA Building Materials',NULL,'2021-09-08 00:00:00','2021-09-14 22:47:14',NULL,NULL),(20,73.97,20,7,2,'CASA BUILDING MATERIALS',NULL,'2021-09-08 00:00:00','2021-09-14 22:48:16',NULL,NULL),(21,10.92,21,2,2,'SAMI MINI MART',NULL,'2021-09-08 00:00:00','2021-09-14 22:48:59',NULL,NULL),(22,9,22,2,2,'FELOMAR GROCERY',NULL,'2021-09-09 00:00:00','2021-09-14 22:51:07',NULL,NULL),(23,22.88,23,2,2,'MINI MART',NULL,'2021-09-10 00:00:00','2021-09-14 22:52:19',NULL,NULL),(24,8.14,24,2,2,'',NULL,'2021-09-14 22:53:10','2021-09-14 22:53:10',NULL,NULL),(25,81.35,25,3,2,'1346 beach channel',NULL,'2021-09-13 00:00:00','2021-09-14 22:58:53',NULL,NULL),(26,31.16,26,7,2,'METRO BUILDING SUPPLY',NULL,'2021-09-13 00:00:00','2021-09-14 23:00:05',NULL,NULL),(27,16.64,27,2,2,'seagirt deli and grill',NULL,'2021-09-14 23:35:21','2021-09-14 23:35:21',NULL,NULL),(28,10.92,28,2,4,'Milano Italian',NULL,'2021-09-14 23:36:42','2021-09-14 23:36:42',NULL,NULL),(29,696.9,29,7,2,'Brooklyn 836 Washington ave ',NULL,'2021-09-15 21:30:47','2021-09-20 20:29:17',NULL,NULL),(30,424.61,30,7,2,'NEW CASTLE BUILDING PRODUCTS',NULL,'2021-09-20 20:26:00','2021-09-20 20:26:00',NULL,NULL),(31,585.71,31,7,2,'HOME DEPOT',NULL,'2021-09-20 21:08:22','2021-09-20 21:08:22',NULL,NULL),(32,950.96,32,7,5,'GLENWOOD MASON SUPPLY',NULL,'2021-09-21 21:06:51','2021-09-29 19:10:20',NULL,NULL),(33,96.76,33,7,2,'MAterials',NULL,'2021-09-27 21:06:37','2021-09-29 19:09:54',NULL,NULL),(34,20.8,34,2,2,'Breakfast ',NULL,'2021-09-27 21:07:42','2021-09-29 19:09:31',NULL,NULL),(35,21.4,35,7,2,'Home Depot',NULL,'2021-09-25 00:00:00','2021-09-29 19:08:49',NULL,NULL),(36,18.72,36,2,2,'Lunch ',NULL,'2021-09-27 23:20:36','2021-09-27 23:20:36',NULL,NULL),(37,15.34,37,2,2,'lunch',NULL,'2021-09-22 00:00:00','2021-09-29 19:28:24',NULL,NULL),(38,20.22,38,2,2,'Lunch',NULL,'2021-09-22 00:00:00','2021-09-29 19:29:28',NULL,NULL),(39,82,39,3,2,'Gas',NULL,'2021-09-25 00:00:00','2021-09-29 19:30:43',NULL,NULL),(40,16.38,40,2,2,'Breakfast',NULL,'2021-09-25 00:00:00','2021-09-29 19:31:24',NULL,NULL);
/*!40000 ALTER TABLE `expense_entries` ENABLE KEYS */;

--
-- Table structure for table `expense_types`
--

DROP TABLE IF EXISTS `expense_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense_types`
--

/*!40000 ALTER TABLE `expense_types` DISABLE KEYS */;
INSERT INTO `expense_types` VALUES (1,'Stationary','','2021-08-31 14:04:22','2021-09-01 23:24:54'),(2,'Food','','2021-09-01 23:25:23','2021-09-01 23:25:23'),(3,'Gas','','2021-09-01 23:25:31','2021-09-01 23:25:31'),(4,'Insurance','','2021-09-01 23:25:40','2021-09-01 23:25:40'),(5,'License','','2021-09-02 22:22:53','2021-09-02 22:22:53'),(6,'AJ Recycle ( Garbage)','','2021-09-07 21:38:05','2021-09-07 21:41:45'),(7,'Materials','','2021-09-07 21:40:55','2021-09-07 21:40:55');
/*!40000 ALTER TABLE `expense_types` ENABLE KEYS */;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense` float DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `expense_type_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_expenses_on_expense_type_id` (`expense_type_id`),
  KEY `index_expenses_on_account_id` (`account_id`),
  CONSTRAINT `fk_rails_244a1b7a3e` FOREIGN KEY (`expense_type_id`) REFERENCES `expense_types` (`id`),
  CONSTRAINT `fk_rails_d88dc500b6` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES (1,86.32,'',NULL,'2021-09-01 00:00:00','2021-09-07 21:37:01',NULL),(2,290,'',NULL,'2021-09-01 00:00:00','2021-09-07 21:40:19',NULL),(3,17.16,'',NULL,'2021-09-01 00:00:00','2021-09-07 21:40:14',NULL),(4,209.26,'',NULL,'2021-09-03 00:00:00','2021-09-07 21:44:22',NULL),(5,16,'',NULL,'2021-09-03 00:00:00','2021-09-07 21:45:23',NULL),(6,2.99,'',NULL,'2021-09-02 00:00:00','2021-09-07 21:46:21',NULL),(7,189.44,'',NULL,'2021-09-02 00:00:00','2021-09-07 21:47:11',NULL),(8,26.91,'',NULL,'2021-09-03 00:00:00','2021-09-07 21:48:13',NULL),(9,74.84,'',NULL,'2021-09-02 00:00:00','2021-09-07 21:49:10',NULL),(10,21.22,'',NULL,'2021-09-04 00:00:00','2021-09-07 21:50:33',NULL),(11,909.81,'',NULL,'2021-09-04 00:00:00','2021-09-07 21:51:33',NULL),(12,27.16,'',NULL,'2021-09-06 00:00:00','2021-09-07 21:54:42',NULL),(13,631.39,'Far Rockaway',NULL,'2021-09-06 00:00:00','2021-09-07 21:56:44',NULL),(14,21.32,'seagirt deli',NULL,'2021-09-06 00:00:00','2021-09-07 21:57:42',NULL),(15,19.76,'Seagirt Deli',NULL,'2021-09-06 00:00:00','2021-09-07 21:58:27',NULL),(16,72,'unlead cr #02',NULL,'2021-09-07 00:00:00','2021-09-07 21:59:27',NULL),(17,14.56,'Sami Mini Mart ',NULL,'2021-09-07 00:00:00','2021-09-07 22:00:02',NULL),(18,13.52,'Aurora Deli',NULL,'2021-09-07 00:00:00','2021-09-07 22:00:31',NULL),(19,600.09,'',NULL,'2021-09-08 00:00:00','2021-09-14 22:47:34',NULL),(20,73.97,'',NULL,'2021-09-08 00:00:00','2021-09-14 22:48:25',NULL),(21,10.92,'',NULL,'2021-09-08 00:00:00','2021-09-14 22:48:59',NULL),(22,9,'',NULL,'2021-09-09 00:00:00','2021-09-14 22:51:07',NULL),(23,22.88,'',NULL,'2021-09-10 00:00:00','2021-09-14 22:52:19',NULL),(24,8.14,'',NULL,'2021-09-14 00:00:00','2021-09-14 22:53:10',NULL),(25,81.35,'',NULL,'2021-09-13 00:00:00','2021-09-14 22:58:53',NULL),(26,31.16,'',NULL,'2021-09-13 00:00:00','2021-09-14 23:00:05',NULL),(27,16.64,'',NULL,'2021-09-14 00:00:00','2021-09-14 23:35:21',NULL),(28,10.92,'',NULL,'2021-09-14 00:00:00','2021-09-14 23:36:42',NULL),(29,696.9,'New Castle building material',NULL,'2021-09-15 00:00:00','2021-09-20 20:29:17',NULL),(30,424.61,'BROOKLYN JOBSITE',NULL,'2021-09-20 00:00:00','2021-09-20 20:26:00',NULL),(31,585.71,'BROOKLYN JOB',NULL,'2021-09-20 00:00:00','2021-09-20 21:08:22',NULL),(32,950.96,'1135 PHELAM PARKWAY',NULL,'2021-09-21 00:00:00','2021-09-29 19:10:20',NULL),(33,96.76,'Far Rockaway',NULL,'2021-09-27 00:00:00','2021-09-29 19:09:54',NULL),(34,20.8,'Far Rockaway',NULL,'2021-09-27 00:00:00','2021-09-29 19:09:31',NULL),(35,21.4,'Brooklyn',NULL,'2021-09-25 00:00:00','2021-09-29 19:08:49',NULL),(36,18.72,'Far Rockaway ',NULL,'2021-09-27 00:00:00','2021-09-27 23:20:36',NULL),(37,15.34,'Far Rockaway',NULL,'2021-09-22 00:00:00','2021-09-29 19:28:24',NULL),(38,20.22,'Brooklyn',NULL,'2021-09-22 00:00:00','2021-09-29 19:29:28',NULL),(39,82,'Adeel',NULL,'2021-09-25 00:00:00','2021-09-29 19:30:43',NULL),(40,16.38,'Brooklyn',NULL,'2021-09-25 00:00:00','2021-09-29 19:31:24',NULL);
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;

--
-- Table structure for table `gates`
--

DROP TABLE IF EXISTS `gates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gates` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pather_from` datetime DEFAULT NULL,
  `pather_to` datetime DEFAULT NULL,
  `kharkar_from` datetime DEFAULT NULL,
  `kharkar_to` datetime DEFAULT NULL,
  `bhari_from` datetime DEFAULT NULL,
  `bhari_to` datetime DEFAULT NULL,
  `jalai_from` datetime DEFAULT NULL,
  `jalai_to` datetime DEFAULT NULL,
  `nakasi_from` datetime DEFAULT NULL,
  `nakasi_to` datetime DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `pather_cost` decimal(10,0) DEFAULT NULL,
  `kharkar_cost` decimal(10,0) DEFAULT NULL,
  `jalai_cost` decimal(10,0) DEFAULT NULL,
  `nakasi_cost` decimal(10,0) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `purchase_from` datetime DEFAULT NULL,
  `purchase_to` datetime DEFAULT NULL,
  `sale_from` datetime DEFAULT NULL,
  `sale_to` datetime DEFAULT NULL,
  `expense_from` datetime DEFAULT NULL,
  `expense_to` datetime DEFAULT NULL,
  `salary_from` datetime DEFAULT NULL,
  `salary_to` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gates`
--

/*!40000 ALTER TABLE `gates` DISABLE KEYS */;
/*!40000 ALTER TABLE `gates` ENABLE KEYS */;

--
-- Table structure for table `investments`
--

DROP TABLE IF EXISTS `investments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `investments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invest` int(11) DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_investments_on_account_id` (`account_id`),
  CONSTRAINT `fk_rails_94ac439de9` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `investments`
--

/*!40000 ALTER TABLE `investments` DISABLE KEYS */;
/*!40000 ALTER TABLE `investments` ENABLE KEYS */;

--
-- Table structure for table `item_types`
--

DROP TABLE IF EXISTS `item_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_types`
--

/*!40000 ALTER TABLE `item_types` DISABLE KEYS */;
INSERT INTO `item_types` VALUES (1,'Construction','default','','2021-08-31 14:04:22','2021-08-31 23:39:09');
/*!40000 ALTER TABLE `item_types` ENABLE KEYS */;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_type_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `minimum` int(11) DEFAULT NULL,
  `optimal` int(11) DEFAULT NULL,
  `maximun` int(11) DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `purchase_type` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `quantity_type` int(11) DEFAULT NULL,
  `weight_type` int(11) DEFAULT NULL,
  `stock` float DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `sale` float DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `measurement_quantity` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_items_on_item_type_id` (`item_type_id`),
  CONSTRAINT `fk_rails_6bed0f90a5` FOREIGN KEY (`item_type_id`) REFERENCES `item_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

/*!40000 ALTER TABLE `items` DISABLE KEYS */;
/*!40000 ALTER TABLE `items` ENABLE KEYS */;

--
-- Table structure for table `ledger_books`
--

DROP TABLE IF EXISTS `ledger_books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ledger_books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sys_user_id` int(11) DEFAULT NULL,
  `debit` decimal(15,5) DEFAULT NULL,
  `credit` decimal(15,5) DEFAULT NULL,
  `balance` decimal(15,5) DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `purchase_sale_detail_id` int(11) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_ledger_books_on_sys_user_id` (`sys_user_id`),
  KEY `index_ledger_books_on_purchase_sale_detail_id` (`purchase_sale_detail_id`),
  KEY `index_ledger_books_on_account_id` (`account_id`),
  KEY `index_ledger_books_on_order_id` (`order_id`),
  CONSTRAINT `fk_rails_f442a8a0da` FOREIGN KEY (`sys_user_id`) REFERENCES `sys_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ledger_books`
--

/*!40000 ALTER TABLE `ledger_books` DISABLE KEYS */;
/*!40000 ALTER TABLE `ledger_books` ENABLE KEYS */;

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `links` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `linkable_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkable_id` bigint(20) DEFAULT NULL,
  `qrcode` text COLLATE utf8mb4_unicode_ci,
  `brcode` text COLLATE utf8mb4_unicode_ci,
  `href` text COLLATE utf8mb4_unicode_ci,
  `title` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_links_on_linkable_type_and_linkable_id` (`linkable_type`,`linkable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `links`
--

/*!40000 ALTER TABLE `links` DISABLE KEYS */;
/*!40000 ALTER TABLE `links` ENABLE KEYS */;

--
-- Table structure for table `materials`
--

DROP TABLE IF EXISTS `materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `production_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `cost_price` float DEFAULT NULL,
  `sale_price` float DEFAULT NULL,
  `total_cost_price` float DEFAULT NULL,
  `total_sale_price` float DEFAULT NULL,
  `quantity` float DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_materials_on_production_id` (`production_id`),
  KEY `index_materials_on_item_id` (`item_id`),
  KEY `index_materials_on_product_id` (`product_id`),
  CONSTRAINT `fk_rails_01d0afd526` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `fk_rails_47683ae25b` FOREIGN KEY (`production_id`) REFERENCES `productions` (`id`),
  CONSTRAINT `fk_rails_924eff50da` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materials`
--

/*!40000 ALTER TABLE `materials` DISABLE KEYS */;
/*!40000 ALTER TABLE `materials` ENABLE KEYS */;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `item_id` bigint(20) DEFAULT NULL,
  `quantity` float DEFAULT NULL,
  `cost_price` float DEFAULT NULL,
  `sale_price` float DEFAULT NULL,
  `total_cost_price` float DEFAULT NULL,
  `total_sale_price` float DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_type` int(11) DEFAULT NULL,
  `discount_price` float DEFAULT NULL,
  `purchase_sale_type` int(11) DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `marla` float DEFAULT NULL,
  `square_feet` float DEFAULT NULL,
  `gst` decimal(15,2) DEFAULT NULL,
  `gst_amount` decimal(15,2) DEFAULT NULL,
  `extra_expence` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_order_items_on_order_id` (`order_id`),
  KEY `index_order_items_on_product_id` (`product_id`),
  KEY `index_order_items_on_item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sys_user_id` bigint(20) DEFAULT NULL,
  `transaction_type` int(11) DEFAULT NULL,
  `total_bill` float DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `discount_price` float DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `voucher_id` int(11) DEFAULT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `carriage` float DEFAULT NULL,
  `loading` float DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `with_gst` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_orders_on_sys_user_id` (`sys_user_id`),
  KEY `index_orders_on_account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `debit` decimal(15,5) DEFAULT NULL,
  `credit` decimal(15,5) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `paymentable_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentable_id` int(11) DEFAULT NULL,
  `amount` decimal(15,5) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `confirmable` int(11) DEFAULT NULL,
  `confirmed_by` int(11) DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_payments_on_account_id` (`account_id`),
  KEY `index_payments_on_paymentable_type_and_paymentable_id` (`paymentable_type`,`paymentable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,NULL,0.00000,1,NULL,NULL,0.00000,NULL,'Opening Balance','2021-08-31 14:04:23','2021-08-31 14:04:23',NULL,NULL,NULL),(2,0.00000,0.00000,1,'Salary',1,0.00000,NULL,'Destory Salary/Advance','2021-09-06 21:53:00','2021-09-06 22:01:54',NULL,NULL,NULL),(3,86.00000,NULL,1,'ExpenseEntry',1,-86.00000,NULL,'Expense','2021-09-07 21:37:01','2021-09-07 21:37:01',NULL,NULL,NULL),(4,290.00000,NULL,1,'ExpenseEntry',2,-376.00000,NULL,'Expense','2021-09-07 21:38:46','2021-09-07 21:38:46',NULL,NULL,NULL),(5,17.00000,NULL,1,'ExpenseEntry',3,-393.00000,NULL,'Expense','2021-09-07 21:39:40','2021-09-07 21:39:40',NULL,NULL,NULL),(6,209.00000,NULL,1,'ExpenseEntry',4,-602.00000,NULL,'Expense','2021-09-07 21:43:33','2021-09-07 21:43:33',NULL,NULL,NULL),(7,16.00000,NULL,1,'ExpenseEntry',5,-618.00000,NULL,'Expense','2021-09-07 21:45:05','2021-09-07 21:45:05',NULL,NULL,NULL),(8,2.00000,NULL,1,'ExpenseEntry',6,-620.00000,NULL,'Expense','2021-09-07 21:46:21','2021-09-07 21:46:21',NULL,NULL,NULL),(9,189.00000,NULL,1,'ExpenseEntry',7,-809.00000,NULL,'Expense','2021-09-07 21:47:11','2021-09-07 21:47:11',NULL,NULL,NULL),(10,26.00000,NULL,1,'ExpenseEntry',8,-835.00000,NULL,'Expense','2021-09-07 21:48:13','2021-09-07 21:48:13',NULL,NULL,NULL),(11,74.00000,NULL,1,'ExpenseEntry',9,-909.00000,NULL,'Expense','2021-09-07 21:49:10','2021-09-07 21:49:10',NULL,NULL,NULL),(12,21.00000,NULL,1,'ExpenseEntry',10,-930.00000,NULL,'Expense','2021-09-07 21:50:33','2021-09-07 21:50:33',NULL,NULL,NULL),(13,909.00000,NULL,1,'ExpenseEntry',11,-1839.00000,NULL,'Expense','2021-09-07 21:51:33','2021-09-07 21:51:33',NULL,NULL,NULL),(14,27.00000,NULL,1,'ExpenseEntry',12,-1866.00000,NULL,'Edited Expense','2021-09-07 21:54:42','2021-09-07 21:54:42',NULL,NULL,NULL),(15,631.00000,NULL,1,'ExpenseEntry',13,-2497.00000,NULL,'Expense','2021-09-07 21:56:13','2021-09-07 21:56:13',NULL,NULL,NULL),(16,21.00000,NULL,1,'ExpenseEntry',14,-2518.00000,NULL,'Expense','2021-09-07 21:57:42','2021-09-07 21:57:42',NULL,NULL,NULL),(17,19.00000,NULL,1,'ExpenseEntry',15,-2537.00000,NULL,'Expense','2021-09-07 21:58:27','2021-09-07 21:58:27',NULL,NULL,NULL),(18,72.00000,NULL,1,'ExpenseEntry',16,-2609.00000,NULL,'Expense','2021-09-07 21:59:27','2021-09-07 21:59:27',NULL,NULL,NULL),(19,14.00000,NULL,1,'ExpenseEntry',17,-2623.00000,NULL,'Expense','2021-09-07 22:00:02','2021-09-07 22:00:02',NULL,NULL,NULL),(20,13.00000,NULL,1,'ExpenseEntry',18,-2636.00000,NULL,'Expense','2021-09-07 22:00:31','2021-09-07 22:00:31',NULL,NULL,NULL),(21,NULL,0.00000,2,NULL,NULL,0.00000,NULL,'Opening Balance','2021-09-14 22:45:51','2021-09-14 22:45:51',NULL,NULL,NULL),(22,NULL,0.00000,3,NULL,NULL,0.00000,NULL,'Opening Balance','2021-09-14 22:46:14','2021-09-14 22:46:14',NULL,NULL,NULL),(23,NULL,0.00000,4,NULL,NULL,0.00000,NULL,'Opening Balance','2021-09-14 22:46:34','2021-09-14 22:46:34',NULL,NULL,NULL),(24,600.00000,NULL,2,'ExpenseEntry',19,-600.00000,NULL,'Expense','2021-09-14 22:47:14','2021-09-14 22:47:14',NULL,NULL,NULL),(25,73.00000,NULL,2,'ExpenseEntry',20,-673.00000,NULL,'Expense','2021-09-14 22:48:16','2021-09-14 22:48:16',NULL,NULL,NULL),(26,10.00000,NULL,2,'ExpenseEntry',21,-683.00000,NULL,'Expense','2021-09-14 22:48:59','2021-09-14 22:48:59',NULL,NULL,NULL),(27,9.00000,NULL,2,'ExpenseEntry',22,-692.00000,NULL,'Expense','2021-09-14 22:51:07','2021-09-14 22:51:07',NULL,NULL,NULL),(28,22.00000,NULL,2,'ExpenseEntry',23,-714.00000,NULL,'Expense','2021-09-14 22:52:19','2021-09-14 22:52:19',NULL,NULL,NULL),(29,8.00000,NULL,2,'ExpenseEntry',24,-722.00000,NULL,'Expense','2021-09-14 22:53:10','2021-09-14 22:53:10',NULL,NULL,NULL),(30,81.00000,NULL,2,'ExpenseEntry',25,-803.00000,NULL,'Expense','2021-09-14 22:58:53','2021-09-14 22:58:53',NULL,NULL,NULL),(31,31.00000,NULL,2,'ExpenseEntry',26,-834.00000,NULL,'Expense','2021-09-14 23:00:05','2021-09-14 23:00:05',NULL,NULL,NULL),(32,16.00000,NULL,2,'ExpenseEntry',27,-850.00000,NULL,'Expense','2021-09-14 23:35:21','2021-09-14 23:35:21',NULL,NULL,NULL),(33,10.00000,NULL,4,'ExpenseEntry',28,-10.00000,NULL,'Expense','2021-09-14 23:36:42','2021-09-14 23:36:42',NULL,NULL,NULL),(34,696.00000,NULL,2,'ExpenseEntry',29,-1546.00000,NULL,'Edited Expense','2021-09-15 21:30:47','2021-09-15 21:30:47',NULL,NULL,NULL),(35,424.00000,NULL,2,'ExpenseEntry',30,-1970.00000,NULL,'Expense','2021-09-20 20:26:00','2021-09-20 20:26:00',NULL,NULL,NULL),(36,585.00000,NULL,2,'ExpenseEntry',31,-2555.00000,NULL,'Expense','2021-09-20 21:08:22','2021-09-20 21:08:22',NULL,NULL,NULL),(37,950.00000,NULL,1,'ExpenseEntry',32,-3586.00000,NULL,'Edited Expense','2021-09-21 21:06:51','2021-09-21 21:06:51',NULL,NULL,NULL),(38,NULL,0.00000,5,NULL,NULL,0.00000,NULL,'Opening Balance','2021-09-21 21:15:22','2021-09-21 21:15:22',NULL,NULL,NULL),(39,96.00000,NULL,2,'ExpenseEntry',33,-2651.00000,NULL,'Edited Expense','2021-09-27 21:06:37','2021-09-27 21:06:37',NULL,NULL,NULL),(40,20.00000,NULL,2,'ExpenseEntry',34,-2671.00000,NULL,'Edited Expense','2021-09-27 21:07:42','2021-09-27 21:07:42',NULL,NULL,NULL),(41,21.00000,NULL,2,'ExpenseEntry',35,-2692.00000,NULL,'Edited Expense','2021-09-27 21:17:31','2021-09-27 21:17:31',NULL,NULL,NULL),(42,18.00000,NULL,2,'ExpenseEntry',36,-2710.00000,NULL,'Expense','2021-09-27 23:20:36','2021-09-27 23:20:36',NULL,NULL,NULL),(43,15.00000,NULL,2,'ExpenseEntry',37,-2725.00000,NULL,'Expense','2021-09-29 19:28:24','2021-09-29 19:28:24',NULL,NULL,NULL),(44,20.00000,NULL,2,'ExpenseEntry',38,-2745.00000,NULL,'Expense','2021-09-29 19:29:28','2021-09-29 19:29:28',NULL,NULL,NULL),(45,82.00000,NULL,2,'ExpenseEntry',39,-2827.00000,NULL,'Expense','2021-09-29 19:30:43','2021-09-29 19:30:43',NULL,NULL,NULL),(46,16.00000,NULL,2,'ExpenseEntry',40,-2843.00000,NULL,'Expense','2021-09-29 19:31:24','2021-09-29 19:31:24',NULL,NULL,NULL);
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;

--
-- Table structure for table `pos_settings`
--

DROP TABLE IF EXISTS `pos_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `sys_type` int(11) DEFAULT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `invoice_note` text COLLATE utf8mb4_unicode_ci,
  `pdf_margin_top` int(11) DEFAULT '0',
  `pdf_margin_right` int(11) DEFAULT '0',
  `pdf_margin_bottom` int(11) DEFAULT '0',
  `pdf_margin_left` int(11) DEFAULT '0',
  `purchase_sale_detail_show_page_size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'A4',
  `purchase_sale_detail_show_line_height` int(11) DEFAULT '20',
  `header` tinyint(1) DEFAULT '1',
  `footer` tinyint(1) DEFAULT '1',
  `header_logo_placement` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'logo_disable_text_center',
  `footer_address_placement` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'center',
  `logo_hieght` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '200',
  `logo_width` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '200',
  `header_hieght` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '50',
  `multi_language` tinyint(1) DEFAULT '0',
  `title_padding` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '10',
  `website` text COLLATE utf8mb4_unicode_ci,
  `gst` text COLLATE utf8mb4_unicode_ci,
  `ntn` text COLLATE utf8mb4_unicode_ci,
  `title_style` text COLLATE utf8mb4_unicode_ci,
  `image_style` text COLLATE utf8mb4_unicode_ci,
  `header_style` text COLLATE utf8mb4_unicode_ci,
  `footer_style` text COLLATE utf8mb4_unicode_ci,
  `is_sms` tinyint(1) DEFAULT '0',
  `is_qr` tinyint(1) DEFAULT '0',
  `sms_user` text COLLATE utf8mb4_unicode_ci,
  `sms_pass` text COLLATE utf8mb4_unicode_ci,
  `sms_mask` text COLLATE utf8mb4_unicode_ci,
  `sms_templates` json DEFAULT NULL,
  `company_mask` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qr_links` json DEFAULT NULL,
  `extra_settings` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_pos_settings_on_account_id` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_settings`
--

/*!40000 ALTER TABLE `pos_settings` DISABLE KEYS */;
INSERT INTO `pos_settings` VALUES (1,'Al-Arsh Construction Corp','Al-Arsh Construction Corp','7184315203',NULL,'309 Deer Road, Ronkonkoma NY 11779','2021-08-31 14:04:24','2021-09-07 00:33:19',4,1,'2022-08-26 00:00:00','',0,0,0,0,'',20,1,1,'logo_left_text_center','center','150','300','180',0,'100',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `pos_settings` ENABLE KEYS */;

--
-- Table structure for table `product_categories`
--

DROP TABLE IF EXISTS `product_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_categories`
--

/*!40000 ALTER TABLE `product_categories` DISABLE KEYS */;
INSERT INTO `product_categories` VALUES (1,'000DC','Default Category','','2021-08-31 14:04:22','2021-09-01 00:40:02');
/*!40000 ALTER TABLE `product_categories` ENABLE KEYS */;

--
-- Table structure for table `product_stock_exchanges`
--

DROP TABLE IF EXISTS `product_stock_exchanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_stock_exchanges` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) DEFAULT NULL,
  `product_recipient_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_product_stock_exchanges_on_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_stock_exchanges`
--

/*!40000 ALTER TABLE `product_stock_exchanges` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_stock_exchanges` ENABLE KEYS */;

--
-- Table structure for table `product_stocks`
--

DROP TABLE IF EXISTS `product_stocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_stocks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) DEFAULT NULL,
  `in_stock` int(11) DEFAULT NULL,
  `out_stock` int(11) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `cost_price` int(11) DEFAULT NULL,
  `sale_price` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_product_stocks_on_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_stocks`
--

/*!40000 ALTER TABLE `product_stocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_stocks` ENABLE KEYS */;

--
-- Table structure for table `product_sub_categories`
--

DROP TABLE IF EXISTS `product_sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_sub_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_category_id` int(11) DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_product_sub_categories_on_product_category_id` (`product_category_id`),
  CONSTRAINT `fk_rails_e399a2e96d` FOREIGN KEY (`product_category_id`) REFERENCES `product_categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_sub_categories`
--

/*!40000 ALTER TABLE `product_sub_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_sub_categories` ENABLE KEYS */;

--
-- Table structure for table `product_warranties`
--

DROP TABLE IF EXISTS `product_warranties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_warranties` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `purchase_sale_detail_id` bigint(20) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `serial` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_product_warranties_on_purchase_sale_detail_id` (`purchase_sale_detail_id`),
  KEY `index_product_warranties_on_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_warranties`
--

/*!40000 ALTER TABLE `product_warranties` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_warranties` ENABLE KEYS */;

--
-- Table structure for table `production_block_types`
--

DROP TABLE IF EXISTS `production_block_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `production_block_types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_block_types`
--

/*!40000 ALTER TABLE `production_block_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_block_types` ENABLE KEYS */;

--
-- Table structure for table `production_blocks`
--

DROP TABLE IF EXISTS `production_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `production_blocks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `production_block_type_id` bigint(20) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bricks_quantity` int(11) DEFAULT NULL,
  `tiles_quantity` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `production_cycle_id` bigint(20) DEFAULT NULL,
  `bhari_production_block_id` int(11) DEFAULT NULL,
  `jalai_a` float DEFAULT NULL,
  `jalai_b` float DEFAULT NULL,
  `production_status` int(11) DEFAULT NULL,
  `purchase_sale_detail_id` bigint(20) DEFAULT NULL,
  `jalai_a_quantity` float DEFAULT NULL,
  `jalai_b_quantity` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_production_blocks_on_production_block_type_id` (`production_block_type_id`),
  KEY `index_production_blocks_on_production_cycle_id` (`production_cycle_id`),
  KEY `index_production_blocks_on_purchase_sale_detail_id` (`purchase_sale_detail_id`),
  CONSTRAINT `fk_rails_48bb3764ca` FOREIGN KEY (`production_block_type_id`) REFERENCES `production_block_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_blocks`
--

/*!40000 ALTER TABLE `production_blocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_blocks` ENABLE KEYS */;

--
-- Table structure for table `production_cycles`
--

DROP TABLE IF EXISTS `production_cycles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `production_cycles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `cycle_type` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `item_id` bigint(20) DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `quantity` float DEFAULT NULL,
  `total_cost` float DEFAULT NULL,
  `measurement_quantity` float DEFAULT NULL,
  `lines` int(11) DEFAULT NULL,
  `cost_per_line` float DEFAULT NULL,
  `per_product_cost` float DEFAULT NULL,
  `per_thousand_product_cost` float DEFAULT NULL,
  `item_quantity_per_line` float DEFAULT NULL,
  `total_item_quantity` float DEFAULT NULL,
  `per_ton_bricks` float DEFAULT NULL,
  `total_bricks` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_production_cycles_on_item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_cycles`
--

/*!40000 ALTER TABLE `production_cycles` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_cycles` ENABLE KEYS */;

--
-- Table structure for table `productions`
--

DROP TABLE IF EXISTS `productions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `productions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `operation_cost` decimal(10,0) DEFAULT NULL,
  `cost_price` decimal(10,0) DEFAULT NULL,
  `sale_price` decimal(10,0) DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_productions_on_product_id` (`product_id`),
  CONSTRAINT `fk_rails_da7ae25ed8` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productions`
--

/*!40000 ALTER TABLE `productions` DISABLE KEYS */;
/*!40000 ALTER TABLE `productions` ENABLE KEYS */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_type_id` int(11) DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_category_id` int(11) DEFAULT NULL,
  `product_sub_category_id` int(11) DEFAULT NULL,
  `acquire_type` int(11) DEFAULT NULL,
  `purchase_type` int(11) DEFAULT NULL,
  `purchase_unit` int(11) DEFAULT NULL,
  `purchase_factor` int(11) DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `sale` float DEFAULT NULL,
  `minimum` float DEFAULT NULL,
  `optimal` float DEFAULT NULL,
  `maximum` float DEFAULT NULL,
  `currency` int(11) DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `stock` float DEFAULT '0',
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_4` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_5` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_6` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_7` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_8` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_9` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_10` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_11` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_12` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_13` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `product_type` int(11) DEFAULT '0',
  `measurement_quantity` float DEFAULT NULL,
  `raw_product_id` bigint(20) DEFAULT NULL,
  `gst` float DEFAULT '0',
  `vat` float DEFAULT '0',
  `hst` float DEFAULT '0',
  `pst` float DEFAULT '0',
  `qst` float DEFAULT '0',
  `with_serial` tinyint(1) DEFAULT NULL,
  `warranty_list` text COLLATE utf8mb4_unicode_ci,
  `marla` float DEFAULT NULL,
  `square_feet` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_products_on_item_type_id` (`item_type_id`),
  KEY `index_products_on_product_category_id` (`product_category_id`),
  KEY `index_products_on_product_sub_category_id` (`product_sub_category_id`),
  KEY `index_products_on_raw_product_id` (`raw_product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,'AGC-0001','Roofing',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,0,NULL,'2021-08-31 23:41:26','2021-09-02 11:27:51',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,'',NULL,NULL),(2,1,'AGC-0002',' Masonry',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,1,NULL,'2021-08-31 23:44:08','2021-09-06 19:48:48',100001,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL),(3,1,'AGC-0003','Interior Work',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,0,NULL,'2021-09-01 00:38:04','2021-09-01 00:38:04',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL),(4,1,'AGC-0004',' Shingle Roof',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,1,NULL,'2021-09-01 00:39:16','2021-09-02 11:27:51',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,'',NULL,NULL),(5,1,'AGC-0005','New Construction',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,1,NULL,'2021-09-01 00:41:59','2021-09-01 00:41:59',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL),(6,1,'AGC-0006','Painting',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,0,NULL,'2021-09-01 00:42:27','2021-09-02 11:27:51',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,'',NULL,NULL),(7,1,'AGC-0007','Tile Works',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,1,NULL,'2021-09-01 00:42:52','2021-09-01 00:42:52',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL),(8,1,'AGC-0008','Vinyl Siding',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,1,NULL,'2021-09-01 00:43:24','2021-09-01 00:43:24',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL),(9,1,'AGC-0009','Gutter Cleaning',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,1,NULL,'2021-09-01 00:43:44','2021-09-01 00:43:44',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL),(10,1,'AGC-0010',' Cold Application Roof',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,1,NULL,'2021-09-01 00:44:10','2021-09-01 00:44:10',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL),(11,1,'AGC-0011','Waterproofing',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,1,NULL,'2021-09-01 00:44:33','2021-09-01 00:44:33',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL),(12,1,'AGC-0012','Paving',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,1,NULL,'2021-09-01 00:44:56','2021-09-01 00:44:56',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL),(13,1,'AGC-0013',' Waterproof  Thorocoat',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,1,NULL,'2021-09-01 00:45:41','2021-09-01 00:45:41',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL),(14,1,'AGC-0014','Scaffolding',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,1,NULL,'2021-09-01 00:46:20','2021-09-01 00:46:20',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL),(15,1,'AGC-0015','Fire Stone Rubber Roof',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,1,NULL,'2021-09-01 00:46:48','2021-09-01 00:46:48',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL),(16,1,'AGC-0016',' Window Replacement 	',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,1,NULL,'2021-09-01 00:47:13','2021-09-01 00:47:13',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL),(17,1,'AGC-0017','Waterproof Thoroseal',1,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,1,NULL,'2021-09-01 00:47:43','2021-09-01 00:47:43',100000,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0',0,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

--
-- Table structure for table `property_installments`
--

DROP TABLE IF EXISTS `property_installments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `property_installments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `property_plan_id` bigint(20) DEFAULT NULL,
  `installment_no` int(11) DEFAULT NULL,
  `installment_price` decimal(15,2) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `due_date` datetime DEFAULT NULL,
  `due_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_property_installments_on_property_plan_id` (`property_plan_id`),
  CONSTRAINT `fk_rails_e8934128e8` FOREIGN KEY (`property_plan_id`) REFERENCES `property_plans` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `property_installments`
--

/*!40000 ALTER TABLE `property_installments` DISABLE KEYS */;
/*!40000 ALTER TABLE `property_installments` ENABLE KEYS */;

--
-- Table structure for table `property_plans`
--

DROP TABLE IF EXISTS `property_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `property_plans` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `property_type` int(11) DEFAULT NULL,
  `area_in_marla` decimal(7,2) DEFAULT NULL,
  `price_per_marla` decimal(15,2) DEFAULT NULL,
  `total_price` decimal(15,2) DEFAULT NULL,
  `payment_type` int(11) DEFAULT NULL,
  `payment_plan` int(11) DEFAULT NULL,
  `no_of_installments` int(11) DEFAULT NULL,
  `advance` decimal(15,2) DEFAULT NULL,
  `high_amount_installments` int(11) DEFAULT NULL,
  `total_high_amount` decimal(15,2) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  `last_instalment` decimal(15,5) DEFAULT '0.00000',
  `due_date` datetime DEFAULT NULL,
  `due_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_property_plans_on_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `property_plans`
--

/*!40000 ALTER TABLE `property_plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `property_plans` ENABLE KEYS */;

--
-- Table structure for table `purchase_sale_details`
--

DROP TABLE IF EXISTS `purchase_sale_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_sale_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sys_user_id` int(11) DEFAULT NULL,
  `transaction_type` int(11) DEFAULT NULL,
  `total_bill` float DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `discount_price` float DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `voucher_id` int(11) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `carriage` float DEFAULT '0',
  `loading` float DEFAULT '0',
  `order_id` bigint(20) DEFAULT NULL,
  `staff_id` bigint(20) DEFAULT NULL,
  `bill_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `destination` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l_c` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_d` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_d_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_d_date` datetime DEFAULT NULL,
  `quantity` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dispatched_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `despatch_date` datetime DEFAULT NULL,
  `job_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `with_gst` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_purchase_sale_details_on_sys_user_id` (`sys_user_id`),
  KEY `index_purchase_sale_details_on_account_id` (`account_id`),
  KEY `index_purchase_sale_details_on_order_id` (`order_id`),
  KEY `index_purchase_sale_details_on_staff_id` (`staff_id`),
  CONSTRAINT `fk_rails_8fef5fd98b` FOREIGN KEY (`sys_user_id`) REFERENCES `sys_users` (`id`),
  CONSTRAINT `fk_rails_d0d464c4c0` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_sale_details`
--

/*!40000 ALTER TABLE `purchase_sale_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_sale_details` ENABLE KEYS */;

--
-- Table structure for table `purchase_sale_items`
--

DROP TABLE IF EXISTS `purchase_sale_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_sale_detail_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `quantity` float DEFAULT NULL,
  `cost_price` float DEFAULT NULL,
  `sale_price` float DEFAULT NULL,
  `total_cost_price` float DEFAULT NULL,
  `total_sale_price` float DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `transaction_type` int(11) DEFAULT NULL,
  `size_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_4` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_5` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_6` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_7` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_8` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_9` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_10` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_11` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_12` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `size_13` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `discount_price` float DEFAULT '0',
  `purchase_sale_type` int(11) DEFAULT '0',
  `expiry_date` datetime DEFAULT NULL,
  `remaining_quantity` float DEFAULT NULL,
  `extra_expence` float DEFAULT NULL,
  `extra_quantity` float DEFAULT NULL,
  `gst` decimal(15,2) DEFAULT NULL,
  `gst_amount` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_purchase_sale_items_on_purchase_sale_detail_id` (`purchase_sale_detail_id`),
  KEY `index_purchase_sale_items_on_item_id` (`item_id`),
  KEY `index_purchase_sale_items_on_product_id` (`product_id`),
  CONSTRAINT `fk_rails_6daff32ec6` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `fk_rails_7950dd97a8` FOREIGN KEY (`purchase_sale_detail_id`) REFERENCES `purchase_sale_details` (`id`),
  CONSTRAINT `fk_rails_ca75b069a2` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_sale_items`
--

/*!40000 ALTER TABLE `purchase_sale_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_sale_items` ENABLE KEYS */;

--
-- Table structure for table `raw_products`
--

DROP TABLE IF EXISTS `raw_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `raw_products` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stock` float DEFAULT NULL,
  `acquire_type` int(11) DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `sale` float DEFAULT NULL,
  `minimum` float DEFAULT NULL,
  `optimal` float DEFAULT NULL,
  `maximum` float DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `first_stock` int(11) DEFAULT '0',
  `second_stock` int(11) DEFAULT '0',
  `third_stock` int(11) DEFAULT '0',
  `nakasi_stock` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `raw_products`
--

/*!40000 ALTER TABLE `raw_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `raw_products` ENABLE KEYS */;

--
-- Table structure for table `salaries`
--

DROP TABLE IF EXISTS `salaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salaries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paid_salary` int(11) DEFAULT NULL,
  `advance` int(11) DEFAULT '0',
  `leaves_in_month` int(11) DEFAULT '0',
  `staff_id` int(11) DEFAULT NULL,
  `paid_to` int(11) DEFAULT NULL,
  `payment_type` int(11) DEFAULT '0',
  `advance_amount` int(11) DEFAULT '0',
  `advance_due_till_this_transaction` int(11) DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `balance` float DEFAULT NULL,
  `total_balance` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_salaries_on_staff_id` (`staff_id`),
  KEY `index_salaries_on_account_id` (`account_id`),
  CONSTRAINT `fk_rails_3201966c25` FOREIGN KEY (`staff_id`) REFERENCES `staffs` (`id`),
  CONSTRAINT `fk_rails_dceb7a339c` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salaries`
--

/*!40000 ALTER TABLE `salaries` DISABLE KEYS */;
/*!40000 ALTER TABLE `salaries` ENABLE KEYS */;

--
-- Table structure for table `salary_detail_product_quantities`
--

DROP TABLE IF EXISTS `salary_detail_product_quantities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salary_detail_product_quantities` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `salary_detail_id` bigint(20) DEFAULT NULL,
  `staff_id` bigint(20) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `quantity` float DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_salary_detail_product_quantities_on_salary_detail_id` (`salary_detail_id`),
  KEY `index_salary_detail_product_quantities_on_staff_id` (`staff_id`),
  KEY `index_salary_detail_product_quantities_on_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_detail_product_quantities`
--

/*!40000 ALTER TABLE `salary_detail_product_quantities` DISABLE KEYS */;
/*!40000 ALTER TABLE `salary_detail_product_quantities` ENABLE KEYS */;

--
-- Table structure for table `salary_details`
--

DROP TABLE IF EXISTS `salary_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salary_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `wage_rate` float DEFAULT NULL,
  `quantity` float DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `extra` int(11) DEFAULT NULL,
  `daily_book_id` bigint(20) DEFAULT NULL,
  `raw_product_id` bigint(20) DEFAULT NULL,
  `raw_quantity` float DEFAULT NULL,
  `raw_wage_rate` float DEFAULT NULL,
  `gift_rate` float DEFAULT NULL,
  `coverge_rate` float DEFAULT NULL,
  `wage_debit` float DEFAULT NULL,
  `gift_pay` float DEFAULT NULL,
  `coverge_pay` float DEFAULT NULL,
  `staff_pathera_id` int(11) DEFAULT NULL,
  `transaction_location` int(11) DEFAULT NULL,
  `khakar_quanity` int(11) DEFAULT NULL,
  `khakar_remaning` int(11) DEFAULT NULL,
  `khakar_debit` int(11) DEFAULT NULL,
  `khakar_wast` int(11) DEFAULT NULL,
  `khakar_extra` int(11) DEFAULT NULL,
  `khakar_credit` int(11) DEFAULT NULL,
  `pather_remaning_quanity` int(11) DEFAULT NULL,
  `pather_salary_detail_id` int(11) DEFAULT NULL,
  `purchase_sale_detail_id` bigint(20) DEFAULT NULL,
  `pather_khakar_wast` int(11) DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `total_balance` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_salary_details_on_staff_id` (`staff_id`),
  KEY `index_salary_details_on_product_id` (`product_id`),
  KEY `index_salary_details_on_daily_book_id` (`daily_book_id`),
  KEY `index_salary_details_on_raw_product_id` (`raw_product_id`),
  KEY `index_salary_details_on_purchase_sale_detail_id` (`purchase_sale_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_details`
--

/*!40000 ALTER TABLE `salary_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `salary_details` ENABLE KEYS */;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('20190820170452'),('20190824033109'),('20190825162666'),('20190901110966'),('20190905123943'),('20190905152700'),('20190910141629'),('20191024182225'),('20192826154824'),('20192826154826'),('20192826154828'),('20192826154829'),('20192826154830'),('20192826154831'),('20192826154832'),('20192826154833'),('20192826154834'),('20192826154835'),('20192826154836'),('20192826154837'),('20192826154838'),('20192826154839'),('20192826154840'),('20192826154841'),('20192826154842'),('20192826154843'),('20192826154844'),('20192826154846'),('20192826154847'),('20192826154852'),('20192826154854'),('20192826154855'),('20192826154856'),('20200113183843'),('20200119105932'),('20200124131728'),('20200124165218'),('20200124191237'),('20200210075332'),('20200217115702'),('20200224063734'),('20200226101712'),('20200226101847'),('20200227095546'),('20200227104259'),('20200301101333'),('20200303093136'),('20200306091302'),('20200311202312'),('20200312110150'),('20200408173307'),('20200418170841'),('20200418181645'),('20200418203508'),('20200419161616'),('20200421062616'),('20200421164024'),('20200421171644'),('20200421174805'),('20200425101108'),('20200425101304'),('20200425143738'),('20200425160537'),('20200426133117'),('20200426210956'),('20200427143930'),('20200427200439'),('20200428192723'),('20200504171138'),('20200504175505'),('20200504191414'),('20200506200039'),('20200507165238'),('20200509184915'),('20200511194915'),('20200513181132'),('20200514092452'),('20200514093642'),('20200514093750'),('20200523195722'),('20200523210319'),('20200530190147'),('20200601181846'),('20200606135427'),('20200607205725'),('20200609122451'),('20200627155258'),('20200628175721'),('20200707185303'),('20200711105128'),('20200711122741'),('20200806112819'),('20200808070939'),('20200812165225'),('20200812172942'),('20200814182240'),('20200816060109'),('20200823212241'),('20200830094330'),('20200830131214'),('20200907071711'),('20200919054722'),('20200923155704'),('20201008133204'),('20201008195028'),('20201010115446'),('20201011152720'),('20201107220236'),('20201113115114'),('20201120192630'),('20201130091020'),('20201205103046'),('20201205182427'),('20201206115351'),('20201211123723'),('20201211204116'),('20201213185840'),('20201213193914'),('20201231095037'),('20210104121504'),('20210104162049'),('20210119072148'),('20210120033132'),('20210125080632'),('20210128093444'),('20210130143156'),('20210131152805'),('20210214083344'),('20210215120751'),('20210228121058'),('20210302044354'),('20210304074527'),('20210317095723'),('20210317100623'),('20210321101342'),('20210403092545'),('20210410095242'),('20210423111955'),('20210628092535'),('20210628103454'),('20210712064243'),('20210730062723'),('20210731124350'),('20210814095243'),('20210823083827'),('20210825084935'),('20210829074606'),('20210908084910'),('20210921143831'),('20210922052435'),('20211015112829'),('20211018073431'),('20211110073300'),('20211115072807'),('20211125074326'),('20211229115106'),('20220114110159'),('20220114110160'),('20220117190850'),('20220121101226'),('20220121104339'),('20220204110604'),('20220207082705'),('20220223173033');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;

--
-- Table structure for table `sms_logs`
--

DROP TABLE IF EXISTS `sms_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sms_from` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sms_to` text COLLATE utf8mb4_unicode_ci,
  `msg` text COLLATE utf8mb4_unicode_ci,
  `sms_by` text COLLATE utf8mb4_unicode_ci,
  `response` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_logs`
--

/*!40000 ALTER TABLE `sms_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_logs` ENABLE KEYS */;

--
-- Table structure for table `staff_deals`
--

DROP TABLE IF EXISTS `staff_deals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff_deals` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `staff_id` bigint(20) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `cost` decimal(10,0) DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_staff_deals_on_staff_id` (`staff_id`),
  KEY `index_staff_deals_on_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_deals`
--

/*!40000 ALTER TABLE `staff_deals` DISABLE KEYS */;
/*!40000 ALTER TABLE `staff_deals` ENABLE KEYS */;

--
-- Table structure for table `staff_ledger_books`
--

DROP TABLE IF EXISTS `staff_ledger_books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff_ledger_books` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `staff_id` bigint(20) DEFAULT NULL,
  `salary_id` bigint(20) DEFAULT NULL,
  `salary_detail_id` bigint(20) DEFAULT NULL,
  `debit` decimal(15,5) DEFAULT NULL,
  `credit` decimal(15,5) DEFAULT NULL,
  `balance` decimal(15,5) DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_staff_ledger_books_on_staff_id` (`staff_id`),
  KEY `index_staff_ledger_books_on_salary_id` (`salary_id`),
  KEY `index_staff_ledger_books_on_salary_detail_id` (`salary_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_ledger_books`
--

/*!40000 ALTER TABLE `staff_ledger_books` DISABLE KEYS */;
/*!40000 ALTER TABLE `staff_ledger_books` ENABLE KEYS */;

--
-- Table structure for table `staff_raw_products`
--

DROP TABLE IF EXISTS `staff_raw_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff_raw_products` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `staff_id` bigint(20) DEFAULT NULL,
  `raw_product_id` bigint(20) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_staff_raw_products_on_staff_id` (`staff_id`),
  KEY `index_staff_raw_products_on_raw_product_id` (`raw_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_raw_products`
--

/*!40000 ALTER TABLE `staff_raw_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `staff_raw_products` ENABLE KEYS */;

--
-- Table structure for table `staffs`
--

DROP TABLE IF EXISTS `staffs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staffs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `father` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `education` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnic` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_joining` date DEFAULT NULL,
  `yearly_increment` int(11) DEFAULT NULL,
  `monthly_salary` decimal(15,5) DEFAULT NULL,
  `staff_department` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` int(11) DEFAULT NULL,
  `advance_amount` decimal(15,5) DEFAULT '0.00000',
  `terminated` tinyint(1) DEFAULT '0',
  `terminated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `wage_rate` decimal(15,5) DEFAULT '0.00000',
  `comment` text COLLATE utf8mb4_unicode_ci,
  `balance` decimal(15,5) DEFAULT '0.00000',
  `department_id` bigint(20) DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `staff_type` int(11) DEFAULT NULL,
  `wage_debit` decimal(15,5) DEFAULT NULL,
  `raw_product_quantity` float DEFAULT '0',
  `raw_product_quantity_tile` float DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_staffs_on_department_id` (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staffs`
--

/*!40000 ALTER TABLE `staffs` DISABLE KEYS */;
INSERT INTO `staffs` VALUES (1,'GHULAM MURTAZA ','','','7184315203','309 Deer Road, Ronkonkoma','',NULL,NULL,NULL,'',0,0.00000,0,'2021-09-01 00:33:26',0,'2021-09-01 00:33:26','2021-09-01 00:33:26','2021-09-01 00:34:29',0.00000,NULL,0.00000,NULL,'AGC-0001',0,0.00000,0,0),(2,'MOHAMMED','','MSCE','9292350395','Queens','','2021-08-02',NULL,NULL,'',0,0.00000,0,'2021-09-01 00:35:08',0,'2021-09-01 00:35:08','2021-09-01 00:35:08','2021-09-01 00:35:24',0.00000,NULL,0.00000,NULL,'AGC-0002',0,0.00000,0,0),(3,'ADEEL ABBAS','','','9292715559','','',NULL,NULL,NULL,'',0,0.00000,0,'2021-09-01 00:36:25',0,'2021-09-01 00:36:25','2021-09-01 00:36:25','2021-09-27 21:21:14',0.00000,NULL,0.00000,NULL,'AGC-0003',0,0.00000,0,0),(4,'Kuldeep','Singh','','','','',NULL,NULL,NULL,'',0,0.00000,0,'2021-09-02 00:34:06',0,'2021-09-02 00:34:06','2021-09-02 00:34:06','2021-09-02 00:34:06',0.00000,NULL,0.00000,NULL,'AGC-0004',0,0.00000,0,0),(5,'Mason-1','','','','','',NULL,NULL,NULL,'',0,0.00000,0,'2021-09-06 19:47:20',0,'2021-09-06 19:47:20','2021-09-06 19:47:20','2021-09-06 21:59:36',250.00000,NULL,0.00000,NULL,'AGC-0005',0,0.00000,0,0);
/*!40000 ALTER TABLE `staffs` ENABLE KEYS */;

--
-- Table structure for table `sys_users`
--

DROP TABLE IF EXISTS `sys_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnic` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_type_id` int(11) DEFAULT NULL,
  `user_group` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `occupation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credit_status` int(11) DEFAULT NULL,
  `credit_limit` decimal(15,2) DEFAULT NULL,
  `opening_balance` decimal(15,2) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `balance` decimal(15,2) DEFAULT NULL,
  `gst` text COLLATE utf8mb4_unicode_ci,
  `ntn` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `index_sys_users_on_user_type_id` (`user_type_id`),
  CONSTRAINT `fk_rails_17a2a8881c` FOREIGN KEY (`user_type_id`) REFERENCES `user_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_users`
--

/*!40000 ALTER TABLE `sys_users` DISABLE KEYS */;
INSERT INTO `sys_users` VALUES (1,'AGC-0001','','GIANNI REDZIC ',1,0,0,'Project manager',0,NULL,0.00,'2021-09-01 00:18:28','2021-09-01 00:32:13',0.00,NULL,NULL),(2,'AGC-0002','','BEN GOLDFARB',1,0,0,'Owner',0,NULL,0.00,'2021-09-01 00:23:54','2021-09-01 00:31:47',0.00,NULL,NULL),(3,'AGC-0003','','SAMI SUHAIL',1,0,0,'Owner',0,NULL,0.00,'2021-09-01 00:26:36','2021-09-02 11:27:51',0.00,NULL,NULL),(4,'AGC-0004','','CLAUDIUS COMPTON',1,0,0,'Management',0,NULL,0.00,'2021-09-01 00:29:30','2021-09-01 00:31:24',0.00,NULL,NULL),(5,'AGC-0005','','DORON YAGHOUBI',1,0,0,'Management',0,NULL,0.00,'2021-09-01 00:31:03','2021-09-01 00:31:03',0.00,NULL,NULL);
/*!40000 ALTER TABLE `sys_users` ENABLE KEYS */;

--
-- Table structure for table `user_abilities`
--

DROP TABLE IF EXISTS `user_abilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_abilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roles_mask` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_user_abilities_on_user_id` (`user_id`),
  CONSTRAINT `fk_rails_39341c4389` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_abilities`
--

/*!40000 ALTER TABLE `user_abilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_abilities` ENABLE KEYS */;

--
-- Table structure for table `user_types`
--

DROP TABLE IF EXISTS `user_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_by_percentage` float DEFAULT NULL,
  `discount_by_amount` float DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_types`
--

/*!40000 ALTER TABLE `user_types` DISABLE KEYS */;
INSERT INTO `user_types` VALUES (1,'Normal','AGC-0001',NULL,NULL,'','2021-08-31 23:46:18','2021-08-31 23:49:44');
/*!40000 ALTER TABLE `user_types` ENABLE KEYS */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encrypted_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reset_password_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_password_sent_at` datetime DEFAULT NULL,
  `remember_created_at` datetime DEFAULT NULL,
  `sign_in_count` int(11) NOT NULL DEFAULT '0',
  `current_sign_in_at` datetime DEFAULT NULL,
  `last_sign_in_at` datetime DEFAULT NULL,
  `failed_attempts` int(11) NOT NULL DEFAULT '0',
  `unlock_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `locked_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `roles_mask` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `father_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `created_by_id` int(11) DEFAULT NULL,
  `company_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_to` text COLLATE utf8mb4_unicode_ci,
  `email_cc` text COLLATE utf8mb4_unicode_ci,
  `email_bcc` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_users_on_email` (`email`),
  UNIQUE KEY `index_users_on_reset_password_token` (`reset_password_token`),
  UNIQUE KEY `index_users_on_user_name` (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

--
-- Table structure for table `versions`
--

DROP TABLE IF EXISTS `versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `versions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `item_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `event` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `whodunnit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `object` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `object_changes` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `index_versions_on_item_type_and_item_id` (`item_type`,`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=428 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `versions`
--

/*!40000 ALTER TABLE `versions` DISABLE KEYS */;
INSERT INTO `versions` VALUES (1,'Country',1,'create',NULL,NULL,'2021-08-31 14:04:22','---\nid:\n- \n- 1\ntitle:\n- \n- Pakistan\ncreated_at:\n- \n- 2021-08-31 14:04:22.000000000 Z\nupdated_at:\n- \n- 2021-08-31 14:04:22.000000000 Z\n'),(2,'City',1,'create',NULL,NULL,'2021-08-31 14:04:22','---\nid:\n- \n- 1\ntitle:\n- \n- Lahore\ncreated_at:\n- \n- 2021-08-31 14:04:22.000000000 Z\nupdated_at:\n- \n- 2021-08-31 14:04:22.000000000 Z\n'),(3,'ItemType',1,'create',NULL,NULL,'2021-08-31 14:04:22','---\nid:\n- \n- 1\ntitle:\n- \n- default\ncode:\n- \n- default\ncreated_at:\n- \n- 2021-08-31 14:04:22.000000000 Z\nupdated_at:\n- \n- 2021-08-31 14:04:22.000000000 Z\n'),(4,'ProductCategory',1,'create',NULL,NULL,'2021-08-31 14:04:22','---\nid:\n- \n- 1\ncode:\n- \n- default Category\ntitle:\n- \n- default Category\ncreated_at:\n- \n- 2021-08-31 14:04:22.000000000 Z\nupdated_at:\n- \n- 2021-08-31 14:04:22.000000000 Z\n'),(5,'ExpenseType',1,'create',NULL,NULL,'2021-08-31 14:04:22','---\nid:\n- \n- 1\ntitle:\n- \n- Expense\ncreated_at:\n- \n- 2021-08-31 14:04:22.000000000 Z\nupdated_at:\n- \n- 2021-08-31 14:04:22.000000000 Z\n'),(6,'Account',1,'update',NULL,'---\nid: 1\ntitle: Comapny Cash\nbank_name: \niban_number: \namount: \ncreated_at: 2021-08-31 14:04:23.000000000 Z\nupdated_at: 2021-08-31 14:04:23.000000000 Z\ncomment: \nuser_id: \n','2021-08-31 14:04:23','---\namount:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(7,'Payment',1,'update',NULL,'---\nid: 1\ndebit: \ncredit: !ruby/object:BigDecimal 18:0.0\naccount_id: 1\npaymentable_type: \npaymentable_id: \namount: \nstatus: \ncomment: Opening Balance\ncreated_at: 2021-08-31 14:04:23.000000000 Z\nupdated_at: 2021-08-31 14:04:23.000000000 Z\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-08-31 14:04:23','---\namount:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(8,'Payment',1,'create',NULL,NULL,'2021-08-31 14:04:23','---\namount:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(9,'Account',1,'create',NULL,NULL,'2021-08-31 14:04:23',NULL),(10,'PosSetting',1,'create',NULL,NULL,'2021-08-31 14:04:24','---\nid:\n- \n- 1\nname:\n- \n- New Company\ncreated_at:\n- \n- 2021-08-31 14:04:24.000000000 Z\nupdated_at:\n- \n- 2021-08-31 14:04:24.000000000 Z\naccount_id:\n- \n- 1\nexpiry_date:\n- \n- 2022-08-26 00:00:00.000000000 Z\n'),(11,'PosSetting',1,'update','192','---\nid: 1\nname: New Company\ndisplay_name: \nphone: \naccount_id: 1\naddress: \nsys_type: \ninvoice_note: \npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: A4\nheader: true\nfooter: true\nheader_logo_placement: logo_disable_text_center\nlogo_hieght: \'200\'\nlogo_width: \'200\'\nheader_hieght: \'50\'\nmulti_language: false\ntitle_padding: \'10\'\nfooter_address_placement: center\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nupdated_at: 2021-08-31 14:04:24.000000000 +05:00\npurchase_sale_detail_show_line_height: 20\n','2021-08-31 23:33:03','---\ndisplay_name:\n- \n- \'\'\nphone:\n- \n- \'\'\naddress:\n- \n- \'\'\nsys_type:\n- \n- 8\ninvoice_note:\n- \n- \'\'\npurchase_sale_detail_show_page_size:\n- A4\n- \'\'\nupdated_at:\n- 2021-08-31 14:04:24.000000000 +05:00\n- 2021-08-31 23:33:03.000000000 +05:00\n'),(12,'PosSetting',1,'update','192','---\nid: 1\nname: New Company\ndisplay_name: \'\'\nphone: \'\'\naccount_id: 1\naddress: \'\'\ninvoice_note: \'\'\npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: \'\'\nheader: true\nfooter: true\nheader_logo_placement: logo_disable_text_center\nlogo_hieght: \'200\'\nlogo_width: \'200\'\nheader_hieght: \'50\'\nmulti_language: false\ntitle_padding: \'10\'\nfooter_address_placement: center\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nupdated_at: 2021-08-31 23:33:03.000000000 +05:00\nsys_type: 8\npurchase_sale_detail_show_line_height: 20\n','2021-08-31 23:35:01','---\nname:\n- New Company\n- Al-Arsh Construction Corp\ndisplay_name:\n- \'\'\n- Al-Arsh Construction Corp\nphone:\n- \'\'\n- \'7184315203\'\naddress:\n- \'\'\n- 309 Deer Road, Ronkonkoma NY 11779\nupdated_at:\n- 2021-08-31 23:33:03.000000000 +05:00\n- 2021-08-31 23:35:01.000000000 +05:00\n'),(13,'ItemType',1,'update','192','---\nid: 1\ntitle: default\ncode: default\ncomment: \ncreated_at: 2021-08-31 14:04:22.000000000 +05:00\nupdated_at: 2021-08-31 14:04:22.000000000 +05:00\n','2021-08-31 23:39:09','---\ntitle:\n- default\n- Construction\ncomment:\n- \n- \'\'\nupdated_at:\n- 2021-08-31 14:04:22.000000000 +05:00\n- 2021-08-31 23:39:09.000000000 +05:00\n'),(14,'Product',1,'create','192',NULL,'2021-08-31 23:41:26','---\nid:\n- \n- 1\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0001\ntitle:\n- \n- Roofing\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 0\ncreated_at:\n- \n- 2021-08-31 23:41:26.000000000 +05:00\nupdated_at:\n- \n- 2021-08-31 23:41:26.000000000 +05:00\nwith_serial:\n- \n- false\n'),(15,'Product',1,'update','192','---\nid: 1\nitem_type_id: 1\ncode: AGC-0001\ntitle: Roofing\nproduct_category_id: 1\nproduct_sub_category_id: \nacquire_type: 0\npurchase_type: 0\npurchase_unit: 0\ncost: 0.0\nsale: 0.0\nminimum: \noptimal: \nmaximum: \ncurrency: 0\nstock: 0.0\ngst: 0.0\nvat: 0.0\nhst: 0.0\npst: 0.0\nqst: 0.0\nwith_serial: false\npurchase_factor: \ncomment: \ncreated_at: 2021-08-31 23:41:26.000000000 +05:00\nupdated_at: 2021-08-31 23:41:26.000000000 +05:00\nlocation: \nsize_1: \'0\'\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\nproduct_type: 0\nmeasurement_quantity: \nraw_product_id: \nwarranty_list: \nmarla: \nsquare_feet: \n','2021-08-31 23:42:58','---\nstock:\n- 0.0\n- 4000000000.0\nupdated_at:\n- 2021-08-31 23:41:26.000000000 +05:00\n- 2021-08-31 23:42:58.000000000 +05:00\n'),(16,'Product',2,'create','192',NULL,'2021-08-31 23:44:08','---\nid:\n- \n- 2\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0002\ntitle:\n- \n- \" Masonry\"\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 0\ncreated_at:\n- \n- 2021-08-31 23:44:08.000000000 +05:00\nupdated_at:\n- \n- 2021-08-31 23:44:08.000000000 +05:00\nwith_serial:\n- \n- false\n'),(17,'Product',2,'update','192','---\nid: 2\nitem_type_id: 1\ncode: AGC-0002\ntitle: \" Masonry\"\nproduct_category_id: 1\nproduct_sub_category_id: \nacquire_type: 0\npurchase_type: 0\npurchase_unit: 0\ncost: 0.0\nsale: 0.0\nminimum: \noptimal: \nmaximum: \ncurrency: 0\nstock: 0.0\ngst: 0.0\nvat: 0.0\nhst: 0.0\npst: 0.0\nqst: 0.0\nwith_serial: false\npurchase_factor: \ncomment: \ncreated_at: 2021-08-31 23:44:08.000000000 +05:00\nupdated_at: 2021-08-31 23:44:08.000000000 +05:00\nlocation: \nsize_1: \'0\'\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\nproduct_type: 0\nmeasurement_quantity: \nraw_product_id: \nwarranty_list: \nmarla: \nsquare_feet: \n','2021-08-31 23:45:16','---\nstock:\n- 0.0\n- 4000000000.0\nupdated_at:\n- 2021-08-31 23:44:08.000000000 +05:00\n- 2021-08-31 23:45:16.000000000 +05:00\n'),(18,'Country',1,'update','192','---\nid: 1\ntitle: Pakistan\ncomment: \ncreated_at: 2021-08-31 14:04:22.000000000 +05:00\nupdated_at: 2021-08-31 14:04:22.000000000 +05:00\n','2021-08-31 23:47:05','---\ntitle:\n- Pakistan\n- United States Of America\ncomment:\n- \n- \'\'\nupdated_at:\n- 2021-08-31 14:04:22.000000000 +05:00\n- 2021-08-31 23:47:05.000000000 +05:00\n'),(19,'City',1,'update','192','---\nid: 1\ntitle: Lahore\ncomment: \ncreated_at: 2021-08-31 14:04:22.000000000 +05:00\nupdated_at: 2021-08-31 14:04:22.000000000 +05:00\n','2021-08-31 23:47:30','---\ntitle:\n- Lahore\n- New York\ncomment:\n- \n- \'\'\nupdated_at:\n- 2021-08-31 14:04:22.000000000 +05:00\n- 2021-08-31 23:47:30.000000000 +05:00\n'),(20,'User',192,'update','192','---\nencrypted_password: \"$2a$11$FcErLWjlKdOZtpcByWOrS.o.7nQpa4fZuIdeWISeGEsSG2BmjD466\"\nid: 192\nroles_mask: 2\ncompany_type: alarsh\nremember_created_at: 2021-08-31 23:31:47.000000000 +05:00\nemail: alarsh_super_admin@gmail.com\nreset_password_token: \nreset_password_sent_at: \nsign_in_count: 0\ncurrent_sign_in_at: \nlast_sign_in_at: \nfailed_attempts: 0\nunlock_token: \nlocked_at: \ncreated_at: 2021-08-31 18:49:17.000000000 +05:00\nupdated_at: 2021-08-31 23:31:47.000000000 +05:00\nname: SuperAdmin\nuser_name: alarsh_super_admin\nfather_name: \ncity: \nphone: \nfax: \naddress: \ncreated_by_id: 99\nemail_to: \nemail_cc: \nemail_bcc: \n','2021-08-31 23:49:48','---\nremember_created_at:\n- 2021-08-31 23:31:47.000000000 +05:00\n- \nupdated_at:\n- 2021-08-31 23:31:47.000000000 +05:00\n- 2021-08-31 23:49:48.000000000 +05:00\n'),(21,'SysUser',1,'create','192',NULL,'2021-09-01 00:18:28','---\nid:\n- \n- 1\ncode:\n- \n- AGC-0001\ncnic:\n- \n- \'\'\nname:\n- \n- \"Gianni Redzic\\t \"\nuser_type_id:\n- \n- 1\nuser_group:\n- \n- 7\nstatus:\n- \n- 0\noccupation:\n- \n- Project manager\ncredit_status:\n- \n- 0\nopening_balance:\n- \n- !ruby/object:BigDecimal 18:0.0\ncreated_at:\n- \n- 2021-09-01 00:18:28.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:18:28.000000000 +05:00\n'),(22,'SysUser',1,'update','192','---\nid: 1\ncode: AGC-0001\ncnic: \'\'\nname: \"Gianni Redzic\\t \"\nuser_type_id: 1\nuser_group: 7\nstatus: 0\noccupation: Project manager\ncredit_status: 0\ncredit_limit: \nopening_balance: !ruby/object:BigDecimal 18:0.0\ncreated_at: 2021-09-01 00:18:28.000000000 +05:00\nupdated_at: 2021-09-01 00:18:28.000000000 +05:00\nbalance: \n','2021-09-01 00:18:28','---\nbalance:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(23,'SysUser',1,'update','192','---\nid: 1\ncode: AGC-0001\ncnic: \'\'\nname: \"Gianni Redzic\\t \"\nuser_type_id: 1\nuser_group: 7\nstatus: 0\noccupation: Project manager\ncredit_status: 0\ncredit_limit: \nopening_balance: !ruby/object:BigDecimal 18:0.0\ncreated_at: 2021-09-01 00:18:28.000000000 +05:00\nupdated_at: 2021-09-01 00:18:28.000000000 +05:00\nbalance: !ruby/object:BigDecimal 18:0.0\n','2021-09-01 00:18:56','---\nuser_group:\n- 7\n- 0\ncredit_status:\n- 0\n- 0\nupdated_at:\n- 2021-09-01 00:18:28.000000000 +05:00\n- 2021-09-01 00:18:56.000000000 +05:00\n'),(24,'SysUser',2,'create','192',NULL,'2021-09-01 00:23:54','---\nid:\n- \n- 2\ncode:\n- \n- AGC-0002\ncnic:\n- \n- \'\'\nname:\n- \n- Ben Goldfarb\nuser_type_id:\n- \n- 1\nuser_group:\n- \n- 0\nstatus:\n- \n- 0\noccupation:\n- \n- Owner\ncredit_status:\n- \n- 0\nopening_balance:\n- \n- !ruby/object:BigDecimal 18:0.0\ncreated_at:\n- \n- 2021-09-01 00:23:54.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:23:54.000000000 +05:00\n'),(25,'SysUser',2,'update','192','---\nid: 2\ncode: AGC-0002\ncnic: \'\'\nname: Ben Goldfarb\nuser_type_id: 1\nuser_group: 0\nstatus: 0\noccupation: Owner\ncredit_status: 0\ncredit_limit: \nopening_balance: !ruby/object:BigDecimal 18:0.0\ncreated_at: 2021-09-01 00:23:54.000000000 +05:00\nupdated_at: 2021-09-01 00:23:54.000000000 +05:00\nbalance: \n','2021-09-01 00:23:55','---\nupdated_at:\n- 2021-09-01 00:23:54.000000000 +05:00\n- 2021-09-01 00:23:55.000000000 +05:00\nbalance:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(26,'SysUser',3,'create','192',NULL,'2021-09-01 00:26:36','---\nid:\n- \n- 3\ncode:\n- \n- AGC-0003\ncnic:\n- \n- \'\'\nname:\n- \n- Sami Suhail\nuser_type_id:\n- \n- 1\nuser_group:\n- \n- 8\nstatus:\n- \n- 0\noccupation:\n- \n- Owner\ncredit_status:\n- \n- 0\nopening_balance:\n- \n- !ruby/object:BigDecimal 18:0.0\ncreated_at:\n- \n- 2021-09-01 00:26:36.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:26:36.000000000 +05:00\n'),(27,'SysUser',3,'update','192','---\nid: 3\ncode: AGC-0003\ncnic: \'\'\nname: Sami Suhail\nuser_type_id: 1\nuser_group: 8\nstatus: 0\noccupation: Owner\ncredit_status: 0\ncredit_limit: \nopening_balance: !ruby/object:BigDecimal 18:0.0\ncreated_at: 2021-09-01 00:26:36.000000000 +05:00\nupdated_at: 2021-09-01 00:26:36.000000000 +05:00\nbalance: \n','2021-09-01 00:26:36','---\nbalance:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(28,'SysUser',3,'update','192','---\nid: 3\ncode: AGC-0003\ncnic: \'\'\nname: Sami Suhail\nuser_type_id: 1\nuser_group: 8\nstatus: 0\noccupation: Owner\ncredit_status: 0\ncredit_limit: \nopening_balance: !ruby/object:BigDecimal 18:0.0\ncreated_at: 2021-09-01 00:26:36.000000000 +05:00\nupdated_at: 2021-09-01 00:26:36.000000000 +05:00\nbalance: !ruby/object:BigDecimal 18:0.0\n','2021-09-01 00:27:00','---\nuser_group:\n- 8\n- 0\ncredit_status:\n- 0\n- 0\nupdated_at:\n- 2021-09-01 00:26:36.000000000 +05:00\n- 2021-09-01 00:27:00.000000000 +05:00\n'),(29,'SysUser',4,'create','192',NULL,'2021-09-01 00:29:30','---\nid:\n- \n- 4\ncode:\n- \n- AGC-0004\ncnic:\n- \n- \'\'\nname:\n- \n- CLAUDIUS COMPTON\nuser_type_id:\n- \n- 1\nuser_group:\n- \n- 0\nstatus:\n- \n- 0\noccupation:\n- \n- Mnagement\ncredit_status:\n- \n- 0\nopening_balance:\n- \n- !ruby/object:BigDecimal 18:0.0\ncreated_at:\n- \n- 2021-09-01 00:29:30.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:29:30.000000000 +05:00\n'),(30,'SysUser',4,'update','192','---\nid: 4\ncode: AGC-0004\ncnic: \'\'\nname: CLAUDIUS COMPTON\nuser_type_id: 1\nuser_group: 0\nstatus: 0\noccupation: Mnagement\ncredit_status: 0\ncredit_limit: \nopening_balance: !ruby/object:BigDecimal 18:0.0\ncreated_at: 2021-09-01 00:29:30.000000000 +05:00\nupdated_at: 2021-09-01 00:29:30.000000000 +05:00\nbalance: \n','2021-09-01 00:29:30','---\nbalance:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(31,'SysUser',5,'create','192',NULL,'2021-09-01 00:31:03','---\nid:\n- \n- 5\ncode:\n- \n- AGC-0005\ncnic:\n- \n- \'\'\nname:\n- \n- DORON YAGHOUBI\nuser_type_id:\n- \n- 1\nuser_group:\n- \n- 0\nstatus:\n- \n- 0\noccupation:\n- \n- Management\ncredit_status:\n- \n- 0\nopening_balance:\n- \n- !ruby/object:BigDecimal 18:0.0\ncreated_at:\n- \n- 2021-09-01 00:31:03.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:31:03.000000000 +05:00\n'),(32,'SysUser',5,'update','192','---\nid: 5\ncode: AGC-0005\ncnic: \'\'\nname: DORON YAGHOUBI\nuser_type_id: 1\nuser_group: 0\nstatus: 0\noccupation: Management\ncredit_status: 0\ncredit_limit: \nopening_balance: !ruby/object:BigDecimal 18:0.0\ncreated_at: 2021-09-01 00:31:03.000000000 +05:00\nupdated_at: 2021-09-01 00:31:03.000000000 +05:00\nbalance: \n','2021-09-01 00:31:03','---\nbalance:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(33,'SysUser',4,'update','192','---\nid: 4\ncode: AGC-0004\ncnic: \'\'\nname: CLAUDIUS COMPTON\nuser_type_id: 1\nuser_group: 0\nstatus: 0\noccupation: Mnagement\ncredit_status: 0\ncredit_limit: \nopening_balance: !ruby/object:BigDecimal 18:0.0\ncreated_at: 2021-09-01 00:29:30.000000000 +05:00\nupdated_at: 2021-09-01 00:29:30.000000000 +05:00\nbalance: !ruby/object:BigDecimal 18:0.0\n','2021-09-01 00:31:24','---\noccupation:\n- Mnagement\n- Management\ncredit_status:\n- 0\n- 0\nupdated_at:\n- 2021-09-01 00:29:30.000000000 +05:00\n- 2021-09-01 00:31:24.000000000 +05:00\n'),(34,'SysUser',2,'update','192','---\nid: 2\ncode: AGC-0002\ncnic: \'\'\nname: Ben Goldfarb\nuser_type_id: 1\nuser_group: 0\nstatus: 0\noccupation: Owner\ncredit_status: 0\ncredit_limit: \nopening_balance: !ruby/object:BigDecimal 18:0.0\ncreated_at: 2021-09-01 00:23:54.000000000 +05:00\nupdated_at: 2021-09-01 00:23:55.000000000 +05:00\nbalance: !ruby/object:BigDecimal 18:0.0\n','2021-09-01 00:31:47','---\nname:\n- Ben Goldfarb\n- BEN GOLDFARB\ncredit_status:\n- 0\n- 0\nupdated_at:\n- 2021-09-01 00:23:55.000000000 +05:00\n- 2021-09-01 00:31:47.000000000 +05:00\n'),(35,'SysUser',1,'update','192','---\nid: 1\ncode: AGC-0001\ncnic: \'\'\nname: \"Gianni Redzic\\t \"\nuser_type_id: 1\nuser_group: 0\nstatus: 0\noccupation: Project manager\ncredit_status: 0\ncredit_limit: \nopening_balance: !ruby/object:BigDecimal 18:0.0\ncreated_at: 2021-09-01 00:18:28.000000000 +05:00\nupdated_at: 2021-09-01 00:18:56.000000000 +05:00\nbalance: !ruby/object:BigDecimal 18:0.0\n','2021-09-01 00:32:13','---\nname:\n- \"Gianni Redzic\\t \"\n- \'GIANNI REDZIC \'\ncredit_status:\n- 0\n- 0\nupdated_at:\n- 2021-09-01 00:18:56.000000000 +05:00\n- 2021-09-01 00:32:13.000000000 +05:00\n'),(36,'Staff',1,'create','192',NULL,'2021-09-01 00:33:26','---\nid:\n- \n- 1\nname:\n- \n- Ghulam Murtaza\nfather:\n- \n- \'\'\neducation:\n- \n- \'\'\nphone:\n- \n- \'7184315203\'\naddress:\n- \n- 309 Deer Road, Ronkonkoma\ncnic:\n- \n- \'\'\nstaff_department:\n- \n- \'\'\ngender:\n- \n- 0\ncreated_at:\n- \n- 2021-09-01 00:33:26.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:33:26.000000000 +05:00\ncode:\n- \n- AGC-0001\nstaff_type:\n- \n- 0\nwage_debit:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(37,'Staff',1,'update','192','---\nid: 1\ncode: AGC-0001\nname: Ghulam Murtaza\nfather: \'\'\neducation: \'\'\ngender: 0\nphone: \'7184315203\'\naddress: 309 Deer Road, Ronkonkoma\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nwage_rate: !ruby/object:BigDecimal 18:0.0\nbalance: !ruby/object:BigDecimal 18:0.0\nstaff_department: \'\'\ndepartment_id: \nstaff_type: 0\nwage_debit: !ruby/object:BigDecimal 18:0.0\nadvance_amount: !ruby/object:BigDecimal 18:0.0\nterminated: false\nterminated_at: 2021-09-01 00:33:26.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-01 00:33:26.000000000 +05:00\ncreated_at: 2021-09-01 00:33:26.000000000 +05:00\nupdated_at: 2021-09-01 00:33:26.000000000 +05:00\ncomment: \nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-01 00:34:29','---\nname:\n- Ghulam Murtaza\n- \'GHULAM MURTAZA \'\nupdated_at:\n- 2021-09-01 00:33:26.000000000 +05:00\n- 2021-09-01 00:34:29.000000000 +05:00\n'),(38,'Staff',2,'create','192',NULL,'2021-09-01 00:35:08','---\nid:\n- \n- 2\nname:\n- \n- MOHAMMED\nfather:\n- \n- \'\'\neducation:\n- \n- MSCE\nphone:\n- \n- \'9292350395\'\naddress:\n- \n- Queens\ncnic:\n- \n- \'\'\nstaff_department:\n- \n- \'\'\ngender:\n- \n- 0\ncreated_at:\n- \n- 2021-09-01 00:35:08.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:35:08.000000000 +05:00\ncode:\n- \n- AGC-0002\nstaff_type:\n- \n- 0\nwage_debit:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(39,'Staff',2,'update','192','---\nid: 2\ncode: AGC-0002\nname: MOHAMMED\nfather: \'\'\neducation: MSCE\ngender: 0\nphone: \'9292350395\'\naddress: Queens\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nwage_rate: !ruby/object:BigDecimal 18:0.0\nbalance: !ruby/object:BigDecimal 18:0.0\nstaff_department: \'\'\ndepartment_id: \nstaff_type: 0\nwage_debit: !ruby/object:BigDecimal 18:0.0\nadvance_amount: !ruby/object:BigDecimal 18:0.0\nterminated: false\nterminated_at: 2021-09-01 00:35:08.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-01 00:35:08.000000000 +05:00\ncreated_at: 2021-09-01 00:35:08.000000000 +05:00\nupdated_at: 2021-09-01 00:35:08.000000000 +05:00\ncomment: \nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-01 00:35:24','---\ndate_of_joining:\n- \n- 2021-08-02\nupdated_at:\n- 2021-09-01 00:35:08.000000000 +05:00\n- 2021-09-01 00:35:24.000000000 +05:00\n'),(40,'Staff',3,'create','192',NULL,'2021-09-01 00:36:25','---\nid:\n- \n- 3\nname:\n- \n- ADDEL ABBAS\nfather:\n- \n- \'\'\neducation:\n- \n- \'\'\nphone:\n- \n- \'9292715559\'\naddress:\n- \n- \'\'\ncnic:\n- \n- \'\'\nstaff_department:\n- \n- \'\'\ngender:\n- \n- 0\ncreated_at:\n- \n- 2021-09-01 00:36:25.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:36:25.000000000 +05:00\ncode:\n- \n- AGC-0003\nstaff_type:\n- \n- 0\nwage_debit:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(41,'Product',3,'create','192',NULL,'2021-09-01 00:38:04','---\nid:\n- \n- 3\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0003\ntitle:\n- \n- Interior Work\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 0\ncreated_at:\n- \n- 2021-09-01 00:38:04.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:38:04.000000000 +05:00\nwith_serial:\n- \n- false\n'),(42,'Product',2,'update','192','---\nid: 2\nitem_type_id: 1\ncode: AGC-0002\ntitle: \" Masonry\"\nproduct_category_id: 1\nproduct_sub_category_id: \nacquire_type: 0\npurchase_type: 0\npurchase_unit: 0\ncost: 0.0\nsale: 0.0\nminimum: \noptimal: \nmaximum: \ncurrency: 0\nstock: 4000000000.0\ngst: 0.0\nvat: 0.0\nhst: 0.0\npst: 0.0\nqst: 0.0\nwith_serial: false\npurchase_factor: \ncomment: \ncreated_at: 2021-08-31 23:44:08.000000000 +05:00\nupdated_at: 2021-08-31 23:45:16.000000000 +05:00\nlocation: \nsize_1: \'0\'\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\nproduct_type: 0\nmeasurement_quantity: \nraw_product_id: \nwarranty_list: \nmarla: \nsquare_feet: \n','2021-09-01 00:38:21','---\ncurrency:\n- 0\n- 1\nupdated_at:\n- 2021-08-31 23:45:16.000000000 +05:00\n- 2021-09-01 00:38:21.000000000 +05:00\n'),(43,'Product',2,'update','192','---\nid: 2\nitem_type_id: 1\ncode: AGC-0002\ntitle: \" Masonry\"\nproduct_category_id: 1\nproduct_sub_category_id: \nacquire_type: 0\npurchase_type: 0\npurchase_unit: 0\ncost: 0.0\nsale: 0.0\nminimum: \noptimal: \nmaximum: \ncurrency: 1\nstock: 4000000000.0\ngst: 0.0\nvat: 0.0\nhst: 0.0\npst: 0.0\nqst: 0.0\nwith_serial: false\npurchase_factor: \ncomment: \ncreated_at: 2021-08-31 23:44:08.000000000 +05:00\nupdated_at: 2021-09-01 00:38:21.000000000 +05:00\nlocation: \nsize_1: \'0\'\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\nproduct_type: 0\nmeasurement_quantity: \nraw_product_id: \nwarranty_list: \nmarla: \nsquare_feet: \n','2021-09-01 00:38:29','---\nstock:\n- 4000000000.0\n- 0.0\nupdated_at:\n- 2021-09-01 00:38:21.000000000 +05:00\n- 2021-09-01 00:38:29.000000000 +05:00\n'),(44,'Product',1,'update','192','---\nid: 1\nitem_type_id: 1\ncode: AGC-0001\ntitle: Roofing\nproduct_category_id: 1\nproduct_sub_category_id: \nacquire_type: 0\npurchase_type: 0\npurchase_unit: 0\ncost: 0.0\nsale: 0.0\nminimum: \noptimal: \nmaximum: \ncurrency: 0\nstock: 4000000000.0\ngst: 0.0\nvat: 0.0\nhst: 0.0\npst: 0.0\nqst: 0.0\nwith_serial: false\npurchase_factor: \ncomment: \ncreated_at: 2021-08-31 23:41:26.000000000 +05:00\nupdated_at: 2021-08-31 23:42:58.000000000 +05:00\nlocation: \nsize_1: \'0\'\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\nproduct_type: 0\nmeasurement_quantity: \nraw_product_id: \nwarranty_list: \nmarla: \nsquare_feet: \n','2021-09-01 00:38:37','---\nstock:\n- 4000000000.0\n- 0.0\nupdated_at:\n- 2021-08-31 23:42:58.000000000 +05:00\n- 2021-09-01 00:38:37.000000000 +05:00\n'),(45,'Product',4,'create','192',NULL,'2021-09-01 00:39:16','---\nid:\n- \n- 4\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0004\ntitle:\n- \n- \" Shingle Roof\"\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 1\ncreated_at:\n- \n- 2021-09-01 00:39:16.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:39:16.000000000 +05:00\nwith_serial:\n- \n- false\n'),(46,'ProductCategory',1,'update','192','---\nid: 1\ntitle: default Category\ncode: default Category\ncomment: \ncreated_at: 2021-08-31 14:04:22.000000000 +05:00\nupdated_at: 2021-08-31 14:04:22.000000000 +05:00\n','2021-09-01 00:39:48','---\ntitle:\n- default Category\n- Default Category\ncode:\n- default Category\n- Default Category\ncomment:\n- \n- \'\'\nupdated_at:\n- 2021-08-31 14:04:22.000000000 +05:00\n- 2021-09-01 00:39:48.000000000 +05:00\n'),(47,'ProductCategory',1,'update','192','---\nid: 1\ntitle: Default Category\ncode: Default Category\ncomment: \'\'\ncreated_at: 2021-08-31 14:04:22.000000000 +05:00\nupdated_at: 2021-09-01 00:39:48.000000000 +05:00\n','2021-09-01 00:40:02','---\ncode:\n- Default Category\n- 000DC\nupdated_at:\n- 2021-09-01 00:39:48.000000000 +05:00\n- 2021-09-01 00:40:02.000000000 +05:00\n'),(48,'Product',5,'create','192',NULL,'2021-09-01 00:41:59','---\nid:\n- \n- 5\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0005\ntitle:\n- \n- New Construction\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 1\ncreated_at:\n- \n- 2021-09-01 00:41:59.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:41:59.000000000 +05:00\nwith_serial:\n- \n- false\n'),(49,'Product',6,'create','192',NULL,'2021-09-01 00:42:27','---\nid:\n- \n- 6\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0006\ntitle:\n- \n- Painting\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 0\ncreated_at:\n- \n- 2021-09-01 00:42:27.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:42:27.000000000 +05:00\nwith_serial:\n- \n- false\n'),(50,'Product',7,'create','192',NULL,'2021-09-01 00:42:52','---\nid:\n- \n- 7\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0007\ntitle:\n- \n- Tile Works\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 1\ncreated_at:\n- \n- 2021-09-01 00:42:52.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:42:52.000000000 +05:00\nwith_serial:\n- \n- false\n'),(51,'Product',8,'create','192',NULL,'2021-09-01 00:43:24','---\nid:\n- \n- 8\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0008\ntitle:\n- \n- Vinyl Siding\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 1\ncreated_at:\n- \n- 2021-09-01 00:43:24.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:43:24.000000000 +05:00\nwith_serial:\n- \n- false\n'),(52,'Product',9,'create','192',NULL,'2021-09-01 00:43:44','---\nid:\n- \n- 9\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0009\ntitle:\n- \n- Gutter Cleaning\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 1\ncreated_at:\n- \n- 2021-09-01 00:43:44.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:43:44.000000000 +05:00\nwith_serial:\n- \n- false\n'),(53,'Product',10,'create','192',NULL,'2021-09-01 00:44:10','---\nid:\n- \n- 10\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0010\ntitle:\n- \n- \" Cold Application Roof\"\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 1\ncreated_at:\n- \n- 2021-09-01 00:44:10.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:44:10.000000000 +05:00\nwith_serial:\n- \n- false\n'),(54,'Product',11,'create','192',NULL,'2021-09-01 00:44:33','---\nid:\n- \n- 11\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0011\ntitle:\n- \n- Waterproofing\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 1\ncreated_at:\n- \n- 2021-09-01 00:44:33.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:44:33.000000000 +05:00\nwith_serial:\n- \n- false\n'),(55,'Product',12,'create','192',NULL,'2021-09-01 00:44:56','---\nid:\n- \n- 12\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0012\ntitle:\n- \n- Paving\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 1\ncreated_at:\n- \n- 2021-09-01 00:44:56.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:44:56.000000000 +05:00\nwith_serial:\n- \n- false\n'),(56,'Product',13,'create','192',NULL,'2021-09-01 00:45:41','---\nid:\n- \n- 13\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0013\ntitle:\n- \n- \" Waterproof  Thorocoat\"\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 1\ncreated_at:\n- \n- 2021-09-01 00:45:41.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:45:41.000000000 +05:00\nwith_serial:\n- \n- false\n'),(57,'Product',14,'create','192',NULL,'2021-09-01 00:46:20','---\nid:\n- \n- 14\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0014\ntitle:\n- \n- Scaffolding\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 1\ncreated_at:\n- \n- 2021-09-01 00:46:20.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:46:20.000000000 +05:00\nwith_serial:\n- \n- false\n'),(58,'Product',15,'create','192',NULL,'2021-09-01 00:46:48','---\nid:\n- \n- 15\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0015\ntitle:\n- \n- Fire Stone Rubber Roof\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 1\ncreated_at:\n- \n- 2021-09-01 00:46:48.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:46:48.000000000 +05:00\nwith_serial:\n- \n- false\n'),(59,'Product',16,'create','192',NULL,'2021-09-01 00:47:13','---\nid:\n- \n- 16\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0016\ntitle:\n- \n- \" Window Replacement \\t\"\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 1\ncreated_at:\n- \n- 2021-09-01 00:47:13.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:47:13.000000000 +05:00\nwith_serial:\n- \n- false\n'),(60,'Product',17,'create','192',NULL,'2021-09-01 00:47:43','---\nid:\n- \n- 17\nitem_type_id:\n- \n- 1\ncode:\n- \n- AGC-0017\ntitle:\n- \n- Waterproof Thoroseal\nproduct_category_id:\n- \n- 1\nacquire_type:\n- \n- 0\npurchase_type:\n- \n- 0\npurchase_unit:\n- \n- 0\ncost:\n- \n- 0.0\nsale:\n- \n- 0.0\ncurrency:\n- \n- 1\ncreated_at:\n- \n- 2021-09-01 00:47:43.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 00:47:43.000000000 +05:00\nwith_serial:\n- \n- false\n'),(61,'SysUser',3,'update','192','---\nid: 3\ncode: AGC-0003\ncnic: \'\'\nname: Sami Suhail\nuser_type_id: 1\nuser_group: 0\nstatus: 0\noccupation: Owner\ncredit_status: 0\ncredit_limit: \nopening_balance: !ruby/object:BigDecimal 18:0.0\ncreated_at: 2021-09-01 00:26:36.000000000 +05:00\nupdated_at: 2021-09-01 00:27:00.000000000 +05:00\nbalance: !ruby/object:BigDecimal 18:0.0\n','2021-09-01 01:11:31','---\ncredit_status:\n- 0\n- 0\nupdated_at:\n- 2021-09-01 00:27:00.000000000 +05:00\n- 2021-09-01 01:11:31.000000000 +05:00\n'),(62,'SysUser',3,'update','192','---\nid: 3\ncode: AGC-0003\ncnic: \'\'\nname: Sami Suhail\nuser_type_id: 1\nuser_group: 0\nstatus: 0\noccupation: Owner\ncredit_status: 0\ncredit_limit: \nopening_balance: !ruby/object:BigDecimal 18:0.0\ncreated_at: 2021-09-01 00:26:36.000000000 +05:00\nupdated_at: 2021-09-01 01:11:31.000000000 +05:00\nbalance: !ruby/object:BigDecimal 18:0.0\n','2021-09-01 01:11:44','---\nname:\n- Sami Suhail\n- SAMI SUHAIL\ncredit_status:\n- 0\n- 0\nupdated_at:\n- 2021-09-01 01:11:31.000000000 +05:00\n- 2021-09-01 01:11:44.000000000 +05:00\n'),(63,'User',192,'update',NULL,'---\nencrypted_password: \"$2a$11$FcErLWjlKdOZtpcByWOrS.o.7nQpa4fZuIdeWISeGEsSG2BmjD466\"\nid: 192\nremember_created_at: \nemail: alarsh_super_admin@gmail.com\nreset_password_token: \nreset_password_sent_at: \nsign_in_count: 0\ncurrent_sign_in_at: \nlast_sign_in_at: \nfailed_attempts: 0\nunlock_token: \nlocked_at: \ncreated_at: 2021-08-31 18:49:17.000000000 +05:00\nupdated_at: 2021-08-31 23:49:48.000000000 +05:00\nroles_mask: 2\nname: SuperAdmin\nuser_name: alarsh_super_admin\nfather_name: \ncity: \nphone: \nfax: \naddress: \ncreated_by_id: 99\ncompany_type: alarsh\nemail_to: \nemail_cc: \nemail_bcc: \n','2021-09-01 23:17:45','---\nremember_created_at:\n- \n- 2021-09-01 23:17:45.000000000 +05:00\nupdated_at:\n- 2021-08-31 23:49:48.000000000 +05:00\n- 2021-09-01 23:17:45.000000000 +05:00\n'),(64,'ExpenseType',1,'update','192','---\nid: 1\ntitle: Expense\ncomment: \ncreated_at: 2021-08-31 14:04:22.000000000 +05:00\nupdated_at: 2021-08-31 14:04:22.000000000 +05:00\n','2021-09-01 23:23:46','---\ntitle:\n- Expense\n- Al-Arsh\ncomment:\n- \n- \'\'\nupdated_at:\n- 2021-08-31 14:04:22.000000000 +05:00\n- 2021-09-01 23:23:46.000000000 +05:00\n'),(65,'ExpenseType',1,'update','192','---\nid: 1\ntitle: Al-Arsh\ncomment: \'\'\ncreated_at: 2021-08-31 14:04:22.000000000 +05:00\nupdated_at: 2021-09-01 23:23:46.000000000 +05:00\n','2021-09-01 23:24:54','---\ntitle:\n- Al-Arsh\n- Stationary\nupdated_at:\n- 2021-09-01 23:23:46.000000000 +05:00\n- 2021-09-01 23:24:54.000000000 +05:00\n'),(66,'ExpenseType',2,'create','192',NULL,'2021-09-01 23:25:23','---\nid:\n- \n- 2\ntitle:\n- \n- Food\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-01 23:25:23.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 23:25:23.000000000 +05:00\n'),(67,'ExpenseType',3,'create','192',NULL,'2021-09-01 23:25:31','---\nid:\n- \n- 3\ntitle:\n- \n- Gas\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-01 23:25:31.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 23:25:31.000000000 +05:00\n'),(68,'ExpenseType',4,'create','192',NULL,'2021-09-01 23:25:40','---\nid:\n- \n- 4\ntitle:\n- \n- Insurance\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-01 23:25:40.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 23:25:40.000000000 +05:00\n'),(69,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:0.0\nid: 1\ntitle: Comapny Cash\nbank_name: \niban_number: \ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-08-31 14:04:23.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-01 23:30:42','---\namount:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:-0.1e2\nupdated_at:\n- 2021-08-31 14:04:23.000000000 +05:00\n- 2021-09-01 23:30:42.000000000 +05:00\n'),(70,'Payment',2,'update','192','---\nid: 2\ndebit: !ruby/object:BigDecimal 18:0.1e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 1\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-01 23:30:42.000000000 +05:00\nupdated_at: 2021-09-01 23:30:42.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-01 23:30:42','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.1e2\n'),(71,'Payment',2,'create','192',NULL,'2021-09-01 23:30:42','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.1e2\n'),(72,'ExpenseEntry',1,'create','192',NULL,'2021-09-01 23:30:42','---\nid:\n- \n- 1\namount:\n- \n- 10.0\nexpense_id:\n- \n- 1\nexpense_type_id:\n- \n- 1\naccount_id:\n- \n- 1\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-01 23:30:42.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 23:30:42.000000000 +05:00\n'),(73,'Expense',1,'create','192',NULL,'2021-09-01 23:30:42','---\nid:\n- \n- 1\nexpense:\n- \n- 10.0\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-01 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 23:30:42.000000000 +05:00\n'),(74,'Account',1,'update','192','---\nid: 1\ntitle: Comapny Cash\nbank_name: \niban_number: \namount: !ruby/object:BigDecimal 18:-0.1e2\nuser_id: \ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-01 23:30:42.000000000 +05:00\ncomment: \n','2021-09-01 23:30:53','---\ntitle:\n- Comapny Cash\n- Company Cash\nbank_name:\n- \n- \'\'\niban_number:\n- \n- \'\'\nupdated_at:\n- 2021-09-01 23:30:42.000000000 +05:00\n- 2021-09-01 23:30:53.000000000 +05:00\n'),(75,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.1e2\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-01 23:30:53.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-01 23:31:19','---\namount:\n- !ruby/object:BigDecimal 18:-0.1e2\n- !ruby/object:BigDecimal 18:-0.6e2\nupdated_at:\n- 2021-09-01 23:30:53.000000000 +05:00\n- 2021-09-01 23:31:19.000000000 +05:00\n'),(76,'Payment',3,'update','192','---\nid: 3\ndebit: !ruby/object:BigDecimal 18:0.5e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 2\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-01 23:31:19.000000000 +05:00\nupdated_at: 2021-09-01 23:31:19.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-01 23:31:19','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.6e2\n'),(77,'Payment',3,'create','192',NULL,'2021-09-01 23:31:19','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.6e2\n'),(78,'ExpenseEntry',2,'create','192',NULL,'2021-09-01 23:31:19','---\nid:\n- \n- 2\namount:\n- \n- 50.0\nexpense_id:\n- \n- 1\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 1\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-01 23:31:19.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 23:31:19.000000000 +05:00\n'),(79,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.6e2\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-01 23:31:19.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-01 23:31:19','---\namount:\n- !ruby/object:BigDecimal 18:-0.6e2\n- !ruby/object:BigDecimal 18:-0.125e3\n'),(80,'Payment',4,'update','192','---\nid: 4\ndebit: !ruby/object:BigDecimal 18:0.65e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 3\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-01 23:31:19.000000000 +05:00\nupdated_at: 2021-09-01 23:31:19.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-01 23:31:19','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.125e3\n'),(81,'Payment',4,'create','192',NULL,'2021-09-01 23:31:19','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.125e3\n'),(82,'ExpenseEntry',3,'create','192',NULL,'2021-09-01 23:31:19','---\nid:\n- \n- 3\namount:\n- \n- 65.0\nexpense_id:\n- \n- 1\nexpense_type_id:\n- \n- 3\naccount_id:\n- \n- 1\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-01 23:31:19.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 23:31:19.000000000 +05:00\n'),(83,'Expense',1,'update','192','---\nid: 1\nexpense: 10.0\ncomment: \'\'\ncreated_at: 2021-09-01 00:00:00.000000000 +05:00\nexpense_type_id: \nupdated_at: 2021-09-01 23:30:42.000000000 +05:00\naccount_id: \n','2021-09-01 23:31:19','---\nexpense:\n- 10.0\n- 125.0\nupdated_at:\n- 2021-09-01 23:30:42.000000000 +05:00\n- 2021-09-01 23:31:19.000000000 +05:00\n'),(84,'ExpenseEntry',1,'update','192','---\nexpense_id: 1\nid: 1\namount: 10.0\ncomment: \'\'\naccount_id: 1\nexpense_type_id: 1\nstatus: \ncreated_at: 2021-09-01 23:30:42.000000000 +05:00\nupdated_at: 2021-09-01 23:30:42.000000000 +05:00\nexpenseable_type: \nexpenseable_id: \n','2021-09-01 23:31:45','---\ncomment:\n- \'\'\n- Notepad\nupdated_at:\n- 2021-09-01 23:30:42.000000000 +05:00\n- 2021-09-01 23:31:45.000000000 +05:00\n'),(85,'ExpenseEntry',2,'update','192','---\nexpense_id: 1\nid: 2\namount: 50.0\ncomment: \'\'\naccount_id: 1\nexpense_type_id: 2\nstatus: \ncreated_at: 2021-09-01 23:31:19.000000000 +05:00\nupdated_at: 2021-09-01 23:31:19.000000000 +05:00\nexpenseable_type: \nexpenseable_id: \n','2021-09-01 23:31:45','---\ncomment:\n- \'\'\n- Lunch\nupdated_at:\n- 2021-09-01 23:31:19.000000000 +05:00\n- 2021-09-01 23:31:45.000000000 +05:00\n'),(86,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.125e3\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-01 23:31:19.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-01 23:35:46','---\namount:\n- !ruby/object:BigDecimal 18:-0.125e3\n- !ruby/object:BigDecimal 18:-0.115e3\nupdated_at:\n- 2021-09-01 23:31:19.000000000 +05:00\n- 2021-09-01 23:35:46.000000000 +05:00\n'),(87,'Payment',2,'destroy','192','---\nid: 2\ndebit: !ruby/object:BigDecimal 18:0.1e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 1\namount: !ruby/object:BigDecimal 18:-0.1e2\nstatus: \ncomment: Edited Expense\ncreated_at: 2021-09-01 23:30:42.000000000 +05:00\nupdated_at: 2021-09-01 23:30:42.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-01 23:35:46','---\nid:\n- 2\n- \ndebit:\n- !ruby/object:BigDecimal 18:0.1e2\n- \ncredit:\n- \n- \naccount_id:\n- 1\n- \npaymentable_type:\n- ExpenseEntry\n- \npaymentable_id:\n- 1\n- \namount:\n- !ruby/object:BigDecimal 18:-0.1e2\n- \nstatus:\n- \n- \ncomment:\n- Edited Expense\n- \ncreated_at:\n- 2021-09-01 23:30:42.000000000 +05:00\n- \nupdated_at:\n- 2021-09-01 23:30:42.000000000 +05:00\n- \nconfirmable:\n- \n- \nconfirmed_by:\n- \n- \nconfirmed_at:\n- \n- \n'),(88,'ExpenseEntry',1,'destroy','192','---\nid: 1\namount: 10.0\nexpense_id: 1\nexpense_type_id: 1\naccount_id: 1\ncomment: Notepad\nstatus: \ncreated_at: 2021-09-01 23:30:42.000000000 +05:00\nupdated_at: 2021-09-01 23:31:45.000000000 +05:00\nexpenseable_type: \nexpenseable_id: \n','2021-09-01 23:35:46','---\nid:\n- 1\n- \namount:\n- 10.0\n- \nexpense_id:\n- 1\n- \nexpense_type_id:\n- 1\n- \naccount_id:\n- 1\n- \ncomment:\n- Notepad\n- \nstatus:\n- \n- \ncreated_at:\n- 2021-09-01 23:30:42.000000000 +05:00\n- \nupdated_at:\n- 2021-09-01 23:31:45.000000000 +05:00\n- \nexpenseable_type:\n- \n- \nexpenseable_id:\n- \n- \n'),(89,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.115e3\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-01 23:35:46.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-01 23:35:46','---\namount:\n- !ruby/object:BigDecimal 18:-0.115e3\n- !ruby/object:BigDecimal 18:-0.65e2\n'),(90,'Payment',3,'destroy','192','---\nid: 3\ndebit: !ruby/object:BigDecimal 18:0.5e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 2\namount: !ruby/object:BigDecimal 18:-0.6e2\nstatus: \ncomment: Edited Expense\ncreated_at: 2021-09-01 23:31:19.000000000 +05:00\nupdated_at: 2021-09-01 23:31:19.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-01 23:35:46','---\nid:\n- 3\n- \ndebit:\n- !ruby/object:BigDecimal 18:0.5e2\n- \ncredit:\n- \n- \naccount_id:\n- 1\n- \npaymentable_type:\n- ExpenseEntry\n- \npaymentable_id:\n- 2\n- \namount:\n- !ruby/object:BigDecimal 18:-0.6e2\n- \nstatus:\n- \n- \ncomment:\n- Edited Expense\n- \ncreated_at:\n- 2021-09-01 23:31:19.000000000 +05:00\n- \nupdated_at:\n- 2021-09-01 23:31:19.000000000 +05:00\n- \nconfirmable:\n- \n- \nconfirmed_by:\n- \n- \nconfirmed_at:\n- \n- \n'),(91,'ExpenseEntry',2,'destroy','192','---\nid: 2\namount: 50.0\nexpense_id: 1\nexpense_type_id: 2\naccount_id: 1\ncomment: Lunch\nstatus: \ncreated_at: 2021-09-01 23:31:19.000000000 +05:00\nupdated_at: 2021-09-01 23:31:45.000000000 +05:00\nexpenseable_type: \nexpenseable_id: \n','2021-09-01 23:35:46','---\nid:\n- 2\n- \namount:\n- 50.0\n- \nexpense_id:\n- 1\n- \nexpense_type_id:\n- 2\n- \naccount_id:\n- 1\n- \ncomment:\n- Lunch\n- \nstatus:\n- \n- \ncreated_at:\n- 2021-09-01 23:31:19.000000000 +05:00\n- \nupdated_at:\n- 2021-09-01 23:31:45.000000000 +05:00\n- \nexpenseable_type:\n- \n- \nexpenseable_id:\n- \n- \n'),(92,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.65e2\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-01 23:35:46.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-01 23:35:46','---\namount:\n- !ruby/object:BigDecimal 18:-0.65e2\n- !ruby/object:BigDecimal 18:0.0\n'),(93,'Payment',4,'destroy','192','---\nid: 4\ndebit: !ruby/object:BigDecimal 18:0.65e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 3\namount: !ruby/object:BigDecimal 18:-0.125e3\nstatus: \ncomment: Expense\ncreated_at: 2021-09-01 23:31:19.000000000 +05:00\nupdated_at: 2021-09-01 23:31:19.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-01 23:35:46','---\nid:\n- 4\n- \ndebit:\n- !ruby/object:BigDecimal 18:0.65e2\n- \ncredit:\n- \n- \naccount_id:\n- 1\n- \npaymentable_type:\n- ExpenseEntry\n- \npaymentable_id:\n- 3\n- \namount:\n- !ruby/object:BigDecimal 18:-0.125e3\n- \nstatus:\n- \n- \ncomment:\n- Expense\n- \ncreated_at:\n- 2021-09-01 23:31:19.000000000 +05:00\n- \nupdated_at:\n- 2021-09-01 23:31:19.000000000 +05:00\n- \nconfirmable:\n- \n- \nconfirmed_by:\n- \n- \nconfirmed_at:\n- \n- \n'),(94,'ExpenseEntry',3,'destroy','192','---\nid: 3\namount: 65.0\nexpense_id: 1\nexpense_type_id: 3\naccount_id: 1\ncomment: \'\'\nstatus: \ncreated_at: 2021-09-01 23:31:19.000000000 +05:00\nupdated_at: 2021-09-01 23:31:19.000000000 +05:00\nexpenseable_type: \nexpenseable_id: \n','2021-09-01 23:35:46','---\nid:\n- 3\n- \namount:\n- 65.0\n- \nexpense_id:\n- 1\n- \nexpense_type_id:\n- 3\n- \naccount_id:\n- 1\n- \ncomment:\n- \'\'\n- \nstatus:\n- \n- \ncreated_at:\n- 2021-09-01 23:31:19.000000000 +05:00\n- \nupdated_at:\n- 2021-09-01 23:31:19.000000000 +05:00\n- \nexpenseable_type:\n- \n- \nexpenseable_id:\n- \n- \n'),(95,'Expense',1,'destroy','192','---\nid: 1\nexpense: 125.0\ncomment: \'\'\nexpense_type_id: \ncreated_at: 2021-09-01 00:00:00.000000000 +05:00\nupdated_at: 2021-09-01 23:31:19.000000000 +05:00\naccount_id: \n','2021-09-01 23:35:46','---\nid:\n- 1\n- \nexpense:\n- 125.0\n- \ncomment:\n- \'\'\n- \nexpense_type_id:\n- \n- \ncreated_at:\n- 2021-09-01 00:00:00.000000000 +05:00\n- \nupdated_at:\n- 2021-09-01 23:31:19.000000000 +05:00\n- \naccount_id:\n- \n- \n'),(96,'PurchaseSaleItem',1,'update','192','---\nid: 1\npurchase_sale_detail_id: 1\nitem_id: \nquantity: 1.0\ncost_price: \nsale_price: 15200.0\ntotal_cost_price: \ntotal_sale_price: 15200.0\nstatus: \ncomment: \'100000\'\ncreated_at: 2021-09-01 23:37:24.000000000 +05:00\nupdated_at: 2021-09-01 23:37:24.000000000 +05:00\nproduct_id: 1\ntransaction_type: 1\nsize_1: \'0\'\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\ndiscount_price: 0.0\npurchase_sale_type: 0\nexpiry_date: \nremaining_quantity: \nextra_expence: \nextra_quantity: 99999.0\ngst: \ngst_amount: \n','2021-09-01 23:37:24','---\ncost_price:\n- \n- 0.0\ntotal_cost_price:\n- \n- 0.0\n'),(97,'Product',1,'update','192','---\ncost: 0.0\nstock: 100000.0\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\nid: 1\nproduct_category_id: 1\nitem_type_id: 1\ncode: AGC-0001\ntitle: Roofing\nproduct_sub_category_id: \nacquire_type: 0\npurchase_type: 0\npurchase_unit: 0\npurchase_factor: \nsale: 0.0\nminimum: \noptimal: \nmaximum: \ncurrency: 0\ncomment: \ncreated_at: 2021-08-31 23:41:26.000000000 +05:00\nupdated_at: 2021-09-01 00:38:37.000000000 +05:00\nlocation: \nsize_1: \'0\'\nproduct_type: 0\nmeasurement_quantity: \nraw_product_id: \ngst: 0.0\nvat: 0.0\nhst: 0.0\npst: 0.0\nqst: 0.0\nwith_serial: false\nwarranty_list: \nmarla: \nsquare_feet: \n','2021-09-01 23:37:24','---\nstock:\n- 100000.0\n- 99999.0\nupdated_at:\n- 2021-09-01 00:38:37.000000000 +05:00\n- 2021-09-01 23:37:24.000000000 +05:00\n'),(98,'PurchaseSaleItem',1,'create','192',NULL,'2021-09-01 23:37:24','---\ncost_price:\n- \n- 0.0\ntotal_cost_price:\n- \n- 0.0\n'),(99,'PurchaseSaleItem',2,'update','192','---\nid: 2\npurchase_sale_detail_id: 1\nitem_id: \nquantity: 1.0\ncost_price: \nsale_price: 10000.0\ntotal_cost_price: \ntotal_sale_price: 10000.0\nstatus: \ncomment: \'100000\'\ncreated_at: 2021-09-01 23:37:24.000000000 +05:00\nupdated_at: 2021-09-01 23:37:24.000000000 +05:00\nproduct_id: 4\ntransaction_type: 1\nsize_1: \'0\'\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\ndiscount_price: 0.0\npurchase_sale_type: 0\nexpiry_date: \nremaining_quantity: \nextra_expence: \nextra_quantity: 99999.0\ngst: \ngst_amount: \n','2021-09-01 23:37:24','---\ncost_price:\n- \n- 0.0\ntotal_cost_price:\n- \n- 0.0\n'),(100,'Product',4,'update','192','---\ncost: 0.0\nstock: 100000.0\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\nid: 4\nproduct_category_id: 1\nitem_type_id: 1\ncode: AGC-0004\ntitle: \" Shingle Roof\"\nproduct_sub_category_id: \nacquire_type: 0\npurchase_type: 0\npurchase_unit: 0\npurchase_factor: \nsale: 0.0\nminimum: \noptimal: \nmaximum: \ncurrency: 1\ncomment: \ncreated_at: 2021-09-01 00:39:16.000000000 +05:00\nupdated_at: 2021-09-01 00:39:16.000000000 +05:00\nlocation: \nsize_1: \'0\'\nproduct_type: 0\nmeasurement_quantity: \nraw_product_id: \ngst: 0.0\nvat: 0.0\nhst: 0.0\npst: 0.0\nqst: 0.0\nwith_serial: false\nwarranty_list: \nmarla: \nsquare_feet: \n','2021-09-01 23:37:24','---\nstock:\n- 100000.0\n- 99999.0\nupdated_at:\n- 2021-09-01 00:39:16.000000000 +05:00\n- 2021-09-01 23:37:24.000000000 +05:00\n'),(101,'PurchaseSaleItem',2,'create','192',NULL,'2021-09-01 23:37:24','---\ncost_price:\n- \n- 0.0\ntotal_cost_price:\n- \n- 0.0\n'),(102,'PurchaseSaleItem',3,'update','192','---\nid: 3\npurchase_sale_detail_id: 1\nitem_id: \nquantity: 1.0\ncost_price: \nsale_price: 15000.0\ntotal_cost_price: \ntotal_sale_price: 15000.0\nstatus: \ncomment: \'100000\'\ncreated_at: 2021-09-01 23:37:24.000000000 +05:00\nupdated_at: 2021-09-01 23:37:24.000000000 +05:00\nproduct_id: 6\ntransaction_type: 1\nsize_1: \'0\'\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\ndiscount_price: 0.0\npurchase_sale_type: 0\nexpiry_date: \nremaining_quantity: \nextra_expence: \nextra_quantity: 99999.0\ngst: \ngst_amount: \n','2021-09-01 23:37:24','---\ncost_price:\n- \n- 0.0\ntotal_cost_price:\n- \n- 0.0\n'),(103,'Product',6,'update','192','---\ncost: 0.0\nstock: 100000.0\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\nid: 6\nproduct_category_id: 1\nitem_type_id: 1\ncode: AGC-0006\ntitle: Painting\nproduct_sub_category_id: \nacquire_type: 0\npurchase_type: 0\npurchase_unit: 0\npurchase_factor: \nsale: 0.0\nminimum: \noptimal: \nmaximum: \ncurrency: 0\ncomment: \ncreated_at: 2021-09-01 00:42:27.000000000 +05:00\nupdated_at: 2021-09-01 00:42:27.000000000 +05:00\nlocation: \nsize_1: \'0\'\nproduct_type: 0\nmeasurement_quantity: \nraw_product_id: \ngst: 0.0\nvat: 0.0\nhst: 0.0\npst: 0.0\nqst: 0.0\nwith_serial: false\nwarranty_list: \nmarla: \nsquare_feet: \n','2021-09-01 23:37:24','---\nstock:\n- 100000.0\n- 99999.0\nupdated_at:\n- 2021-09-01 00:42:27.000000000 +05:00\n- 2021-09-01 23:37:24.000000000 +05:00\n'),(104,'PurchaseSaleItem',3,'create','192',NULL,'2021-09-01 23:37:24','---\ncost_price:\n- \n- 0.0\ntotal_cost_price:\n- \n- 0.0\n'),(105,'PurchaseSaleDetail',1,'create','192',NULL,'2021-09-01 23:37:24','---\nid:\n- \n- 1\nsys_user_id:\n- \n- 3\ntransaction_type:\n- \n- 1\ntotal_bill:\n- \n- 40200.0\nstatus:\n- \n- 0\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-01 23:36:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 23:37:24.000000000 +05:00\nvoucher_id:\n- \n- 1\naccount_id:\n- \n- 1\nbill_no:\n- \n- \'\'\nuser_name:\n- \n- SuperAdmin\ndestination:\n- \n- \'\'\nl_c:\n- \n- \'\'\ng_d:\n- \n- \'\'\ng_d_type:\n- \n- \'\'\ng_d_date:\n- \n- 2021-09-01 23:36:00.000000000 +05:00\nquantity:\n- \n- \'\'\ndispatched_to:\n- \n- \'\'\ndespatch_date:\n- \n- 2021-09-01 23:36:00.000000000 +05:00\njob_no:\n- \n- \'\'\nreference_no:\n- \n- \'\'\ncompany_name:\n- \n- WHITE WAY Enterprise\n'),(106,'Payment',5,'update','192','---\nid: 5\ndebit: \ncredit: !ruby/object:BigDecimal 18:0.0\naccount_id: 1\npaymentable_type: PurchaseSaleDetail\npaymentable_id: 1\namount: \nstatus: \ncomment: \'Voucher #1  ||  01/Sep/21 at 11:36PM\'\ncreated_at: 2021-09-01 23:37:24.000000000 +05:00\nupdated_at: 2021-09-01 23:37:24.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-01 23:37:24','---\namount:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(107,'Payment',5,'create','192',NULL,'2021-09-01 23:37:24','---\namount:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(108,'Product',1,'update','192','---\ncost: 0.0\nstock: 99999.0\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\nid: 1\nproduct_category_id: 1\nitem_type_id: 1\ncode: AGC-0001\ntitle: Roofing\nproduct_sub_category_id: \nacquire_type: 0\npurchase_type: 0\npurchase_unit: 0\npurchase_factor: \nsale: 0.0\nminimum: \noptimal: \nmaximum: \ncurrency: 0\ncomment: \ncreated_at: 2021-08-31 23:41:26.000000000 +05:00\nupdated_at: 2021-09-01 23:37:24.000000000 +05:00\nlocation: \nsize_1: \'0\'\nproduct_type: 0\nmeasurement_quantity: \nraw_product_id: \ngst: 0.0\nvat: 0.0\nhst: 0.0\npst: 0.0\nqst: 0.0\nwith_serial: false\nwarranty_list: \nmarla: \nsquare_feet: \n','2021-09-01 23:37:25','---\nupdated_at:\n- 2021-09-01 23:37:24.000000000 +05:00\n- 2021-09-01 23:37:25.000000000 +05:00\nwarranty_list:\n- \n- \'\'\n'),(109,'Product',4,'update','192','---\ncost: 0.0\nstock: 99999.0\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\nid: 4\nproduct_category_id: 1\nitem_type_id: 1\ncode: AGC-0004\ntitle: \" Shingle Roof\"\nproduct_sub_category_id: \nacquire_type: 0\npurchase_type: 0\npurchase_unit: 0\npurchase_factor: \nsale: 0.0\nminimum: \noptimal: \nmaximum: \ncurrency: 1\ncomment: \ncreated_at: 2021-09-01 00:39:16.000000000 +05:00\nupdated_at: 2021-09-01 23:37:24.000000000 +05:00\nlocation: \nsize_1: \'0\'\nproduct_type: 0\nmeasurement_quantity: \nraw_product_id: \ngst: 0.0\nvat: 0.0\nhst: 0.0\npst: 0.0\nqst: 0.0\nwith_serial: false\nwarranty_list: \nmarla: \nsquare_feet: \n','2021-09-01 23:37:25','---\nupdated_at:\n- 2021-09-01 23:37:24.000000000 +05:00\n- 2021-09-01 23:37:25.000000000 +05:00\nwarranty_list:\n- \n- \'\'\n'),(110,'Product',6,'update','192','---\ncost: 0.0\nstock: 99999.0\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\nid: 6\nproduct_category_id: 1\nitem_type_id: 1\ncode: AGC-0006\ntitle: Painting\nproduct_sub_category_id: \nacquire_type: 0\npurchase_type: 0\npurchase_unit: 0\npurchase_factor: \nsale: 0.0\nminimum: \noptimal: \nmaximum: \ncurrency: 0\ncomment: \ncreated_at: 2021-09-01 00:42:27.000000000 +05:00\nupdated_at: 2021-09-01 23:37:24.000000000 +05:00\nlocation: \nsize_1: \'0\'\nproduct_type: 0\nmeasurement_quantity: \nraw_product_id: \ngst: 0.0\nvat: 0.0\nhst: 0.0\npst: 0.0\nqst: 0.0\nwith_serial: false\nwarranty_list: \nmarla: \nsquare_feet: \n','2021-09-01 23:37:25','---\nupdated_at:\n- 2021-09-01 23:37:24.000000000 +05:00\n- 2021-09-01 23:37:25.000000000 +05:00\nwarranty_list:\n- \n- \'\'\n'),(111,'SysUser',3,'update','192','---\nopening_balance: !ruby/object:BigDecimal 18:0.0\nid: 3\nbalance: !ruby/object:BigDecimal 18:0.0\nuser_type_id: 1\ncode: AGC-0003\ncnic: \'\'\nname: SAMI SUHAIL\nuser_group: 0\nstatus: 0\noccupation: Owner\ncredit_status: 0\ncredit_limit: \ncreated_at: 2021-09-01 00:26:36.000000000 +05:00\nupdated_at: 2021-09-01 01:11:44.000000000 +05:00\n','2021-09-01 23:37:25','---\nbalance:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:-0.402e5\nupdated_at:\n- 2021-09-01 01:11:44.000000000 +05:00\n- 2021-09-01 23:37:25.000000000 +05:00\n'),(112,'LedgerBook',1,'create','192',NULL,'2021-09-01 23:37:25','---\nid:\n- \n- 1\nsys_user_id:\n- \n- 3\ndebit:\n- \n- !ruby/object:BigDecimal 18:0.402e5\ncredit:\n- \n- !ruby/object:BigDecimal 18:0.0\nbalance:\n- \n- !ruby/object:BigDecimal 18:-0.402e5\ncomment:\n- \n- \'Voucher #1  ||  1/9/2021 at 11:37PM\'\ncreated_at:\n- \n- 2021-09-01 23:37:25.000000000 +05:00\nupdated_at:\n- \n- 2021-09-01 23:37:25.000000000 +05:00\npurchase_sale_detail_id:\n- \n- 1\n'),(113,'PosSetting',1,'update','192','---\nid: 1\nname: Al-Arsh Construction Corp\ndisplay_name: Al-Arsh Construction Corp\nphone: \'7184315203\'\naccount_id: 1\naddress: 309 Deer Road, Ronkonkoma NY 11779\nsys_type: 8\ninvoice_note: \'\'\npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: \'\'\nheader: true\nfooter: true\nheader_logo_placement: logo_disable_text_center\nlogo_hieght: \'200\'\nlogo_width: \'200\'\nheader_hieght: \'50\'\nmulti_language: false\ntitle_padding: \'10\'\nfooter_address_placement: center\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nupdated_at: 2021-08-31 23:35:01.000000000 +05:00\npurchase_sale_detail_show_line_height: 20\n','2021-09-01 23:40:15','---\nsys_type:\n- 8\n- 4\nupdated_at:\n- 2021-08-31 23:35:01.000000000 +05:00\n- 2021-09-01 23:40:15.000000000 +05:00\n'),(114,'PurchaseSaleDetail',1,'update','192','---\nid: 1\ncarriage: 0.0\nloading: 0.0\nsys_user_id: 3\ntransaction_type: 1\ntotal_bill: 40200.0\namount: \ndiscount_price: \nstatus: 0\ncomment: \'\'\naccount_id: 1\norder_id: \nbill_no: \'\'\ncreated_at: 2021-09-01 23:36:00.000000000 +05:00\nupdated_at: 2021-09-01 23:37:24.000000000 +05:00\nvoucher_id: 1\nstaff_id: \nuser_name: SuperAdmin\ndestination: \'\'\nl_c: \'\'\ng_d: \'\'\ng_d_type: \'\'\ng_d_date: 2021-09-01 23:36:00.000000000 +05:00\nquantity: \'\'\ndispatched_to: \'\'\ndespatch_date: 2021-09-01 23:36:00.000000000 +05:00\njob_no: \'\'\nreference_no: \'\'\ncompany_name: WHITE WAY Enterprise\nwith_gst: \n','2021-09-01 23:41:52','---\namount:\n- \n- 0.0\nupdated_at:\n- 2021-09-01 23:37:24.000000000 +05:00\n- 2021-09-01 23:41:52.000000000 +05:00\n'),(115,'LedgerBook',1,'update','192','---\npurchase_sale_detail_id: 1\nid: 1\nsys_user_id: 3\ndebit: !ruby/object:BigDecimal 18:0.402e5\ncredit: !ruby/object:BigDecimal 18:0.0\naccount_id: \nbalance: !ruby/object:BigDecimal 18:-0.402e5\ncomment: \'Voucher #1  ||  1/9/2021 at 11:37PM\'\ncreated_at: 2021-09-01 23:37:25.000000000 +05:00\nupdated_at: 2021-09-01 23:37:25.000000000 +05:00\norder_id: \nstatus: \n','2021-09-01 23:41:52','---\naccount_id:\n- \n- 1\nupdated_at:\n- 2021-09-01 23:37:25.000000000 +05:00\n- 2021-09-01 23:41:52.000000000 +05:00\n'),(116,'PosSetting',1,'update','192','---\nid: 1\nname: Al-Arsh Construction Corp\ndisplay_name: Al-Arsh Construction Corp\nphone: \'7184315203\'\naccount_id: 1\naddress: 309 Deer Road, Ronkonkoma NY 11779\nsys_type: 4\ninvoice_note: \'\'\npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: \'\'\nheader: true\nfooter: true\nheader_logo_placement: logo_disable_text_center\nlogo_hieght: \'200\'\nlogo_width: \'200\'\nheader_hieght: \'50\'\nmulti_language: false\ntitle_padding: \'10\'\nfooter_address_placement: center\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nupdated_at: 2021-09-01 23:40:15.000000000 +05:00\npurchase_sale_detail_show_line_height: 20\n','2021-09-01 23:43:11','---\nsys_type:\n- 4\n- 8\nupdated_at:\n- 2021-09-01 23:40:15.000000000 +05:00\n- 2021-09-01 23:43:11.000000000 +05:00\n'),(117,'PurchaseSaleDetail',1,'update','192','---\nid: 1\ncarriage: 0.0\nloading: 0.0\nsys_user_id: 3\ntransaction_type: 1\ntotal_bill: 40200.0\namount: 0.0\ndiscount_price: \nstatus: 0\ncomment: \'\'\naccount_id: 1\nbill_no: \'\'\ndestination: \'\'\nl_c: \'\'\ng_d: \'\'\ng_d_type: \'\'\nquantity: \'\'\ndispatched_to: \'\'\njob_no: \'\'\nreference_no: \'\'\ncompany_name: WHITE WAY Enterprise\ncreated_at: 2021-09-01 23:36:00.000000000 +05:00\ng_d_date: 2021-09-01 23:36:00.000000000 +05:00\ndespatch_date: 2021-09-01 23:36:00.000000000 +05:00\nupdated_at: 2021-09-01 23:41:52.000000000 +05:00\nvoucher_id: 1\norder_id: \nstaff_id: \nuser_name: SuperAdmin\nwith_gst: \n','2021-09-01 23:45:38','---\namount:\n- 0.0\n- 20000.0\nbill_no:\n- \'\'\n- \'00\'\njob_no:\n- \'\'\n- \'00\'\nreference_no:\n- \'\'\n- \'00\'\nupdated_at:\n- 2021-09-01 23:41:52.000000000 +05:00\n- 2021-09-01 23:45:38.000000000 +05:00\n'),(118,'Payment',5,'update','192','---\ncredit: !ruby/object:BigDecimal 18:0.2e5\ndebit: \namount: !ruby/object:BigDecimal 18:0.0\nid: 5\naccount_id: 1\npaymentable_type: PurchaseSaleDetail\npaymentable_id: 1\nstatus: \ncomment: Edit Sale\ncreated_at: 2021-09-01 23:37:24.000000000 +05:00\nupdated_at: 2021-09-01 23:37:24.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-01 23:45:38','---\namount:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:0.2e5\nupdated_at:\n- 2021-09-01 23:37:24.000000000 +05:00\n- 2021-09-01 23:45:38.000000000 +05:00\n'),(119,'Account',1,'update','192','---\nid: 1\namount: !ruby/object:BigDecimal 18:0.0\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-01 23:35:46.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-01 23:45:38','---\namount:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:0.2e5\nupdated_at:\n- 2021-09-01 23:35:46.000000000 +05:00\n- 2021-09-01 23:45:38.000000000 +05:00\n'),(120,'SysUser',3,'update','192','---\nopening_balance: !ruby/object:BigDecimal 18:0.0\nid: 3\nbalance: !ruby/object:BigDecimal 18:-0.402e5\nuser_type_id: 1\ncode: AGC-0003\ncnic: \'\'\nname: SAMI SUHAIL\nuser_group: 0\nstatus: 0\noccupation: Owner\ncredit_status: 0\ncredit_limit: \ncreated_at: 2021-09-01 00:26:36.000000000 +05:00\nupdated_at: 2021-09-01 23:37:25.000000000 +05:00\n','2021-09-01 23:45:38','---\nbalance:\n- !ruby/object:BigDecimal 18:-0.402e5\n- !ruby/object:BigDecimal 18:-0.202e5\nupdated_at:\n- 2021-09-01 23:37:25.000000000 +05:00\n- 2021-09-01 23:45:38.000000000 +05:00\n'),(121,'LedgerBook',1,'update','192','---\npurchase_sale_detail_id: 1\nid: 1\nsys_user_id: 3\ndebit: !ruby/object:BigDecimal 18:0.402e5\ncredit: !ruby/object:BigDecimal 18:0.0\naccount_id: 1\nbalance: !ruby/object:BigDecimal 18:-0.402e5\ncomment: \'Voucher #1  ||  1/9/2021 at 11:37PM\'\ncreated_at: 2021-09-01 23:37:25.000000000 +05:00\nupdated_at: 2021-09-01 23:41:52.000000000 +05:00\norder_id: \nstatus: \n','2021-09-01 23:45:38','---\ncredit:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:0.2e5\nupdated_at:\n- 2021-09-01 23:41:52.000000000 +05:00\n- 2021-09-01 23:45:38.000000000 +05:00\n'),(122,'LedgerBook',1,'update','192','---\ncredit: !ruby/object:BigDecimal 18:0.2e5\ndebit: !ruby/object:BigDecimal 18:0.402e5\nbalance: !ruby/object:BigDecimal 18:-0.402e5\nid: 1\nsys_user_id: 3\ncomment: \'Voucher #1  ||  1/9/2021 at 11:37PM\'\ncreated_at: 2021-09-01 23:37:25.000000000 +05:00\nupdated_at: 2021-09-01 23:45:38.000000000 +05:00\npurchase_sale_detail_id: 1\naccount_id: 1\norder_id: \nstatus: \n','2021-09-01 23:45:38','---\nbalance:\n- !ruby/object:BigDecimal 18:-0.402e5\n- !ruby/object:BigDecimal 18:-0.202e5\n'),(123,'PosSetting',1,'update','192','---\nid: 1\nname: Al-Arsh Construction Corp\ndisplay_name: Al-Arsh Construction Corp\nphone: \'7184315203\'\naccount_id: 1\naddress: 309 Deer Road, Ronkonkoma NY 11779\nsys_type: 8\ninvoice_note: \'\'\npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: \'\'\nheader: true\nfooter: true\nheader_logo_placement: logo_disable_text_center\nlogo_hieght: \'200\'\nlogo_width: \'200\'\nheader_hieght: \'50\'\nmulti_language: false\ntitle_padding: \'10\'\nfooter_address_placement: center\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nupdated_at: 2021-09-01 23:43:11.000000000 +05:00\npurchase_sale_detail_show_line_height: 20\n','2021-09-01 23:46:30','---\nsys_type:\n- 8\n- 4\nupdated_at:\n- 2021-09-01 23:43:11.000000000 +05:00\n- 2021-09-01 23:46:30.000000000 +05:00\n'),(124,'User',192,'update','192','---\nid: 192\nname: SuperAdmin\nuser_name: alarsh_super_admin\nfather_name: \ncity: \nphone: \nfax: \naddress: \ncreated_by_id: 99\nemail_to: \nemail_cc: \nemail_bcc: \nemail: alarsh_super_admin@gmail.com\nencrypted_password: \"$2a$11$FcErLWjlKdOZtpcByWOrS.o.7nQpa4fZuIdeWISeGEsSG2BmjD466\"\nreset_password_token: \nreset_password_sent_at: \nremember_created_at: 2021-09-01 23:17:45.000000000 +05:00\nsign_in_count: 0\ncurrent_sign_in_at: \nlast_sign_in_at: \nfailed_attempts: 0\nunlock_token: \nlocked_at: \ncreated_at: 2021-08-31 18:49:17.000000000 +05:00\nupdated_at: 2021-09-01 23:17:45.000000000 +05:00\nroles_mask: 2\ncompany_type: alarsh\n','2021-09-01 23:50:56','---\nfather_name:\n- \n- \'\'\ncity:\n- \n- Ronkonkoma\nphone:\n- \n- \'7184315203\'\nfax:\n- \n- \'\'\naddress:\n- \n- 309 Deer Road\nemail_to:\n- \n- alarshny@yahoo.com,info@alarshconstruction.com\nemail_cc:\n- \n- info@alarshconstruction.com\nemail_bcc:\n- \n- alarshny@yahoo.com\nupdated_at:\n- 2021-09-01 23:17:45.000000000 +05:00\n- 2021-09-01 23:50:56.000000000 +05:00\n'),(125,'Staff',4,'create','192',NULL,'2021-09-02 00:34:06','---\nid:\n- \n- 4\nname:\n- \n- Kuldeep\nfather:\n- \n- Singh\neducation:\n- \n- \'\'\nphone:\n- \n- \'\'\naddress:\n- \n- \'\'\ncnic:\n- \n- \'\'\nstaff_department:\n- \n- \'\'\ngender:\n- \n- 0\ncreated_at:\n- \n- 2021-09-02 00:34:06.000000000 +05:00\nupdated_at:\n- \n- 2021-09-02 00:34:06.000000000 +05:00\ncode:\n- \n- AGC-0004\nstaff_type:\n- \n- 0\nwage_debit:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(126,'PurchaseSaleItem',1,'destroy','192','---\nid: 1\npurchase_sale_detail_id: 1\nitem_id: \nquantity: 1.0\ncost_price: 0.0\nsale_price: 15200.0\ntotal_cost_price: 0.0\ntotal_sale_price: 15200.0\nstatus: \ncomment: \'100000\'\ncreated_at: 2021-09-01 23:37:24.000000000 +05:00\nupdated_at: 2021-09-01 23:37:24.000000000 +05:00\nproduct_id: 1\ntransaction_type: 1\nsize_1: \'0\'\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\ndiscount_price: 0.0\npurchase_sale_type: 0\nexpiry_date: \nremaining_quantity: \nextra_expence: \nextra_quantity: 99999.0\ngst: \ngst_amount: \n','2021-09-02 11:27:51','---\nid:\n- 1\n- \npurchase_sale_detail_id:\n- 1\n- \nitem_id:\n- \n- \nquantity:\n- 1.0\n- \ncost_price:\n- 0.0\n- \nsale_price:\n- 15200.0\n- \ntotal_cost_price:\n- 0.0\n- \ntotal_sale_price:\n- 15200.0\n- \nstatus:\n- \n- \ncomment:\n- \'100000\'\n- \ncreated_at:\n- 2021-09-01 23:37:24.000000000 +05:00\n- \nupdated_at:\n- 2021-09-01 23:37:24.000000000 +05:00\n- \nproduct_id:\n- 1\n- \ntransaction_type:\n- 1\n- \nsize_1:\n- \'0\'\n- \nsize_2:\n- \'0\'\n- \nsize_3:\n- \'0\'\n- \nsize_4:\n- \'0\'\n- \nsize_5:\n- \'0\'\n- \nsize_6:\n- \'0\'\n- \nsize_7:\n- \'0\'\n- \nsize_8:\n- \'0\'\n- \nsize_9:\n- \'0\'\n- \nsize_10:\n- \'0\'\n- \nsize_11:\n- \'0\'\n- \nsize_12:\n- \'0\'\n- \nsize_13:\n- \'0\'\n- \ndiscount_price:\n- 0.0\n- \npurchase_sale_type:\n- 0\n- \nexpiry_date:\n- \n- \nremaining_quantity:\n- \n- \nextra_expence:\n- \n- \nextra_quantity:\n- 99999.0\n- \ngst:\n- \n- \ngst_amount:\n- \n- \n'),(127,'Product',1,'update','192','---\nstock: 99999.0\ncost: 0.0\nid: 1\nproduct_category_id: 1\nitem_type_id: 1\ncode: AGC-0001\ntitle: Roofing\nproduct_sub_category_id: \nacquire_type: 0\npurchase_type: 0\npurchase_unit: 0\npurchase_factor: \nsale: 0.0\nminimum: \noptimal: \nmaximum: \ncurrency: 0\ncomment: \ncreated_at: 2021-08-31 23:41:26.000000000 +05:00\nupdated_at: 2021-09-01 23:37:25.000000000 +05:00\nlocation: \nsize_1: \'0\'\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\nproduct_type: 0\nmeasurement_quantity: \nraw_product_id: \ngst: 0.0\nvat: 0.0\nhst: 0.0\npst: 0.0\nqst: 0.0\nwith_serial: false\nwarranty_list: \'\'\nmarla: \nsquare_feet: \n','2021-09-02 11:27:51','---\nstock:\n- 99999.0\n- 100000.0\nupdated_at:\n- 2021-09-01 23:37:25.000000000 +05:00\n- 2021-09-02 11:27:51.000000000 +05:00\n'),(128,'PurchaseSaleItem',2,'destroy','192','---\nid: 2\npurchase_sale_detail_id: 1\nitem_id: \nquantity: 1.0\ncost_price: 0.0\nsale_price: 10000.0\ntotal_cost_price: 0.0\ntotal_sale_price: 10000.0\nstatus: \ncomment: \'100000\'\ncreated_at: 2021-09-01 23:37:24.000000000 +05:00\nupdated_at: 2021-09-01 23:37:24.000000000 +05:00\nproduct_id: 4\ntransaction_type: 1\nsize_1: \'0\'\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\ndiscount_price: 0.0\npurchase_sale_type: 0\nexpiry_date: \nremaining_quantity: \nextra_expence: \nextra_quantity: 99999.0\ngst: \ngst_amount: \n','2021-09-02 11:27:51','---\nid:\n- 2\n- \npurchase_sale_detail_id:\n- 1\n- \nitem_id:\n- \n- \nquantity:\n- 1.0\n- \ncost_price:\n- 0.0\n- \nsale_price:\n- 10000.0\n- \ntotal_cost_price:\n- 0.0\n- \ntotal_sale_price:\n- 10000.0\n- \nstatus:\n- \n- \ncomment:\n- \'100000\'\n- \ncreated_at:\n- 2021-09-01 23:37:24.000000000 +05:00\n- \nupdated_at:\n- 2021-09-01 23:37:24.000000000 +05:00\n- \nproduct_id:\n- 4\n- \ntransaction_type:\n- 1\n- \nsize_1:\n- \'0\'\n- \nsize_2:\n- \'0\'\n- \nsize_3:\n- \'0\'\n- \nsize_4:\n- \'0\'\n- \nsize_5:\n- \'0\'\n- \nsize_6:\n- \'0\'\n- \nsize_7:\n- \'0\'\n- \nsize_8:\n- \'0\'\n- \nsize_9:\n- \'0\'\n- \nsize_10:\n- \'0\'\n- \nsize_11:\n- \'0\'\n- \nsize_12:\n- \'0\'\n- \nsize_13:\n- \'0\'\n- \ndiscount_price:\n- 0.0\n- \npurchase_sale_type:\n- 0\n- \nexpiry_date:\n- \n- \nremaining_quantity:\n- \n- \nextra_expence:\n- \n- \nextra_quantity:\n- 99999.0\n- \ngst:\n- \n- \ngst_amount:\n- \n- \n'),(129,'Product',4,'update','192','---\nstock: 99999.0\ncost: 0.0\nid: 4\nproduct_category_id: 1\nitem_type_id: 1\ncode: AGC-0004\ntitle: \" Shingle Roof\"\nproduct_sub_category_id: \nacquire_type: 0\npurchase_type: 0\npurchase_unit: 0\npurchase_factor: \nsale: 0.0\nminimum: \noptimal: \nmaximum: \ncurrency: 1\ncomment: \ncreated_at: 2021-09-01 00:39:16.000000000 +05:00\nupdated_at: 2021-09-01 23:37:25.000000000 +05:00\nlocation: \nsize_1: \'0\'\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\nproduct_type: 0\nmeasurement_quantity: \nraw_product_id: \ngst: 0.0\nvat: 0.0\nhst: 0.0\npst: 0.0\nqst: 0.0\nwith_serial: false\nwarranty_list: \'\'\nmarla: \nsquare_feet: \n','2021-09-02 11:27:51','---\nstock:\n- 99999.0\n- 100000.0\nupdated_at:\n- 2021-09-01 23:37:25.000000000 +05:00\n- 2021-09-02 11:27:51.000000000 +05:00\n'),(130,'PurchaseSaleItem',3,'destroy','192','---\nid: 3\npurchase_sale_detail_id: 1\nitem_id: \nquantity: 1.0\ncost_price: 0.0\nsale_price: 15000.0\ntotal_cost_price: 0.0\ntotal_sale_price: 15000.0\nstatus: \ncomment: \'100000\'\ncreated_at: 2021-09-01 23:37:24.000000000 +05:00\nupdated_at: 2021-09-01 23:37:24.000000000 +05:00\nproduct_id: 6\ntransaction_type: 1\nsize_1: \'0\'\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\ndiscount_price: 0.0\npurchase_sale_type: 0\nexpiry_date: \nremaining_quantity: \nextra_expence: \nextra_quantity: 99999.0\ngst: \ngst_amount: \n','2021-09-02 11:27:51','---\nid:\n- 3\n- \npurchase_sale_detail_id:\n- 1\n- \nitem_id:\n- \n- \nquantity:\n- 1.0\n- \ncost_price:\n- 0.0\n- \nsale_price:\n- 15000.0\n- \ntotal_cost_price:\n- 0.0\n- \ntotal_sale_price:\n- 15000.0\n- \nstatus:\n- \n- \ncomment:\n- \'100000\'\n- \ncreated_at:\n- 2021-09-01 23:37:24.000000000 +05:00\n- \nupdated_at:\n- 2021-09-01 23:37:24.000000000 +05:00\n- \nproduct_id:\n- 6\n- \ntransaction_type:\n- 1\n- \nsize_1:\n- \'0\'\n- \nsize_2:\n- \'0\'\n- \nsize_3:\n- \'0\'\n- \nsize_4:\n- \'0\'\n- \nsize_5:\n- \'0\'\n- \nsize_6:\n- \'0\'\n- \nsize_7:\n- \'0\'\n- \nsize_8:\n- \'0\'\n- \nsize_9:\n- \'0\'\n- \nsize_10:\n- \'0\'\n- \nsize_11:\n- \'0\'\n- \nsize_12:\n- \'0\'\n- \nsize_13:\n- \'0\'\n- \ndiscount_price:\n- 0.0\n- \npurchase_sale_type:\n- 0\n- \nexpiry_date:\n- \n- \nremaining_quantity:\n- \n- \nextra_expence:\n- \n- \nextra_quantity:\n- 99999.0\n- \ngst:\n- \n- \ngst_amount:\n- \n- \n'),(131,'Product',6,'update','192','---\nstock: 99999.0\ncost: 0.0\nid: 6\nproduct_category_id: 1\nitem_type_id: 1\ncode: AGC-0006\ntitle: Painting\nproduct_sub_category_id: \nacquire_type: 0\npurchase_type: 0\npurchase_unit: 0\npurchase_factor: \nsale: 0.0\nminimum: \noptimal: \nmaximum: \ncurrency: 0\ncomment: \ncreated_at: 2021-09-01 00:42:27.000000000 +05:00\nupdated_at: 2021-09-01 23:37:25.000000000 +05:00\nlocation: \nsize_1: \'0\'\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\nproduct_type: 0\nmeasurement_quantity: \nraw_product_id: \ngst: 0.0\nvat: 0.0\nhst: 0.0\npst: 0.0\nqst: 0.0\nwith_serial: false\nwarranty_list: \'\'\nmarla: \nsquare_feet: \n','2021-09-02 11:27:51','---\nstock:\n- 99999.0\n- 100000.0\nupdated_at:\n- 2021-09-01 23:37:25.000000000 +05:00\n- 2021-09-02 11:27:51.000000000 +05:00\n'),(132,'LedgerBook',1,'destroy','192','---\nid: 1\nsys_user_id: 3\ndebit: !ruby/object:BigDecimal 18:0.402e5\ncredit: !ruby/object:BigDecimal 18:0.2e5\nbalance: !ruby/object:BigDecimal 18:-0.202e5\ncomment: \'Voucher #1  ||  1/9/2021 at 11:37PM\'\ncreated_at: 2021-09-01 23:37:25.000000000 +05:00\nupdated_at: 2021-09-01 23:45:38.000000000 +05:00\npurchase_sale_detail_id: 1\naccount_id: 1\norder_id: \nstatus: \n','2021-09-02 11:27:51','---\nid:\n- 1\n- \nsys_user_id:\n- 3\n- \ndebit:\n- !ruby/object:BigDecimal 18:0.402e5\n- \ncredit:\n- !ruby/object:BigDecimal 18:0.2e5\n- \nbalance:\n- !ruby/object:BigDecimal 18:-0.202e5\n- \ncomment:\n- \'Voucher #1  ||  1/9/2021 at 11:37PM\'\n- \ncreated_at:\n- 2021-09-01 23:37:25.000000000 +05:00\n- \nupdated_at:\n- 2021-09-01 23:45:38.000000000 +05:00\n- \npurchase_sale_detail_id:\n- 1\n- \naccount_id:\n- 1\n- \norder_id:\n- \n- \nstatus:\n- \n- \n'),(133,'SysUser',3,'update','192','---\nopening_balance: !ruby/object:BigDecimal 18:0.0\nid: 3\nbalance: !ruby/object:BigDecimal 18:-0.202e5\nuser_type_id: 1\ncode: AGC-0003\ncnic: \'\'\nname: SAMI SUHAIL\nuser_group: 0\nstatus: 0\noccupation: Owner\ncredit_status: 0\ncredit_limit: \ncreated_at: 2021-09-01 00:26:36.000000000 +05:00\nupdated_at: 2021-09-01 23:45:38.000000000 +05:00\n','2021-09-02 11:27:51','---\nbalance:\n- !ruby/object:BigDecimal 18:-0.202e5\n- !ruby/object:BigDecimal 18:0.0\nupdated_at:\n- 2021-09-01 23:45:38.000000000 +05:00\n- 2021-09-02 11:27:51.000000000 +05:00\n'),(134,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:0.2e5\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-01 23:45:38.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-02 11:27:51','---\namount:\n- !ruby/object:BigDecimal 18:0.2e5\n- !ruby/object:BigDecimal 18:0.0\nupdated_at:\n- 2021-09-01 23:45:38.000000000 +05:00\n- 2021-09-02 11:27:51.000000000 +05:00\n'),(135,'Payment',5,'destroy','192','---\nid: 5\ndebit: \ncredit: !ruby/object:BigDecimal 18:0.2e5\naccount_id: 1\npaymentable_type: PurchaseSaleDetail\npaymentable_id: 1\namount: !ruby/object:BigDecimal 18:0.2e5\nstatus: \ncomment: Edit Sale\ncreated_at: 2021-09-01 23:37:24.000000000 +05:00\nupdated_at: 2021-09-01 23:45:38.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-02 11:27:51','---\nid:\n- 5\n- \ndebit:\n- \n- \ncredit:\n- !ruby/object:BigDecimal 18:0.2e5\n- \naccount_id:\n- 1\n- \npaymentable_type:\n- PurchaseSaleDetail\n- \npaymentable_id:\n- 1\n- \namount:\n- !ruby/object:BigDecimal 18:0.2e5\n- \nstatus:\n- \n- \ncomment:\n- Edit Sale\n- \ncreated_at:\n- 2021-09-01 23:37:24.000000000 +05:00\n- \nupdated_at:\n- 2021-09-01 23:45:38.000000000 +05:00\n- \nconfirmable:\n- \n- \nconfirmed_by:\n- \n- \nconfirmed_at:\n- \n- \n'),(136,'PurchaseSaleDetail',1,'destroy','192','---\nid: 1\nsys_user_id: 3\ntransaction_type: 1\ntotal_bill: 40200.0\namount: 20000.0\ndiscount_price: \nstatus: 0\ncomment: \'\'\ncreated_at: 2021-09-01 23:36:00.000000000 +05:00\nupdated_at: 2021-09-01 23:45:38.000000000 +05:00\nvoucher_id: 1\naccount_id: 1\ncarriage: 0.0\nloading: 0.0\norder_id: \nstaff_id: \nbill_no: \'00\'\nuser_name: SuperAdmin\ndestination: \'\'\nl_c: \'\'\ng_d: \'\'\ng_d_type: \'\'\ng_d_date: 2021-09-01 23:36:00.000000000 +05:00\nquantity: \'\'\ndispatched_to: \'\'\ndespatch_date: 2021-09-01 23:36:00.000000000 +05:00\njob_no: \'00\'\nreference_no: \'00\'\ncompany_name: WHITE WAY Enterprise\nwith_gst: \n','2021-09-02 11:27:51','---\nid:\n- 1\n- \nsys_user_id:\n- 3\n- \ntransaction_type:\n- 1\n- \ntotal_bill:\n- 40200.0\n- \namount:\n- 20000.0\n- \ndiscount_price:\n- \n- \nstatus:\n- 0\n- \ncomment:\n- \'\'\n- \ncreated_at:\n- 2021-09-01 23:36:00.000000000 +05:00\n- \nupdated_at:\n- 2021-09-01 23:45:38.000000000 +05:00\n- \nvoucher_id:\n- 1\n- \naccount_id:\n- 1\n- \ncarriage:\n- 0.0\n- \nloading:\n- 0.0\n- \norder_id:\n- \n- \nstaff_id:\n- \n- \nbill_no:\n- \'00\'\n- \nuser_name:\n- SuperAdmin\n- \ndestination:\n- \'\'\n- \nl_c:\n- \'\'\n- \ng_d:\n- \'\'\n- \ng_d_type:\n- \'\'\n- \ng_d_date:\n- 2021-09-01 23:36:00.000000000 +05:00\n- \nquantity:\n- \'\'\n- \ndispatched_to:\n- \'\'\n- \ndespatch_date:\n- 2021-09-01 23:36:00.000000000 +05:00\n- \njob_no:\n- \'00\'\n- \nreference_no:\n- \'00\'\n- \ncompany_name:\n- WHITE WAY Enterprise\n- \nwith_gst:\n- \n- \n'),(137,'ExpenseType',5,'create','192',NULL,'2021-09-02 22:22:53','---\nid:\n- \n- 5\ntitle:\n- \n- License\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-02 22:22:53.000000000 +05:00\nupdated_at:\n- \n- 2021-09-02 22:22:53.000000000 +05:00\n'),(138,'Staff',5,'create','192',NULL,'2021-09-06 19:47:20','---\nid:\n- \n- 5\nname:\n- \n- Mason-1\nfather:\n- \n- \'\'\neducation:\n- \n- \'\'\nphone:\n- \n- \'\'\naddress:\n- \n- \'\'\ncnic:\n- \n- \'\'\nstaff_department:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-06 19:47:20.000000000 +05:00\nupdated_at:\n- \n- 2021-09-06 19:47:20.000000000 +05:00\ncode:\n- \n- AGC-0005\nstaff_type:\n- \n- 0\nwage_debit:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(139,'Staff',5,'update','192','---\nid: 5\ncode: AGC-0005\nname: Mason-1\nfather: \'\'\neducation: \'\'\ngender: \nphone: \'\'\naddress: \'\'\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nwage_rate: !ruby/object:BigDecimal 18:0.0\nbalance: !ruby/object:BigDecimal 18:0.0\nstaff_department: \'\'\ndepartment_id: \nstaff_type: 0\nwage_debit: !ruby/object:BigDecimal 18:0.0\nadvance_amount: !ruby/object:BigDecimal 18:0.0\nterminated: false\nterminated_at: 2021-09-06 19:47:20.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-06 19:47:20.000000000 +05:00\ncreated_at: 2021-09-06 19:47:20.000000000 +05:00\nupdated_at: 2021-09-06 19:47:20.000000000 +05:00\ncomment: \nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-06 19:47:47','---\ngender:\n- \n- 0\nupdated_at:\n- 2021-09-06 19:47:20.000000000 +05:00\n- 2021-09-06 19:47:47.000000000 +05:00\n'),(140,'Product',2,'update','192','---\nstock: 100000.0\nid: 2\nproduct_category_id: 1\nitem_type_id: 1\ncode: AGC-0002\ntitle: \" Masonry\"\nproduct_sub_category_id: \nacquire_type: 0\npurchase_type: 0\npurchase_unit: 0\npurchase_factor: \ncost: 0.0\nsale: 0.0\nminimum: \noptimal: \nmaximum: \ncurrency: 1\ncomment: \ncreated_at: 2021-08-31 23:44:08.000000000 +05:00\nupdated_at: 2021-09-01 00:38:29.000000000 +05:00\nlocation: \nsize_1: \'0\'\nsize_2: \'0\'\nsize_3: \'0\'\nsize_4: \'0\'\nsize_5: \'0\'\nsize_6: \'0\'\nsize_7: \'0\'\nsize_8: \'0\'\nsize_9: \'0\'\nsize_10: \'0\'\nsize_11: \'0\'\nsize_12: \'0\'\nsize_13: \'0\'\nproduct_type: 0\nmeasurement_quantity: \nraw_product_id: \ngst: 0.0\nvat: 0.0\nhst: 0.0\npst: 0.0\nqst: 0.0\nwith_serial: false\nwarranty_list: \nmarla: \nsquare_feet: \n','2021-09-06 19:48:48','---\nstock:\n- 100000.0\n- 100001.0\nupdated_at:\n- 2021-09-01 00:38:29.000000000 +05:00\n- 2021-09-06 19:48:48.000000000 +05:00\n'),(141,'Staff',5,'update','192','---\nbalance: !ruby/object:BigDecimal 18:0.0\nwage_debit: !ruby/object:BigDecimal 18:0.0\nid: 5\ncode: AGC-0005\nname: Mason-1\nfather: \'\'\neducation: \'\'\nphone: \'\'\naddress: \'\'\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nstaff_department: \'\'\ngender: 0\nadvance_amount: !ruby/object:BigDecimal 18:0.0\nterminated: false\nterminated_at: 2021-09-06 19:47:20.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-06 19:47:20.000000000 +05:00\ncreated_at: 2021-09-06 19:47:20.000000000 +05:00\nupdated_at: 2021-09-06 19:47:47.000000000 +05:00\nwage_rate: !ruby/object:BigDecimal 18:0.0\ncomment: \ndepartment_id: \nstaff_type: 0\nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-06 19:48:48','---\nbalance:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:0.25e3\nwage_debit:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:0.25e3\nupdated_at:\n- 2021-09-06 19:47:47.000000000 +05:00\n- 2021-09-06 19:48:48.000000000 +05:00\n'),(142,'StaffLedgerBook',1,'create','192',NULL,'2021-09-06 19:48:48','---\nid:\n- \n- 1\nstaff_id:\n- \n- 5\nsalary_detail_id:\n- \n- 1\ncredit:\n- \n- !ruby/object:BigDecimal 18:0.25e3\nbalance:\n- \n- !ruby/object:BigDecimal 18:0.25e3\ncreated_at:\n- \n- 2021-09-06 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-06 19:48:48.000000000 +05:00\n'),(143,'SalaryDetail',1,'create','192',NULL,'2021-09-06 19:48:48','---\nid:\n- \n- 1\nstaff_id:\n- \n- 5\nwage_rate:\n- \n- 250.0\nquantity:\n- \n- 1.0\namount:\n- \n- 250.0\nremarks:\n- \n- \'250.0\'\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-06 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-06 19:48:48.000000000 +05:00\nproduct_id:\n- \n- 2\nstatus:\n- \n- 1\n'),(144,'PosSetting',1,'update','192','---\nid: 1\nname: Al-Arsh Construction Corp\ndisplay_name: Al-Arsh Construction Corp\nphone: \'7184315203\'\naccount_id: 1\naddress: 309 Deer Road, Ronkonkoma NY 11779\ninvoice_note: \'\'\npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: \'\'\nheader: true\nfooter: true\nheader_logo_placement: logo_disable_text_center\nlogo_hieght: \'200\'\nlogo_width: \'200\'\nheader_hieght: \'50\'\nmulti_language: false\ntitle_padding: \'10\'\nfooter_address_placement: center\nupdated_at: 2021-09-06 21:43:46.000000000 +05:00\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nsys_type: 4\npurchase_sale_detail_show_line_height: 20\n','2021-09-06 21:43:46',NULL),(145,'PosSetting',1,'update','192','---\nid: 1\nname: Al-Arsh Construction Corp\ndisplay_name: Al-Arsh Construction Corp\nphone: \'7184315203\'\naccount_id: 1\naddress: 309 Deer Road, Ronkonkoma NY 11779\ninvoice_note: \'\'\npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: \'\'\nheader: true\nfooter: true\nheader_logo_placement: logo_disable_text_center\nlogo_hieght: \'200\'\nlogo_width: \'200\'\nheader_hieght: \'50\'\nmulti_language: false\ntitle_padding: \'10\'\nfooter_address_placement: center\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nupdated_at: 2021-09-06 21:43:46.000000000 +05:00\nsys_type: 4\npurchase_sale_detail_show_line_height: 20\n','2021-09-06 21:44:18','---\nlogo_width:\n- \'200\'\n- \'300\'\nupdated_at:\n- 2021-09-06 21:43:46.000000000 +05:00\n- 2021-09-06 21:44:18.000000000 +05:00\n'),(146,'Staff',5,'update','192','---\nid: 5\ncode: AGC-0005\nname: Mason-1\nfather: \'\'\neducation: \'\'\ngender: 0\nphone: \'\'\naddress: \'\'\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nwage_rate: !ruby/object:BigDecimal 18:0.0\nbalance: !ruby/object:BigDecimal 18:0.25e3\nstaff_department: \'\'\ndepartment_id: \nstaff_type: 0\nwage_debit: !ruby/object:BigDecimal 18:0.25e3\nadvance_amount: !ruby/object:BigDecimal 18:0.0\nterminated: false\nterminated_at: 2021-09-06 19:47:20.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-06 19:47:20.000000000 +05:00\ncreated_at: 2021-09-06 19:47:20.000000000 +05:00\nupdated_at: 2021-09-06 19:48:48.000000000 +05:00\ncomment: \nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-06 21:45:58','---\nwage_rate:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:0.25e3\nbalance:\n- !ruby/object:BigDecimal 18:0.25e3\n- !ruby/object:BigDecimal 18:0.0\nupdated_at:\n- 2021-09-06 19:48:48.000000000 +05:00\n- 2021-09-06 21:45:58.000000000 +05:00\n'),(147,'Staff',5,'update','192','---\nid: 5\ncode: AGC-0005\nname: Mason-1\nfather: \'\'\neducation: \'\'\ngender: 0\nphone: \'\'\naddress: \'\'\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nwage_rate: !ruby/object:BigDecimal 18:0.25e3\nbalance: !ruby/object:BigDecimal 18:0.0\nstaff_department: \'\'\ndepartment_id: \nstaff_type: 0\nwage_debit: !ruby/object:BigDecimal 18:0.25e3\nadvance_amount: !ruby/object:BigDecimal 18:0.0\nterminated: false\nterminated_at: 2021-09-06 19:47:20.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-06 19:47:20.000000000 +05:00\ncreated_at: 2021-09-06 19:47:20.000000000 +05:00\nupdated_at: 2021-09-06 21:45:58.000000000 +05:00\ncomment: \nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-06 21:47:27','---\nbalance:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:0.25e3\nupdated_at:\n- 2021-09-06 21:45:58.000000000 +05:00\n- 2021-09-06 21:47:27.000000000 +05:00\n'),(148,'Staff',5,'update','192','---\nid: 5\ncode: AGC-0005\nname: Mason-1\nfather: \'\'\neducation: \'\'\ngender: 0\nphone: \'\'\naddress: \'\'\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nwage_rate: !ruby/object:BigDecimal 18:0.25e3\nbalance: !ruby/object:BigDecimal 18:0.25e3\nstaff_department: \'\'\ndepartment_id: \nstaff_type: 0\nwage_debit: !ruby/object:BigDecimal 18:0.25e3\nadvance_amount: !ruby/object:BigDecimal 18:0.0\nterminated: false\nterminated_at: 2021-09-06 19:47:20.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-06 19:47:20.000000000 +05:00\ncreated_at: 2021-09-06 19:47:20.000000000 +05:00\nupdated_at: 2021-09-06 21:47:27.000000000 +05:00\ncomment: \nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-06 21:47:58','---\nbalance:\n- !ruby/object:BigDecimal 18:0.25e3\n- !ruby/object:BigDecimal 18:0.0\nwage_debit:\n- !ruby/object:BigDecimal 18:0.25e3\n- !ruby/object:BigDecimal 18:0.0\nupdated_at:\n- 2021-09-06 21:47:27.000000000 +05:00\n- 2021-09-06 21:47:58.000000000 +05:00\n'),(149,'Staff',5,'update','192','---\nbalance: !ruby/object:BigDecimal 18:0.0\nwage_debit: !ruby/object:BigDecimal 18:0.0\nid: 5\ncode: AGC-0005\nname: Mason-1\nfather: \'\'\neducation: \'\'\nphone: \'\'\naddress: \'\'\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nstaff_department: \'\'\ngender: 0\nadvance_amount: !ruby/object:BigDecimal 18:0.0\nterminated: false\nterminated_at: 2021-09-06 19:47:20.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-06 19:47:20.000000000 +05:00\ncreated_at: 2021-09-06 19:47:20.000000000 +05:00\nupdated_at: 2021-09-06 21:47:58.000000000 +05:00\nwage_rate: !ruby/object:BigDecimal 18:0.25e3\ncomment: \ndepartment_id: \nstaff_type: 0\nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-06 21:50:34','---\nbalance:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:0.75e3\nwage_debit:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:0.75e3\nupdated_at:\n- 2021-09-06 21:47:58.000000000 +05:00\n- 2021-09-06 21:50:34.000000000 +05:00\n'),(150,'StaffLedgerBook',2,'create','192',NULL,'2021-09-06 21:50:34','---\nid:\n- \n- 2\nstaff_id:\n- \n- 5\nsalary_detail_id:\n- \n- 2\ncredit:\n- \n- !ruby/object:BigDecimal 18:0.75e3\nbalance:\n- \n- !ruby/object:BigDecimal 18:0.75e3\ncreated_at:\n- \n- 2021-09-06 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-06 21:50:34.000000000 +05:00\n'),(151,'SalaryDetail',2,'create','192',NULL,'2021-09-06 21:50:34','---\nid:\n- \n- 2\nstaff_id:\n- \n- 5\nwage_rate:\n- \n- 250.0\nquantity:\n- \n- 3.0\namount:\n- \n- 750.0\nremarks:\n- \n- \'750.0\'\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-06 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-06 21:50:34.000000000 +05:00\n'),(152,'StaffLedgerBook',1,'update','192','---\nbalance: !ruby/object:BigDecimal 18:0.25e3\nid: 1\nstaff_id: 5\nsalary_id: \nsalary_detail_id: 1\ndebit: \ncredit: !ruby/object:BigDecimal 18:0.25e3\ncomment: \ncreated_at: 2021-09-06 00:00:00.000000000 +05:00\nupdated_at: 2021-09-06 19:48:48.000000000 +05:00\nstatus: \n','2021-09-06 21:51:31','---\nbalance:\n- !ruby/object:BigDecimal 18:0.25e3\n- !ruby/object:BigDecimal 18:0.75e3\nupdated_at:\n- 2021-09-06 19:48:48.000000000 +05:00\n- 2021-09-06 21:51:31.000000000 +05:00\n'),(153,'StaffLedgerBook',2,'update','192','---\nbalance: !ruby/object:BigDecimal 18:0.75e3\nid: 2\nstaff_id: 5\nsalary_id: \nsalary_detail_id: 2\ndebit: \ncredit: !ruby/object:BigDecimal 18:0.75e3\ncomment: \ncreated_at: 2021-09-06 00:00:00.000000000 +05:00\nupdated_at: 2021-09-06 21:50:34.000000000 +05:00\nstatus: \n','2021-09-06 21:51:31','---\nbalance:\n- !ruby/object:BigDecimal 18:0.75e3\n- !ruby/object:BigDecimal 18:0.5e3\nupdated_at:\n- 2021-09-06 21:50:34.000000000 +05:00\n- 2021-09-06 21:51:31.000000000 +05:00\n'),(154,'Staff',5,'update','192','---\nbalance: !ruby/object:BigDecimal 18:0.75e3\nwage_debit: !ruby/object:BigDecimal 18:0.75e3\nname: Mason-1\nfather: \'\'\nid: 5\ncode: AGC-0005\neducation: \'\'\nphone: \'\'\naddress: \'\'\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nstaff_department: \'\'\ngender: 0\nadvance_amount: !ruby/object:BigDecimal 18:0.0\nterminated: false\nterminated_at: 2021-09-06 19:47:20.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-06 19:47:20.000000000 +05:00\ncreated_at: 2021-09-06 19:47:20.000000000 +05:00\nupdated_at: 2021-09-06 21:50:34.000000000 +05:00\nwage_rate: !ruby/object:BigDecimal 18:0.25e3\ncomment: \ndepartment_id: \nstaff_type: 0\nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-06 21:53:41','---\nbalance:\n- !ruby/object:BigDecimal 18:0.75e3\n- !ruby/object:BigDecimal 18:0.25e3\nwage_debit:\n- !ruby/object:BigDecimal 18:0.75e3\n- !ruby/object:BigDecimal 18:0.25e3\nupdated_at:\n- 2021-09-06 21:50:34.000000000 +05:00\n- 2021-09-06 21:53:41.000000000 +05:00\n'),(155,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:0.0\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-02 11:27:51.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-06 21:53:41','---\namount:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:-0.5e3\nupdated_at:\n- 2021-09-02 11:27:51.000000000 +05:00\n- 2021-09-06 21:53:41.000000000 +05:00\n'),(156,'Payment',2,'update','192','---\nid: 2\ndebit: !ruby/object:BigDecimal 18:0.5e3\ncredit: \naccount_id: 1\npaymentable_type: Salary\npaymentable_id: 1\namount: \nstatus: \ncomment: \'Salary/Advance To Mason-1 \'\ncreated_at: 2021-09-06 21:53:41.000000000 +05:00\nupdated_at: 2021-09-06 21:53:41.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-06 21:53:41','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.5e3\n'),(157,'Payment',2,'create','192',NULL,'2021-09-06 21:53:41','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.5e3\n'),(158,'StaffLedgerBook',3,'create','192',NULL,'2021-09-06 21:53:41','---\nid:\n- \n- 3\nstaff_id:\n- \n- 5\nsalary_id:\n- \n- 1\ndebit:\n- \n- !ruby/object:BigDecimal 18:0.5e3\nbalance:\n- \n- !ruby/object:BigDecimal 18:0.25e3\ncreated_at:\n- \n- 2021-09-06 21:52:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-06 21:53:41.000000000 +05:00\n'),(159,'Salary',1,'create','192',NULL,'2021-09-06 21:53:41','---\nid:\n- \n- 1\nadvance:\n- 0\n- 500\nstaff_id:\n- \n- 5\npayment_type:\n- 0\n- 1\ncreated_at:\n- \n- 2021-09-06 21:52:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-06 21:53:41.000000000 +05:00\naccount_id:\n- \n- 1\ncomment:\n- \n- \'\'\nbalance:\n- \n- 250.0\ntotal_balance:\n- \n- 250.0\n'),(160,'Staff',5,'update','192','---\nbalance: !ruby/object:BigDecimal 18:0.25e3\nwage_debit: !ruby/object:BigDecimal 18:0.25e3\nname: Mason-1\nfather: \'\'\nid: 5\ncode: AGC-0005\neducation: \'\'\nphone: \'\'\naddress: \'\'\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nstaff_department: \'\'\ngender: 0\nadvance_amount: !ruby/object:BigDecimal 18:0.0\nterminated: false\nterminated_at: 2021-09-06 19:47:20.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-06 19:47:20.000000000 +05:00\ncreated_at: 2021-09-06 19:47:20.000000000 +05:00\nupdated_at: 2021-09-06 21:53:41.000000000 +05:00\nwage_rate: !ruby/object:BigDecimal 18:0.25e3\ncomment: \ndepartment_id: \nstaff_type: 0\nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-06 21:53:41','---\nadvance_amount:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:0.5e3\n'),(161,'Payment',2,'update','192','---\npaymentable_id: 1\npaymentable_type: Salary\namount: !ruby/object:BigDecimal 18:-0.5e3\nid: 2\ndebit: !ruby/object:BigDecimal 18:0.5e3\ncomment: \'Salary/Advance To Mason-1 \'\naccount_id: 1\ncredit: \nstatus: \ncreated_at: 2021-09-06 21:53:41.000000000 +05:00\nupdated_at: 2021-09-06 21:53:41.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-06 21:54:09','---\ncomment:\n- \'Salary/Advance To Mason-1 \'\n- Edited Salary/Advance\nupdated_at:\n- 2021-09-06 21:53:41.000000000 +05:00\n- 2021-09-06 21:54:09.000000000 +05:00\n'),(162,'StaffLedgerBook',3,'update','192','---\nsalary_id: 1\nbalance: !ruby/object:BigDecimal 18:0.25e3\ndebit: !ruby/object:BigDecimal 18:0.5e3\nid: 3\nstaff_id: 5\nsalary_detail_id: \ncredit: \ncomment: \ncreated_at: 2021-09-06 21:52:00.000000000 +05:00\nupdated_at: 2021-09-06 21:53:41.000000000 +05:00\nstatus: \n','2021-09-06 21:54:09','---\nbalance:\n- !ruby/object:BigDecimal 18:0.25e3\n- !ruby/object:BigDecimal 18:-0.75e3\nupdated_at:\n- 2021-09-06 21:53:41.000000000 +05:00\n- 2021-09-06 21:54:09.000000000 +05:00\n'),(163,'Staff',5,'update','192','---\nbalance: !ruby/object:BigDecimal 18:0.25e3\nwage_debit: !ruby/object:BigDecimal 18:0.25e3\nid: 5\ncode: AGC-0005\nname: Mason-1\nfather: \'\'\neducation: \'\'\nphone: \'\'\naddress: \'\'\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nstaff_department: \'\'\ngender: 0\nadvance_amount: !ruby/object:BigDecimal 18:0.5e3\nterminated: false\nterminated_at: 2021-09-06 19:47:20.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-06 19:47:20.000000000 +05:00\ncreated_at: 2021-09-06 19:47:20.000000000 +05:00\nupdated_at: 2021-09-06 21:53:41.000000000 +05:00\nwage_rate: !ruby/object:BigDecimal 18:0.25e3\ncomment: \ndepartment_id: \nstaff_type: 0\nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-06 21:54:09','---\nadvance_amount:\n- !ruby/object:BigDecimal 18:0.5e3\n- !ruby/object:BigDecimal 18:0.1e4\nupdated_at:\n- 2021-09-06 21:53:41.000000000 +05:00\n- 2021-09-06 21:54:09.000000000 +05:00\n'),(164,'Staff',5,'update','192','---\nid: 5\nadvance_amount: !ruby/object:BigDecimal 18:0.1e4\ncode: AGC-0005\nname: Mason-1\nfather: \'\'\neducation: \'\'\nphone: \'\'\naddress: \'\'\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nstaff_department: \'\'\ngender: 0\nterminated: false\nterminated_at: 2021-09-06 19:47:20.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-06 19:47:20.000000000 +05:00\ncreated_at: 2021-09-06 19:47:20.000000000 +05:00\nupdated_at: 2021-09-06 21:54:09.000000000 +05:00\nwage_rate: !ruby/object:BigDecimal 18:0.25e3\ncomment: \nbalance: !ruby/object:BigDecimal 18:0.25e3\ndepartment_id: \nstaff_type: 0\nwage_debit: !ruby/object:BigDecimal 18:0.25e3\nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-06 21:54:09','---\nadvance_amount:\n- !ruby/object:BigDecimal 18:0.1e4\n- !ruby/object:BigDecimal 18:0.5e3\n'),(165,'StaffLedgerBook',3,'update','192','---\nbalance: !ruby/object:BigDecimal 18:-0.75e3\nid: 3\nstaff_id: 5\nsalary_id: 1\nsalary_detail_id: \ndebit: !ruby/object:BigDecimal 18:0.5e3\ncredit: \ncomment: \ncreated_at: 2021-09-06 21:52:00.000000000 +05:00\nupdated_at: 2021-09-06 21:54:09.000000000 +05:00\nstatus: \n','2021-09-06 21:54:09','---\nbalance:\n- !ruby/object:BigDecimal 18:-0.75e3\n- !ruby/object:BigDecimal 18:0.5e3\n'),(166,'StaffLedgerBook',1,'update','192','---\nbalance: !ruby/object:BigDecimal 18:0.75e3\nid: 1\nstaff_id: 5\nsalary_id: \nsalary_detail_id: 1\ndebit: \ncredit: !ruby/object:BigDecimal 18:0.25e3\ncomment: \ncreated_at: 2021-09-06 00:00:00.000000000 +05:00\nupdated_at: 2021-09-06 21:51:31.000000000 +05:00\nstatus: \n','2021-09-06 21:54:09','---\nbalance:\n- !ruby/object:BigDecimal 18:0.75e3\n- !ruby/object:BigDecimal 18:0.1e4\nupdated_at:\n- 2021-09-06 21:51:31.000000000 +05:00\n- 2021-09-06 21:54:09.000000000 +05:00\n'),(167,'StaffLedgerBook',2,'update','192','---\nbalance: !ruby/object:BigDecimal 18:0.5e3\nid: 2\nstaff_id: 5\nsalary_id: \nsalary_detail_id: 2\ndebit: \ncredit: !ruby/object:BigDecimal 18:0.75e3\ncomment: \ncreated_at: 2021-09-06 00:00:00.000000000 +05:00\nupdated_at: 2021-09-06 21:51:31.000000000 +05:00\nstatus: \n','2021-09-06 21:54:09','---\nbalance:\n- !ruby/object:BigDecimal 18:0.5e3\n- !ruby/object:BigDecimal 18:0.75e3\nupdated_at:\n- 2021-09-06 21:51:31.000000000 +05:00\n- 2021-09-06 21:54:09.000000000 +05:00\n'),(168,'StaffLedgerBook',3,'destroy','192','---\nid: 3\nstaff_id: 5\nsalary_id: 1\nsalary_detail_id: \ndebit: !ruby/object:BigDecimal 18:0.5e3\ncredit: \nbalance: !ruby/object:BigDecimal 18:0.5e3\ncomment: \ncreated_at: 2021-09-06 21:52:00.000000000 +05:00\nupdated_at: 2021-09-06 21:54:09.000000000 +05:00\nstatus: \n','2021-09-06 21:59:08','---\nid:\n- 3\n- \nstaff_id:\n- 5\n- \nsalary_id:\n- 1\n- \nsalary_detail_id:\n- \n- \ndebit:\n- !ruby/object:BigDecimal 18:0.5e3\n- \ncredit:\n- \n- \nbalance:\n- !ruby/object:BigDecimal 18:0.5e3\n- \ncomment:\n- \n- \ncreated_at:\n- 2021-09-06 21:52:00.000000000 +05:00\n- \nupdated_at:\n- 2021-09-06 21:54:09.000000000 +05:00\n- \nstatus:\n- \n- \n'),(169,'Payment',2,'update','192','---\npaymentable_id: 1\npaymentable_type: Salary\namount: !ruby/object:BigDecimal 18:-0.5e3\nid: 2\ndebit: !ruby/object:BigDecimal 18:0.5e3\ncredit: \ncomment: Edited Salary/Advance\naccount_id: 1\nstatus: \ncreated_at: 2021-09-06 21:53:41.000000000 +05:00\nupdated_at: 2021-09-06 21:54:09.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-06 21:59:08','---\namount:\n- !ruby/object:BigDecimal 18:-0.5e3\n- !ruby/object:BigDecimal 18:0.0\ndebit:\n- !ruby/object:BigDecimal 18:0.5e3\n- !ruby/object:BigDecimal 18:0.0\ncredit:\n- \n- !ruby/object:BigDecimal 18:0.0\ncomment:\n- Edited Salary/Advance\n- Destory Salary/Advance\nupdated_at:\n- 2021-09-06 21:54:09.000000000 +05:00\n- 2021-09-06 21:59:08.000000000 +05:00\n'),(170,'Staff',5,'update','192','---\nbalance: !ruby/object:BigDecimal 18:0.25e3\nwage_debit: !ruby/object:BigDecimal 18:0.25e3\nid: 5\ncode: AGC-0005\nname: Mason-1\nfather: \'\'\neducation: \'\'\nphone: \'\'\naddress: \'\'\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nstaff_department: \'\'\ngender: 0\nadvance_amount: !ruby/object:BigDecimal 18:0.5e3\nterminated: false\nterminated_at: 2021-09-06 19:47:20.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-06 19:47:20.000000000 +05:00\ncreated_at: 2021-09-06 19:47:20.000000000 +05:00\nupdated_at: 2021-09-06 21:54:09.000000000 +05:00\nwage_rate: !ruby/object:BigDecimal 18:0.25e3\ncomment: \ndepartment_id: \nstaff_type: 0\nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-06 21:59:08','---\nbalance:\n- !ruby/object:BigDecimal 18:0.25e3\n- !ruby/object:BigDecimal 18:0.75e3\nwage_debit:\n- !ruby/object:BigDecimal 18:0.25e3\n- !ruby/object:BigDecimal 18:0.75e3\nupdated_at:\n- 2021-09-06 21:54:09.000000000 +05:00\n- 2021-09-06 21:59:08.000000000 +05:00\n'),(171,'Salary',1,'destroy','192','---\nid: 1\npaid_salary: \nadvance: 500\nleaves_in_month: 0\nstaff_id: 5\npaid_to: \npayment_type: 1\nadvance_amount: 0\nadvance_due_till_this_transaction: 1000\ncreated_at: 2021-09-06 21:52:00.000000000 +05:00\nupdated_at: 2021-09-06 21:53:41.000000000 +05:00\naccount_id: 1\ncomment: \'\'\nbalance: 250.0\ntotal_balance: 250.0\n','2021-09-06 21:59:08','---\nid:\n- 1\n- \npaid_salary:\n- \n- \nadvance:\n- 500\n- \nleaves_in_month:\n- 0\n- \nstaff_id:\n- 5\n- \npaid_to:\n- \n- \npayment_type:\n- 1\n- \nadvance_amount:\n- 0\n- \nadvance_due_till_this_transaction:\n- 1000\n- \ncreated_at:\n- 2021-09-06 21:52:00.000000000 +05:00\n- \nupdated_at:\n- 2021-09-06 21:53:41.000000000 +05:00\n- \naccount_id:\n- 1\n- \ncomment:\n- \'\'\n- \nbalance:\n- 250.0\n- \ntotal_balance:\n- 250.0\n- \n'),(172,'Staff',5,'update','192','---\nid: 5\nadvance_amount: !ruby/object:BigDecimal 18:0.5e3\ncode: AGC-0005\nname: Mason-1\nfather: \'\'\neducation: \'\'\nphone: \'\'\naddress: \'\'\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nstaff_department: \'\'\ngender: 0\nterminated: false\nterminated_at: 2021-09-06 19:47:20.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-06 19:47:20.000000000 +05:00\ncreated_at: 2021-09-06 19:47:20.000000000 +05:00\nupdated_at: 2021-09-06 21:59:08.000000000 +05:00\nwage_rate: !ruby/object:BigDecimal 18:0.25e3\ncomment: \nbalance: !ruby/object:BigDecimal 18:0.75e3\ndepartment_id: \nstaff_type: 0\nwage_debit: !ruby/object:BigDecimal 18:0.75e3\nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-06 21:59:08','---\nadvance_amount:\n- !ruby/object:BigDecimal 18:0.5e3\n- !ruby/object:BigDecimal 18:0.0\n'),(173,'StaffLedgerBook',1,'destroy','192','---\nid: 1\nstaff_id: 5\nsalary_id: \nsalary_detail_id: 1\ndebit: \ncredit: !ruby/object:BigDecimal 18:0.25e3\nbalance: !ruby/object:BigDecimal 18:0.1e4\ncomment: \ncreated_at: 2021-09-06 00:00:00.000000000 +05:00\nupdated_at: 2021-09-06 21:54:09.000000000 +05:00\nstatus: \n','2021-09-06 21:59:11','---\nid:\n- 1\n- \nstaff_id:\n- 5\n- \nsalary_id:\n- \n- \nsalary_detail_id:\n- 1\n- \ndebit:\n- \n- \ncredit:\n- !ruby/object:BigDecimal 18:0.25e3\n- \nbalance:\n- !ruby/object:BigDecimal 18:0.1e4\n- \ncomment:\n- \n- \ncreated_at:\n- 2021-09-06 00:00:00.000000000 +05:00\n- \nupdated_at:\n- 2021-09-06 21:54:09.000000000 +05:00\n- \nstatus:\n- \n- \n'),(174,'SalaryDetail',1,'destroy','192','---\nid: 1\nstaff_id: 5\nwage_rate: 250.0\nquantity: 1.0\namount: 250.0\nremarks: \'750.0\'\ncomment: \'\'\ncreated_at: 2021-09-06 00:00:00.000000000 +05:00\nupdated_at: 2021-09-06 19:48:48.000000000 +05:00\nproduct_id: 2\nstatus: 1\nextra: \ndaily_book_id: \nraw_product_id: \nraw_quantity: \nraw_wage_rate: \ngift_rate: \ncoverge_rate: \nwage_debit: \ngift_pay: \ncoverge_pay: \nstaff_pathera_id: \ntransaction_location: \nkhakar_quanity: \nkhakar_remaning: \nkhakar_debit: \nkhakar_wast: \nkhakar_extra: \nkhakar_credit: \npather_remaning_quanity: \npather_salary_detail_id: \npurchase_sale_detail_id: \npather_khakar_wast: \nbalance: \ntotal_balance: \n','2021-09-06 21:59:11','---\nid:\n- 1\n- \nstaff_id:\n- 5\n- \nwage_rate:\n- 250.0\n- \nquantity:\n- 1.0\n- \namount:\n- 250.0\n- \nremarks:\n- \'750.0\'\n- \ncomment:\n- \'\'\n- \ncreated_at:\n- 2021-09-06 00:00:00.000000000 +05:00\n- \nupdated_at:\n- 2021-09-06 19:48:48.000000000 +05:00\n- \nproduct_id:\n- 2\n- \nstatus:\n- 1\n- \nextra:\n- \n- \ndaily_book_id:\n- \n- \nraw_product_id:\n- \n- \nraw_quantity:\n- \n- \nraw_wage_rate:\n- \n- \ngift_rate:\n- \n- \ncoverge_rate:\n- \n- \nwage_debit:\n- \n- \ngift_pay:\n- \n- \ncoverge_pay:\n- \n- \nstaff_pathera_id:\n- \n- \ntransaction_location:\n- \n- \nkhakar_quanity:\n- \n- \nkhakar_remaning:\n- \n- \nkhakar_debit:\n- \n- \nkhakar_wast:\n- \n- \nkhakar_extra:\n- \n- \nkhakar_credit:\n- \n- \npather_remaning_quanity:\n- \n- \npather_salary_detail_id:\n- \n- \npurchase_sale_detail_id:\n- \n- \npather_khakar_wast:\n- \n- \nbalance:\n- \n- \ntotal_balance:\n- \n- \n'),(175,'StaffLedgerBook',2,'destroy','192','---\nid: 2\nstaff_id: 5\nsalary_id: \nsalary_detail_id: 2\ndebit: \ncredit: !ruby/object:BigDecimal 18:0.75e3\nbalance: !ruby/object:BigDecimal 18:0.75e3\ncomment: \ncreated_at: 2021-09-06 00:00:00.000000000 +05:00\nupdated_at: 2021-09-06 21:54:09.000000000 +05:00\nstatus: \n','2021-09-06 21:59:14','---\nid:\n- 2\n- \nstaff_id:\n- 5\n- \nsalary_id:\n- \n- \nsalary_detail_id:\n- 2\n- \ndebit:\n- \n- \ncredit:\n- !ruby/object:BigDecimal 18:0.75e3\n- \nbalance:\n- !ruby/object:BigDecimal 18:0.75e3\n- \ncomment:\n- \n- \ncreated_at:\n- 2021-09-06 00:00:00.000000000 +05:00\n- \nupdated_at:\n- 2021-09-06 21:54:09.000000000 +05:00\n- \nstatus:\n- \n- \n'),(176,'SalaryDetail',2,'destroy','192','---\nid: 2\nstaff_id: 5\nwage_rate: 250.0\nquantity: 3.0\namount: 750.0\nremarks: \'750.0\'\ncomment: \'\'\ncreated_at: 2021-09-06 00:00:00.000000000 +05:00\nupdated_at: 2021-09-06 21:50:34.000000000 +05:00\nproduct_id: \nstatus: \nextra: \ndaily_book_id: \nraw_product_id: \nraw_quantity: \nraw_wage_rate: \ngift_rate: \ncoverge_rate: \nwage_debit: \ngift_pay: \ncoverge_pay: \nstaff_pathera_id: \ntransaction_location: \nkhakar_quanity: \nkhakar_remaning: \nkhakar_debit: \nkhakar_wast: \nkhakar_extra: \nkhakar_credit: \npather_remaning_quanity: \npather_salary_detail_id: \npurchase_sale_detail_id: \npather_khakar_wast: \nbalance: \ntotal_balance: \n','2021-09-06 21:59:14','---\nid:\n- 2\n- \nstaff_id:\n- 5\n- \nwage_rate:\n- 250.0\n- \nquantity:\n- 3.0\n- \namount:\n- 750.0\n- \nremarks:\n- \'750.0\'\n- \ncomment:\n- \'\'\n- \ncreated_at:\n- 2021-09-06 00:00:00.000000000 +05:00\n- \nupdated_at:\n- 2021-09-06 21:50:34.000000000 +05:00\n- \nproduct_id:\n- \n- \nstatus:\n- \n- \nextra:\n- \n- \ndaily_book_id:\n- \n- \nraw_product_id:\n- \n- \nraw_quantity:\n- \n- \nraw_wage_rate:\n- \n- \ngift_rate:\n- \n- \ncoverge_rate:\n- \n- \nwage_debit:\n- \n- \ngift_pay:\n- \n- \ncoverge_pay:\n- \n- \nstaff_pathera_id:\n- \n- \ntransaction_location:\n- \n- \nkhakar_quanity:\n- \n- \nkhakar_remaning:\n- \n- \nkhakar_debit:\n- \n- \nkhakar_wast:\n- \n- \nkhakar_extra:\n- \n- \nkhakar_credit:\n- \n- \npather_remaning_quanity:\n- \n- \npather_salary_detail_id:\n- \n- \npurchase_sale_detail_id:\n- \n- \npather_khakar_wast:\n- \n- \nbalance:\n- \n- \ntotal_balance:\n- \n- \n'),(177,'Staff',5,'update','192','---\nid: 5\ncode: AGC-0005\nname: Mason-1\nfather: \'\'\neducation: \'\'\ngender: 0\nphone: \'\'\naddress: \'\'\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nwage_rate: !ruby/object:BigDecimal 18:0.25e3\nbalance: !ruby/object:BigDecimal 18:0.0\nstaff_department: \'\'\ndepartment_id: \nstaff_type: 0\nwage_debit: !ruby/object:BigDecimal 18:0.75e3\nadvance_amount: !ruby/object:BigDecimal 18:0.0\nterminated: false\nterminated_at: 2021-09-06 19:47:20.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-06 19:47:20.000000000 +05:00\ncreated_at: 2021-09-06 19:47:20.000000000 +05:00\nupdated_at: 2021-09-06 21:59:08.000000000 +05:00\ncomment: \nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-06 21:59:36','---\nwage_debit:\n- !ruby/object:BigDecimal 18:0.75e3\n- !ruby/object:BigDecimal 18:0.0\nupdated_at:\n- 2021-09-06 21:59:08.000000000 +05:00\n- 2021-09-06 21:59:36.000000000 +05:00\n'),(178,'Payment',2,'update','192','---\nid: 2\ndebit: !ruby/object:BigDecimal 18:0.0\ncredit: !ruby/object:BigDecimal 18:0.0\ncomment: Destory Salary/Advance\naccount_id: 1\ncreated_at: 2021-09-06 21:53:41.000000000 +05:00\npaymentable_type: Salary\npaymentable_id: 1\namount: !ruby/object:BigDecimal 18:0.0\nstatus: \nupdated_at: 2021-09-06 21:59:08.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-06 22:01:54','---\ncreated_at:\n- 2021-09-06 21:53:41.000000000 +05:00\n- 2021-09-06 21:53:00.000000000 +05:00\nupdated_at:\n- 2021-09-06 21:59:08.000000000 +05:00\n- 2021-09-06 22:01:54.000000000 +05:00\n'),(179,'Account',1,'update','192','---\nid: 1\namount: !ruby/object:BigDecimal 18:-0.5e3\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-06 21:53:41.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-06 22:01:54','---\namount:\n- !ruby/object:BigDecimal 18:-0.5e3\n- !ruby/object:BigDecimal 18:0.0\nupdated_at:\n- 2021-09-06 21:53:41.000000000 +05:00\n- 2021-09-06 22:01:54.000000000 +05:00\n'),(180,'PosSetting',1,'update','192','---\nid: 1\nname: Al-Arsh Construction Corp\ndisplay_name: Al-Arsh Construction Corp\nphone: \'7184315203\'\naccount_id: 1\naddress: 309 Deer Road, Ronkonkoma NY 11779\ninvoice_note: \'\'\npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: \'\'\nheader: true\nfooter: true\nheader_logo_placement: logo_disable_text_center\nlogo_hieght: \'200\'\nlogo_width: \'300\'\nheader_hieght: \'50\'\nmulti_language: false\ntitle_padding: \'10\'\nfooter_address_placement: center\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nupdated_at: 2021-09-06 21:44:18.000000000 +05:00\nsys_type: 4\npurchase_sale_detail_show_line_height: 20\n','2021-09-07 00:29:17','---\nheader_logo_placement:\n- logo_disable_text_center\n- logo_left_text_center\nlogo_hieght:\n- \'200\'\n- \'170\'\nlogo_width:\n- \'300\'\n- \'170\'\nheader_hieght:\n- \'50\'\n- \'120\'\nupdated_at:\n- 2021-09-06 21:44:18.000000000 +05:00\n- 2021-09-07 00:29:17.000000000 +05:00\n'),(181,'PosSetting',1,'update','192','---\nid: 1\nname: Al-Arsh Construction Corp\ndisplay_name: Al-Arsh Construction Corp\nphone: \'7184315203\'\naccount_id: 1\naddress: 309 Deer Road, Ronkonkoma NY 11779\ninvoice_note: \'\'\npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: \'\'\nheader: true\nfooter: true\nheader_logo_placement: logo_left_text_center\nlogo_hieght: \'170\'\nlogo_width: \'170\'\nheader_hieght: \'120\'\nmulti_language: false\ntitle_padding: \'10\'\nfooter_address_placement: center\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nupdated_at: 2021-09-07 00:29:17.000000000 +05:00\nsys_type: 4\npurchase_sale_detail_show_line_height: 20\n','2021-09-07 00:29:42','---\nlogo_width:\n- \'170\'\n- \'220\'\nupdated_at:\n- 2021-09-07 00:29:17.000000000 +05:00\n- 2021-09-07 00:29:42.000000000 +05:00\n'),(182,'PosSetting',1,'update','192','---\nid: 1\nname: Al-Arsh Construction Corp\ndisplay_name: Al-Arsh Construction Corp\nphone: \'7184315203\'\naccount_id: 1\naddress: 309 Deer Road, Ronkonkoma NY 11779\ninvoice_note: \'\'\npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: \'\'\nheader: true\nfooter: true\nheader_logo_placement: logo_left_text_center\nlogo_hieght: \'170\'\nlogo_width: \'220\'\nheader_hieght: \'120\'\nmulti_language: false\ntitle_padding: \'10\'\nfooter_address_placement: center\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nupdated_at: 2021-09-07 00:29:42.000000000 +05:00\nsys_type: 4\npurchase_sale_detail_show_line_height: 20\n','2021-09-07 00:30:36','---\nlogo_width:\n- \'220\'\n- \'250\'\nupdated_at:\n- 2021-09-07 00:29:42.000000000 +05:00\n- 2021-09-07 00:30:36.000000000 +05:00\n'),(183,'PosSetting',1,'update','192','---\nid: 1\nname: Al-Arsh Construction Corp\ndisplay_name: Al-Arsh Construction Corp\nphone: \'7184315203\'\naccount_id: 1\naddress: 309 Deer Road, Ronkonkoma NY 11779\ninvoice_note: \'\'\npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: \'\'\nheader: true\nfooter: true\nheader_logo_placement: logo_left_text_center\nlogo_hieght: \'170\'\nlogo_width: \'250\'\nheader_hieght: \'120\'\nmulti_language: false\ntitle_padding: \'10\'\nfooter_address_placement: center\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nupdated_at: 2021-09-07 00:30:36.000000000 +05:00\nsys_type: 4\npurchase_sale_detail_show_line_height: 20\n','2021-09-07 00:31:14','---\nlogo_hieght:\n- \'170\'\n- \'150\'\nlogo_width:\n- \'250\'\n- \'270\'\nupdated_at:\n- 2021-09-07 00:30:36.000000000 +05:00\n- 2021-09-07 00:31:14.000000000 +05:00\n'),(184,'PosSetting',1,'update','192','---\nid: 1\nname: Al-Arsh Construction Corp\ndisplay_name: Al-Arsh Construction Corp\nphone: \'7184315203\'\naccount_id: 1\naddress: 309 Deer Road, Ronkonkoma NY 11779\ninvoice_note: \'\'\npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: \'\'\nheader: true\nfooter: true\nheader_logo_placement: logo_left_text_center\nlogo_hieght: \'150\'\nlogo_width: \'270\'\nheader_hieght: \'120\'\nmulti_language: false\ntitle_padding: \'10\'\nfooter_address_placement: center\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nupdated_at: 2021-09-07 00:31:14.000000000 +05:00\nsys_type: 4\npurchase_sale_detail_show_line_height: 20\n','2021-09-07 00:31:47','---\nlogo_width:\n- \'270\'\n- \'300\'\nheader_hieght:\n- \'120\'\n- \'100\'\nupdated_at:\n- 2021-09-07 00:31:14.000000000 +05:00\n- 2021-09-07 00:31:47.000000000 +05:00\n'),(185,'PosSetting',1,'update','192','---\nid: 1\nname: Al-Arsh Construction Corp\ndisplay_name: Al-Arsh Construction Corp\nphone: \'7184315203\'\naccount_id: 1\naddress: 309 Deer Road, Ronkonkoma NY 11779\ninvoice_note: \'\'\npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: \'\'\nheader: true\nfooter: true\nheader_logo_placement: logo_left_text_center\nlogo_hieght: \'150\'\nlogo_width: \'300\'\nheader_hieght: \'100\'\nmulti_language: false\ntitle_padding: \'10\'\nfooter_address_placement: center\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nupdated_at: 2021-09-07 00:31:47.000000000 +05:00\nsys_type: 4\npurchase_sale_detail_show_line_height: 20\n','2021-09-07 00:32:21','---\nheader_hieght:\n- \'100\'\n- \'150\'\nupdated_at:\n- 2021-09-07 00:31:47.000000000 +05:00\n- 2021-09-07 00:32:21.000000000 +05:00\n'),(186,'PosSetting',1,'update','192','---\nid: 1\nname: Al-Arsh Construction Corp\ndisplay_name: Al-Arsh Construction Corp\nphone: \'7184315203\'\naccount_id: 1\naddress: 309 Deer Road, Ronkonkoma NY 11779\ninvoice_note: \'\'\npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: \'\'\nheader: true\nfooter: true\nheader_logo_placement: logo_left_text_center\nlogo_hieght: \'150\'\nlogo_width: \'300\'\nheader_hieght: \'150\'\nmulti_language: false\ntitle_padding: \'10\'\nfooter_address_placement: center\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nupdated_at: 2021-09-07 00:32:21.000000000 +05:00\nsys_type: 4\npurchase_sale_detail_show_line_height: 20\n','2021-09-07 00:32:41','---\ntitle_padding:\n- \'10\'\n- \'100\'\nupdated_at:\n- 2021-09-07 00:32:21.000000000 +05:00\n- 2021-09-07 00:32:41.000000000 +05:00\n'),(187,'PosSetting',1,'update','192','---\nid: 1\nname: Al-Arsh Construction Corp\ndisplay_name: Al-Arsh Construction Corp\nphone: \'7184315203\'\naccount_id: 1\naddress: 309 Deer Road, Ronkonkoma NY 11779\ninvoice_note: \'\'\npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: \'\'\nheader: true\nfooter: true\nheader_logo_placement: logo_left_text_center\nlogo_hieght: \'150\'\nlogo_width: \'300\'\nheader_hieght: \'150\'\nmulti_language: false\ntitle_padding: \'100\'\nfooter_address_placement: center\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nupdated_at: 2021-09-07 00:32:41.000000000 +05:00\nsys_type: 4\npurchase_sale_detail_show_line_height: 20\n','2021-09-07 00:33:05','---\nheader_hieght:\n- \'150\'\n- \'170\'\nupdated_at:\n- 2021-09-07 00:32:41.000000000 +05:00\n- 2021-09-07 00:33:05.000000000 +05:00\n'),(188,'PosSetting',1,'update','192','---\nid: 1\nname: Al-Arsh Construction Corp\ndisplay_name: Al-Arsh Construction Corp\nphone: \'7184315203\'\naccount_id: 1\naddress: 309 Deer Road, Ronkonkoma NY 11779\ninvoice_note: \'\'\npdf_margin_top: 0\npdf_margin_right: 0\npdf_margin_left: 0\npdf_margin_bottom: 0\npurchase_sale_detail_show_page_size: \'\'\nheader: true\nfooter: true\nheader_logo_placement: logo_left_text_center\nlogo_hieght: \'150\'\nlogo_width: \'300\'\nheader_hieght: \'170\'\nmulti_language: false\ntitle_padding: \'100\'\nfooter_address_placement: center\nexpiry_date: 2022-08-26 00:00:00.000000000 +05:00\nlogo: \ncreated_at: 2021-08-31 14:04:24.000000000 +05:00\nupdated_at: 2021-09-07 00:33:05.000000000 +05:00\nsys_type: 4\npurchase_sale_detail_show_line_height: 20\n','2021-09-07 00:33:19','---\nheader_hieght:\n- \'170\'\n- \'180\'\nupdated_at:\n- 2021-09-07 00:33:05.000000000 +05:00\n- 2021-09-07 00:33:19.000000000 +05:00\n'),(189,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:0.0\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-06 22:01:54.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:37:01','---\namount:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:-0.86e2\nupdated_at:\n- 2021-09-06 22:01:54.000000000 +05:00\n- 2021-09-07 21:37:01.000000000 +05:00\n'),(190,'Payment',3,'update','192','---\nid: 3\ndebit: !ruby/object:BigDecimal 18:0.86e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 1\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:37:01.000000000 +05:00\nupdated_at: 2021-09-07 21:37:01.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:37:01','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.86e2\n'),(191,'Payment',3,'create','192',NULL,'2021-09-07 21:37:01','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.86e2\n'),(192,'ExpenseEntry',1,'create','192',NULL,'2021-09-07 21:37:01','---\nid:\n- \n- 1\namount:\n- \n- 86.32\nexpense_id:\n- \n- 1\nexpense_type_id:\n- \n- 3\naccount_id:\n- \n- 1\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-07 21:37:01.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:37:01.000000000 +05:00\n'),(193,'Expense',1,'create','192',NULL,'2021-09-07 21:37:01','---\nid:\n- \n- 1\nexpense:\n- \n- 86.32\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-01 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:37:01.000000000 +05:00\n'),(194,'ExpenseType',6,'create','192',NULL,'2021-09-07 21:38:05','---\nid:\n- \n- 6\ntitle:\n- \n- AJ Recycle ( Grabage)\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-07 21:38:05.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:38:05.000000000 +05:00\n'),(195,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.86e2\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:37:01.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:38:46','---\namount:\n- !ruby/object:BigDecimal 18:-0.86e2\n- !ruby/object:BigDecimal 18:-0.376e3\nupdated_at:\n- 2021-09-07 21:37:01.000000000 +05:00\n- 2021-09-07 21:38:46.000000000 +05:00\n'),(196,'Payment',4,'update','192','---\nid: 4\ndebit: !ruby/object:BigDecimal 18:0.29e3\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 2\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:38:46.000000000 +05:00\nupdated_at: 2021-09-07 21:38:46.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:38:46','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.376e3\n'),(197,'Payment',4,'create','192',NULL,'2021-09-07 21:38:46','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.376e3\n'),(198,'ExpenseEntry',2,'create','192',NULL,'2021-09-07 21:38:46','---\nid:\n- \n- 2\namount:\n- \n- 290.0\nexpense_id:\n- \n- 2\nexpense_type_id:\n- \n- 6\naccount_id:\n- \n- 1\ncomment:\n- \n- Garbage from morris site\ncreated_at:\n- \n- 2021-09-07 21:38:46.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:38:46.000000000 +05:00\n'),(199,'Expense',2,'create','192',NULL,'2021-09-07 21:38:46','---\nid:\n- \n- 2\nexpense:\n- \n- 290.0\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-07 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:38:46.000000000 +05:00\n'),(200,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.376e3\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:38:46.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:39:40','---\namount:\n- !ruby/object:BigDecimal 18:-0.376e3\n- !ruby/object:BigDecimal 18:-0.393e3\nupdated_at:\n- 2021-09-07 21:38:46.000000000 +05:00\n- 2021-09-07 21:39:40.000000000 +05:00\n'),(201,'Payment',5,'update','192','---\nid: 5\ndebit: !ruby/object:BigDecimal 18:0.17e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 3\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:39:40.000000000 +05:00\nupdated_at: 2021-09-07 21:39:40.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:39:40','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.393e3\n'),(202,'Payment',5,'create','192',NULL,'2021-09-07 21:39:40','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.393e3\n'),(203,'ExpenseEntry',3,'create','192',NULL,'2021-09-07 21:39:40','---\nid:\n- \n- 3\namount:\n- \n- 17.16\nexpense_id:\n- \n- 3\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 1\ncomment:\n- \n- Aurora Deli\ncreated_at:\n- \n- 2021-09-07 21:39:40.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:39:40.000000000 +05:00\n'),(204,'Expense',3,'create','192',NULL,'2021-09-07 21:39:40','---\nid:\n- \n- 3\nexpense:\n- \n- 17.16\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-07 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:39:40.000000000 +05:00\n'),(205,'Expense',3,'update','192','---\nid: 3\nexpense: 17.16\ncomment: \'\'\ncreated_at: 2021-09-07 00:00:00.000000000 +05:00\nexpense_type_id: \nupdated_at: 2021-09-07 21:39:40.000000000 +05:00\naccount_id: \n','2021-09-07 21:40:14','---\ncreated_at:\n- 2021-09-07 00:00:00.000000000 +05:00\n- 2021-09-01 00:00:00.000000000 +05:00\nupdated_at:\n- 2021-09-07 21:39:40.000000000 +05:00\n- 2021-09-07 21:40:14.000000000 +05:00\n'),(206,'Expense',2,'update','192','---\nid: 2\nexpense: 290.0\ncomment: \'\'\ncreated_at: 2021-09-07 00:00:00.000000000 +05:00\nexpense_type_id: \nupdated_at: 2021-09-07 21:38:46.000000000 +05:00\naccount_id: \n','2021-09-07 21:40:19','---\ncreated_at:\n- 2021-09-07 00:00:00.000000000 +05:00\n- 2021-09-01 00:00:00.000000000 +05:00\nupdated_at:\n- 2021-09-07 21:38:46.000000000 +05:00\n- 2021-09-07 21:40:19.000000000 +05:00\n'),(207,'ExpenseType',7,'create','192',NULL,'2021-09-07 21:40:55','---\nid:\n- \n- 7\ntitle:\n- \n- Materials\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-07 21:40:55.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:40:55.000000000 +05:00\n'),(208,'ExpenseType',6,'update','192','---\nid: 6\ntitle: AJ Recycle ( Grabage)\ncomment: \'\'\ncreated_at: 2021-09-07 21:38:05.000000000 +05:00\nupdated_at: 2021-09-07 21:38:05.000000000 +05:00\n','2021-09-07 21:41:45','---\ntitle:\n- AJ Recycle ( Grabage)\n- AJ Recycle ( Garbage)\nupdated_at:\n- 2021-09-07 21:38:05.000000000 +05:00\n- 2021-09-07 21:41:45.000000000 +05:00\n'),(209,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.393e3\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:39:40.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:43:33','---\namount:\n- !ruby/object:BigDecimal 18:-0.393e3\n- !ruby/object:BigDecimal 18:-0.602e3\nupdated_at:\n- 2021-09-07 21:39:40.000000000 +05:00\n- 2021-09-07 21:43:33.000000000 +05:00\n'),(210,'Payment',6,'update','192','---\nid: 6\ndebit: !ruby/object:BigDecimal 18:0.209e3\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 4\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:43:33.000000000 +05:00\nupdated_at: 2021-09-07 21:43:33.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:43:33','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.602e3\n'),(211,'Payment',6,'create','192',NULL,'2021-09-07 21:43:33','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.602e3\n'),(212,'ExpenseEntry',4,'create','192',NULL,'2021-09-07 21:43:33','---\nid:\n- \n- 4\namount:\n- \n- 209.26\nexpense_id:\n- \n- 4\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 1\ncomment:\n- \n- united building supply\ncreated_at:\n- \n- 2021-09-07 21:43:33.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:43:33.000000000 +05:00\n'),(213,'Expense',4,'create','192',NULL,'2021-09-07 21:43:33','---\nid:\n- \n- 4\nexpense:\n- \n- 209.26\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-07 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:43:33.000000000 +05:00\n'),(214,'Expense',4,'update','192','---\nid: 4\nexpense: 209.26\ncomment: \'\'\ncreated_at: 2021-09-07 00:00:00.000000000 +05:00\nexpense_type_id: \nupdated_at: 2021-09-07 21:43:33.000000000 +05:00\naccount_id: \n','2021-09-07 21:44:22','---\ncreated_at:\n- 2021-09-07 00:00:00.000000000 +05:00\n- 2021-09-03 00:00:00.000000000 +05:00\nupdated_at:\n- 2021-09-07 21:43:33.000000000 +05:00\n- 2021-09-07 21:44:22.000000000 +05:00\n'),(215,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.602e3\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:43:33.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:45:05','---\namount:\n- !ruby/object:BigDecimal 18:-0.602e3\n- !ruby/object:BigDecimal 18:-0.618e3\nupdated_at:\n- 2021-09-07 21:43:33.000000000 +05:00\n- 2021-09-07 21:45:05.000000000 +05:00\n'),(216,'Payment',7,'update','192','---\nid: 7\ndebit: !ruby/object:BigDecimal 18:0.16e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 5\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:45:05.000000000 +05:00\nupdated_at: 2021-09-07 21:45:05.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:45:05','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.618e3\n'),(217,'Payment',7,'create','192',NULL,'2021-09-07 21:45:05','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.618e3\n'),(218,'ExpenseEntry',5,'create','192',NULL,'2021-09-07 21:45:05','---\nid:\n- \n- 5\namount:\n- \n- 16.0\nexpense_id:\n- \n- 5\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 1\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-07 21:45:05.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:45:05.000000000 +05:00\n'),(219,'Expense',5,'create','192',NULL,'2021-09-07 21:45:05','---\nid:\n- \n- 5\nexpense:\n- \n- 16.0\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-07 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:45:05.000000000 +05:00\n'),(220,'Expense',5,'update','192','---\nid: 5\nexpense: 16.0\ncomment: \'\'\ncreated_at: 2021-09-07 00:00:00.000000000 +05:00\nexpense_type_id: \nupdated_at: 2021-09-07 21:45:05.000000000 +05:00\naccount_id: \n','2021-09-07 21:45:23','---\ncreated_at:\n- 2021-09-07 00:00:00.000000000 +05:00\n- 2021-09-03 00:00:00.000000000 +05:00\nupdated_at:\n- 2021-09-07 21:45:05.000000000 +05:00\n- 2021-09-07 21:45:23.000000000 +05:00\n'),(221,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.618e3\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:45:05.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:46:21','---\namount:\n- !ruby/object:BigDecimal 18:-0.618e3\n- !ruby/object:BigDecimal 18:-0.62e3\nupdated_at:\n- 2021-09-07 21:45:05.000000000 +05:00\n- 2021-09-07 21:46:21.000000000 +05:00\n'),(222,'Payment',8,'update','192','---\nid: 8\ndebit: !ruby/object:BigDecimal 18:0.2e1\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 6\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:46:21.000000000 +05:00\nupdated_at: 2021-09-07 21:46:21.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:46:21','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.62e3\n'),(223,'Payment',8,'create','192',NULL,'2021-09-07 21:46:21','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.62e3\n'),(224,'ExpenseEntry',6,'create','192',NULL,'2021-09-07 21:46:21','---\nid:\n- \n- 6\namount:\n- \n- 2.99\nexpense_id:\n- \n- 6\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 1\ncomment:\n- \n- Five boro building supply\ncreated_at:\n- \n- 2021-09-07 21:46:21.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:46:21.000000000 +05:00\n'),(225,'Expense',6,'create','192',NULL,'2021-09-07 21:46:21','---\nid:\n- \n- 6\nexpense:\n- \n- 2.99\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-02 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:46:21.000000000 +05:00\n'),(226,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.62e3\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:46:21.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:47:11','---\namount:\n- !ruby/object:BigDecimal 18:-0.62e3\n- !ruby/object:BigDecimal 18:-0.809e3\nupdated_at:\n- 2021-09-07 21:46:21.000000000 +05:00\n- 2021-09-07 21:47:11.000000000 +05:00\n'),(227,'Payment',9,'update','192','---\nid: 9\ndebit: !ruby/object:BigDecimal 18:0.189e3\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 7\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:47:11.000000000 +05:00\nupdated_at: 2021-09-07 21:47:11.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:47:11','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.809e3\n'),(228,'Payment',9,'create','192',NULL,'2021-09-07 21:47:11','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.809e3\n'),(229,'ExpenseEntry',7,'create','192',NULL,'2021-09-07 21:47:11','---\nid:\n- \n- 7\namount:\n- \n- 189.44\nexpense_id:\n- \n- 7\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 1\ncomment:\n- \n- Five boro building supply\ncreated_at:\n- \n- 2021-09-07 21:47:11.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:47:11.000000000 +05:00\n'),(230,'Expense',7,'create','192',NULL,'2021-09-07 21:47:11','---\nid:\n- \n- 7\nexpense:\n- \n- 189.44\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-02 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:47:11.000000000 +05:00\n'),(231,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.809e3\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:47:11.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:48:13','---\namount:\n- !ruby/object:BigDecimal 18:-0.809e3\n- !ruby/object:BigDecimal 18:-0.835e3\nupdated_at:\n- 2021-09-07 21:47:11.000000000 +05:00\n- 2021-09-07 21:48:13.000000000 +05:00\n'),(232,'Payment',10,'update','192','---\nid: 10\ndebit: !ruby/object:BigDecimal 18:0.26e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 8\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:48:13.000000000 +05:00\nupdated_at: 2021-09-07 21:48:13.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:48:13','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.835e3\n'),(233,'Payment',10,'create','192',NULL,'2021-09-07 21:48:13','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.835e3\n'),(234,'ExpenseEntry',8,'create','192',NULL,'2021-09-07 21:48:13','---\nid:\n- \n- 8\namount:\n- \n- 26.91\nexpense_id:\n- \n- 8\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 1\ncomment:\n- \n- 1115 Astor Ave\ncreated_at:\n- \n- 2021-09-07 21:48:13.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:48:13.000000000 +05:00\n'),(235,'Expense',8,'create','192',NULL,'2021-09-07 21:48:13','---\nid:\n- \n- 8\nexpense:\n- \n- 26.91\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-03 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:48:13.000000000 +05:00\n'),(236,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.835e3\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:48:13.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:49:10','---\namount:\n- !ruby/object:BigDecimal 18:-0.835e3\n- !ruby/object:BigDecimal 18:-0.909e3\nupdated_at:\n- 2021-09-07 21:48:13.000000000 +05:00\n- 2021-09-07 21:49:10.000000000 +05:00\n'),(237,'Payment',11,'update','192','---\nid: 11\ndebit: !ruby/object:BigDecimal 18:0.74e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 9\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:49:10.000000000 +05:00\nupdated_at: 2021-09-07 21:49:10.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:49:10','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.909e3\n'),(238,'Payment',11,'create','192',NULL,'2021-09-07 21:49:10','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.909e3\n'),(239,'ExpenseEntry',9,'create','192',NULL,'2021-09-07 21:49:10','---\nid:\n- \n- 9\namount:\n- \n- 74.84\nexpense_id:\n- \n- 9\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 1\ncomment:\n- \n- \'Metro Building \'\ncreated_at:\n- \n- 2021-09-07 21:49:10.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:49:10.000000000 +05:00\n'),(240,'Expense',9,'create','192',NULL,'2021-09-07 21:49:10','---\nid:\n- \n- 9\nexpense:\n- \n- 74.84\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-02 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:49:10.000000000 +05:00\n'),(241,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.909e3\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:49:10.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:50:33','---\namount:\n- !ruby/object:BigDecimal 18:-0.909e3\n- !ruby/object:BigDecimal 18:-0.93e3\nupdated_at:\n- 2021-09-07 21:49:10.000000000 +05:00\n- 2021-09-07 21:50:33.000000000 +05:00\n'),(242,'Payment',12,'update','192','---\nid: 12\ndebit: !ruby/object:BigDecimal 18:0.21e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 10\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:50:33.000000000 +05:00\nupdated_at: 2021-09-07 21:50:33.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:50:33','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.93e3\n'),(243,'Payment',12,'create','192',NULL,'2021-09-07 21:50:33','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.93e3\n'),(244,'ExpenseEntry',10,'create','192',NULL,'2021-09-07 21:50:33','---\nid:\n- \n- 10\namount:\n- \n- 21.22\nexpense_id:\n- \n- 10\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 1\ncomment:\n- \n- \'Gourmet Delight \'\ncreated_at:\n- \n- 2021-09-07 21:50:33.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:50:33.000000000 +05:00\n'),(245,'Expense',10,'create','192',NULL,'2021-09-07 21:50:33','---\nid:\n- \n- 10\nexpense:\n- \n- 21.22\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-04 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:50:33.000000000 +05:00\n'),(246,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.93e3\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:50:33.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:51:33','---\namount:\n- !ruby/object:BigDecimal 18:-0.93e3\n- !ruby/object:BigDecimal 18:-0.1839e4\nupdated_at:\n- 2021-09-07 21:50:33.000000000 +05:00\n- 2021-09-07 21:51:33.000000000 +05:00\n'),(247,'Payment',13,'update','192','---\nid: 13\ndebit: !ruby/object:BigDecimal 18:0.909e3\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 11\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:51:33.000000000 +05:00\nupdated_at: 2021-09-07 21:51:33.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:51:33','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.1839e4\n'),(248,'Payment',13,'create','192',NULL,'2021-09-07 21:51:33','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.1839e4\n'),(249,'ExpenseEntry',11,'create','192',NULL,'2021-09-07 21:51:33','---\nid:\n- \n- 11\namount:\n- \n- 909.81\nexpense_id:\n- \n- 11\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 1\ncomment:\n- \n- Home Depot\ncreated_at:\n- \n- 2021-09-07 21:51:33.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:51:33.000000000 +05:00\n'),(250,'Expense',11,'create','192',NULL,'2021-09-07 21:51:33','---\nid:\n- \n- 11\nexpense:\n- \n- 909.81\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-04 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:51:33.000000000 +05:00\n'),(251,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.1839e4\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:51:33.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:54:42','---\namount:\n- !ruby/object:BigDecimal 18:-0.1839e4\n- !ruby/object:BigDecimal 18:-0.1866e4\nupdated_at:\n- 2021-09-07 21:51:33.000000000 +05:00\n- 2021-09-07 21:54:42.000000000 +05:00\n'),(252,'Payment',14,'update','192','---\nid: 14\ndebit: !ruby/object:BigDecimal 18:0.27e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 12\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:54:42.000000000 +05:00\nupdated_at: 2021-09-07 21:54:42.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:54:42','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.1866e4\n'),(253,'Payment',14,'create','192',NULL,'2021-09-07 21:54:42','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.1866e4\n'),(254,'ExpenseEntry',12,'create','192',NULL,'2021-09-07 21:54:42','---\nid:\n- \n- 12\namount:\n- \n- 27.16\nexpense_id:\n- \n- 12\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 1\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-07 21:54:42.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:54:42.000000000 +05:00\n'),(255,'Expense',12,'create','192',NULL,'2021-09-07 21:54:42','---\nid:\n- \n- 12\nexpense:\n- \n- 27.16\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-06 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:54:42.000000000 +05:00\n'),(256,'ExpenseEntry',12,'update','192','---\nexpense_id: 12\nid: 12\namount: 27.16\ncomment: \'\'\naccount_id: 1\nexpense_type_id: 7\nstatus: \ncreated_at: 2021-09-06 00:00:00.000000000 +05:00\nupdated_at: 2021-09-07 21:54:42.000000000 +05:00\nexpenseable_type: \nexpenseable_id: \n','2021-09-07 21:55:22','---\ncomment:\n- \'\'\n- United Building Supply\nupdated_at:\n- 2021-09-07 21:54:42.000000000 +05:00\n- 2021-09-07 21:55:22.000000000 +05:00\n'),(257,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.1866e4\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:54:42.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:56:13','---\namount:\n- !ruby/object:BigDecimal 18:-0.1866e4\n- !ruby/object:BigDecimal 18:-0.2497e4\nupdated_at:\n- 2021-09-07 21:54:42.000000000 +05:00\n- 2021-09-07 21:56:13.000000000 +05:00\n'),(258,'Payment',15,'update','192','---\nid: 15\ndebit: !ruby/object:BigDecimal 18:0.631e3\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 13\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:56:13.000000000 +05:00\nupdated_at: 2021-09-07 21:56:13.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:56:13','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2497e4\n'),(259,'Payment',15,'create','192',NULL,'2021-09-07 21:56:13','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2497e4\n'),(260,'ExpenseEntry',13,'create','192',NULL,'2021-09-07 21:56:13','---\nid:\n- \n- 13\namount:\n- \n- 631.39\nexpense_id:\n- \n- 13\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 1\ncomment:\n- \n- united Building material\ncreated_at:\n- \n- 2021-09-07 21:56:13.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:56:13.000000000 +05:00\n'),(261,'Expense',13,'create','192',NULL,'2021-09-07 21:56:13','---\nid:\n- \n- 13\nexpense:\n- \n- 631.39\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-06 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:56:13.000000000 +05:00\n'),(262,'Expense',13,'update','192','---\nid: 13\nexpense: 631.39\ncomment: \'\'\ncreated_at: 2021-09-06 00:00:00.000000000 +05:00\nexpense_type_id: \nupdated_at: 2021-09-07 21:56:13.000000000 +05:00\naccount_id: \n','2021-09-07 21:56:44','---\ncomment:\n- \'\'\n- Far Rockaway\nupdated_at:\n- 2021-09-07 21:56:13.000000000 +05:00\n- 2021-09-07 21:56:44.000000000 +05:00\n'),(263,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.2497e4\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:56:13.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:57:42','---\namount:\n- !ruby/object:BigDecimal 18:-0.2497e4\n- !ruby/object:BigDecimal 18:-0.2518e4\nupdated_at:\n- 2021-09-07 21:56:13.000000000 +05:00\n- 2021-09-07 21:57:42.000000000 +05:00\n'),(264,'Payment',16,'update','192','---\nid: 16\ndebit: !ruby/object:BigDecimal 18:0.21e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 14\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:57:42.000000000 +05:00\nupdated_at: 2021-09-07 21:57:42.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:57:42','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2518e4\n'),(265,'Payment',16,'create','192',NULL,'2021-09-07 21:57:42','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2518e4\n'),(266,'ExpenseEntry',14,'create','192',NULL,'2021-09-07 21:57:42','---\nid:\n- \n- 14\namount:\n- \n- 21.32\nexpense_id:\n- \n- 14\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 1\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-07 21:57:42.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:57:42.000000000 +05:00\n'),(267,'Expense',14,'create','192',NULL,'2021-09-07 21:57:42','---\nid:\n- \n- 14\nexpense:\n- \n- 21.32\ncomment:\n- \n- seagirt deli\ncreated_at:\n- \n- 2021-09-06 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:57:42.000000000 +05:00\n'),(268,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.2518e4\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:57:42.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:58:27','---\namount:\n- !ruby/object:BigDecimal 18:-0.2518e4\n- !ruby/object:BigDecimal 18:-0.2537e4\nupdated_at:\n- 2021-09-07 21:57:42.000000000 +05:00\n- 2021-09-07 21:58:27.000000000 +05:00\n'),(269,'Payment',17,'update','192','---\nid: 17\ndebit: !ruby/object:BigDecimal 18:0.19e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 15\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:58:27.000000000 +05:00\nupdated_at: 2021-09-07 21:58:27.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:58:27','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2537e4\n'),(270,'Payment',17,'create','192',NULL,'2021-09-07 21:58:27','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2537e4\n'),(271,'ExpenseEntry',15,'create','192',NULL,'2021-09-07 21:58:27','---\nid:\n- \n- 15\namount:\n- \n- 19.76\nexpense_id:\n- \n- 15\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 1\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-07 21:58:27.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:58:27.000000000 +05:00\n'),(272,'Expense',15,'create','192',NULL,'2021-09-07 21:58:27','---\nid:\n- \n- 15\nexpense:\n- \n- 19.76\ncomment:\n- \n- Seagirt Deli\ncreated_at:\n- \n- 2021-09-06 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:58:27.000000000 +05:00\n'),(273,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.2537e4\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:58:27.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 21:59:27','---\namount:\n- !ruby/object:BigDecimal 18:-0.2537e4\n- !ruby/object:BigDecimal 18:-0.2609e4\nupdated_at:\n- 2021-09-07 21:58:27.000000000 +05:00\n- 2021-09-07 21:59:27.000000000 +05:00\n'),(274,'Payment',18,'update','192','---\nid: 18\ndebit: !ruby/object:BigDecimal 18:0.72e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 16\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 21:59:27.000000000 +05:00\nupdated_at: 2021-09-07 21:59:27.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 21:59:27','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2609e4\n'),(275,'Payment',18,'create','192',NULL,'2021-09-07 21:59:27','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2609e4\n'),(276,'ExpenseEntry',16,'create','192',NULL,'2021-09-07 21:59:27','---\nid:\n- \n- 16\namount:\n- \n- 72.0\nexpense_id:\n- \n- 16\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 1\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-07 21:59:27.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:59:27.000000000 +05:00\n'),(277,'Expense',16,'create','192',NULL,'2021-09-07 21:59:27','---\nid:\n- \n- 16\nexpense:\n- \n- 72.0\ncomment:\n- \n- \'unlead cr #02\'\ncreated_at:\n- \n- 2021-09-07 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 21:59:27.000000000 +05:00\n'),(278,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.2609e4\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 21:59:27.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 22:00:02','---\namount:\n- !ruby/object:BigDecimal 18:-0.2609e4\n- !ruby/object:BigDecimal 18:-0.2623e4\nupdated_at:\n- 2021-09-07 21:59:27.000000000 +05:00\n- 2021-09-07 22:00:02.000000000 +05:00\n'),(279,'Payment',19,'update','192','---\nid: 19\ndebit: !ruby/object:BigDecimal 18:0.14e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 17\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 22:00:02.000000000 +05:00\nupdated_at: 2021-09-07 22:00:02.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 22:00:02','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2623e4\n'),(280,'Payment',19,'create','192',NULL,'2021-09-07 22:00:02','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2623e4\n'),(281,'ExpenseEntry',17,'create','192',NULL,'2021-09-07 22:00:02','---\nid:\n- \n- 17\namount:\n- \n- 14.56\nexpense_id:\n- \n- 17\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 1\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-07 22:00:02.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 22:00:02.000000000 +05:00\n'),(282,'Expense',17,'create','192',NULL,'2021-09-07 22:00:02','---\nid:\n- \n- 17\nexpense:\n- \n- 14.56\ncomment:\n- \n- \'Sami Mini Mart \'\ncreated_at:\n- \n- 2021-09-07 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 22:00:02.000000000 +05:00\n'),(283,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.2623e4\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 22:00:02.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-07 22:00:31','---\namount:\n- !ruby/object:BigDecimal 18:-0.2623e4\n- !ruby/object:BigDecimal 18:-0.2636e4\nupdated_at:\n- 2021-09-07 22:00:02.000000000 +05:00\n- 2021-09-07 22:00:31.000000000 +05:00\n'),(284,'Payment',20,'update','192','---\nid: 20\ndebit: !ruby/object:BigDecimal 18:0.13e2\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 18\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-07 22:00:31.000000000 +05:00\nupdated_at: 2021-09-07 22:00:31.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-07 22:00:31','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2636e4\n'),(285,'Payment',20,'create','192',NULL,'2021-09-07 22:00:31','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2636e4\n'),(286,'ExpenseEntry',18,'create','192',NULL,'2021-09-07 22:00:31','---\nid:\n- \n- 18\namount:\n- \n- 13.52\nexpense_id:\n- \n- 18\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 1\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-07 22:00:31.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 22:00:31.000000000 +05:00\n'),(287,'Expense',18,'create','192',NULL,'2021-09-07 22:00:31','---\nid:\n- \n- 18\nexpense:\n- \n- 13.52\ncomment:\n- \n- Aurora Deli\ncreated_at:\n- \n- 2021-09-07 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-07 22:00:31.000000000 +05:00\n'),(288,'Payment',21,'update','192','---\nid: 21\ndebit: \ncredit: !ruby/object:BigDecimal 18:0.0\naccount_id: 2\npaymentable_type: \npaymentable_id: \namount: \nstatus: \ncomment: Opening Balance\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-14 22:45:51.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-14 22:45:51','---\namount:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(289,'Payment',21,'create','192',NULL,'2021-09-14 22:45:51','---\namount:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(290,'Account',2,'create','192',NULL,'2021-09-14 22:45:51',NULL),(291,'Payment',22,'update','192','---\nid: 22\ndebit: \ncredit: !ruby/object:BigDecimal 18:0.0\naccount_id: 3\npaymentable_type: \npaymentable_id: \namount: \nstatus: \ncomment: Opening Balance\ncreated_at: 2021-09-14 22:46:14.000000000 +05:00\nupdated_at: 2021-09-14 22:46:14.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-14 22:46:14','---\namount:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(292,'Payment',22,'create','192',NULL,'2021-09-14 22:46:14','---\namount:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(293,'Account',3,'create','192',NULL,'2021-09-14 22:46:14',NULL),(294,'Payment',23,'update','192','---\nid: 23\ndebit: \ncredit: !ruby/object:BigDecimal 18:0.0\naccount_id: 4\npaymentable_type: \npaymentable_id: \namount: \nstatus: \ncomment: Opening Balance\ncreated_at: 2021-09-14 22:46:34.000000000 +05:00\nupdated_at: 2021-09-14 22:46:34.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-14 22:46:34','---\namount:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(295,'Payment',23,'create','192',NULL,'2021-09-14 22:46:34','---\namount:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(296,'Account',4,'create','192',NULL,'2021-09-14 22:46:34',NULL),(297,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:0.0\nid: 2\ntitle: ADDEL CARD\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-14 22:45:51.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-14 22:47:14','---\namount:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:-0.6e3\nupdated_at:\n- 2021-09-14 22:45:51.000000000 +05:00\n- 2021-09-14 22:47:14.000000000 +05:00\n'),(298,'Payment',24,'update','192','---\nid: 24\ndebit: !ruby/object:BigDecimal 18:0.6e3\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 19\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-14 22:47:14.000000000 +05:00\nupdated_at: 2021-09-14 22:47:14.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-14 22:47:14','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.6e3\n'),(299,'Payment',24,'create','192',NULL,'2021-09-14 22:47:14','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.6e3\n'),(300,'ExpenseEntry',19,'create','192',NULL,'2021-09-14 22:47:14','---\nid:\n- \n- 19\namount:\n- \n- 600.09\nexpense_id:\n- \n- 19\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 2\ncomment:\n- \n- CASA Building Materials\ncreated_at:\n- \n- 2021-09-14 22:47:14.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 22:47:14.000000000 +05:00\n'),(301,'Expense',19,'create','192',NULL,'2021-09-14 22:47:14','---\nid:\n- \n- 19\nexpense:\n- \n- 600.09\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-14 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 22:47:14.000000000 +05:00\n'),(302,'Expense',19,'update','192','---\nid: 19\nexpense: 600.09\ncomment: \'\'\ncreated_at: 2021-09-14 00:00:00.000000000 +05:00\nexpense_type_id: \nupdated_at: 2021-09-14 22:47:14.000000000 +05:00\naccount_id: \n','2021-09-14 22:47:34','---\ncreated_at:\n- 2021-09-14 00:00:00.000000000 +05:00\n- 2021-09-08 00:00:00.000000000 +05:00\nupdated_at:\n- 2021-09-14 22:47:14.000000000 +05:00\n- 2021-09-14 22:47:34.000000000 +05:00\n'),(303,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.6e3\nid: 2\ntitle: ADDEL CARD\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-14 22:47:14.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-14 22:48:16','---\namount:\n- !ruby/object:BigDecimal 18:-0.6e3\n- !ruby/object:BigDecimal 18:-0.673e3\nupdated_at:\n- 2021-09-14 22:47:14.000000000 +05:00\n- 2021-09-14 22:48:16.000000000 +05:00\n'),(304,'Payment',25,'update','192','---\nid: 25\ndebit: !ruby/object:BigDecimal 18:0.73e2\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 20\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-14 22:48:16.000000000 +05:00\nupdated_at: 2021-09-14 22:48:16.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-14 22:48:16','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.673e3\n'),(305,'Payment',25,'create','192',NULL,'2021-09-14 22:48:16','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.673e3\n'),(306,'ExpenseEntry',20,'create','192',NULL,'2021-09-14 22:48:16','---\nid:\n- \n- 20\namount:\n- \n- 73.97\nexpense_id:\n- \n- 20\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 2\ncomment:\n- \n- CASA BUILDING MATERIALS\ncreated_at:\n- \n- 2021-09-14 22:48:16.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 22:48:16.000000000 +05:00\n'),(307,'Expense',20,'create','192',NULL,'2021-09-14 22:48:16','---\nid:\n- \n- 20\nexpense:\n- \n- 73.97\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-14 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 22:48:16.000000000 +05:00\n'),(308,'Expense',20,'update','192','---\nid: 20\nexpense: 73.97\ncomment: \'\'\ncreated_at: 2021-09-14 00:00:00.000000000 +05:00\nexpense_type_id: \nupdated_at: 2021-09-14 22:48:16.000000000 +05:00\naccount_id: \n','2021-09-14 22:48:25','---\ncreated_at:\n- 2021-09-14 00:00:00.000000000 +05:00\n- 2021-09-08 00:00:00.000000000 +05:00\nupdated_at:\n- 2021-09-14 22:48:16.000000000 +05:00\n- 2021-09-14 22:48:25.000000000 +05:00\n'),(309,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.673e3\nid: 2\ntitle: ADDEL CARD\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-14 22:48:16.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-14 22:48:59','---\namount:\n- !ruby/object:BigDecimal 18:-0.673e3\n- !ruby/object:BigDecimal 18:-0.683e3\nupdated_at:\n- 2021-09-14 22:48:16.000000000 +05:00\n- 2021-09-14 22:48:59.000000000 +05:00\n'),(310,'Payment',26,'update','192','---\nid: 26\ndebit: !ruby/object:BigDecimal 18:0.1e2\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 21\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-14 22:48:59.000000000 +05:00\nupdated_at: 2021-09-14 22:48:59.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-14 22:48:59','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.683e3\n'),(311,'Payment',26,'create','192',NULL,'2021-09-14 22:48:59','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.683e3\n'),(312,'ExpenseEntry',21,'create','192',NULL,'2021-09-14 22:48:59','---\nid:\n- \n- 21\namount:\n- \n- 10.92\nexpense_id:\n- \n- 21\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 2\ncomment:\n- \n- SAMI MINI MART\ncreated_at:\n- \n- 2021-09-14 22:48:59.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 22:48:59.000000000 +05:00\n'),(313,'Expense',21,'create','192',NULL,'2021-09-14 22:48:59','---\nid:\n- \n- 21\nexpense:\n- \n- 10.92\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-08 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 22:48:59.000000000 +05:00\n'),(314,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.683e3\nid: 2\ntitle: ADDEL CARD\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-14 22:48:59.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-14 22:51:07','---\namount:\n- !ruby/object:BigDecimal 18:-0.683e3\n- !ruby/object:BigDecimal 18:-0.692e3\nupdated_at:\n- 2021-09-14 22:48:59.000000000 +05:00\n- 2021-09-14 22:51:07.000000000 +05:00\n'),(315,'Payment',27,'update','192','---\nid: 27\ndebit: !ruby/object:BigDecimal 18:0.9e1\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 22\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-14 22:51:07.000000000 +05:00\nupdated_at: 2021-09-14 22:51:07.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-14 22:51:07','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.692e3\n'),(316,'Payment',27,'create','192',NULL,'2021-09-14 22:51:07','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.692e3\n'),(317,'ExpenseEntry',22,'create','192',NULL,'2021-09-14 22:51:07','---\nid:\n- \n- 22\namount:\n- \n- 9.0\nexpense_id:\n- \n- 22\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 2\ncomment:\n- \n- FELOMAR GROCERY\ncreated_at:\n- \n- 2021-09-14 22:51:07.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 22:51:07.000000000 +05:00\n'),(318,'Expense',22,'create','192',NULL,'2021-09-14 22:51:07','---\nid:\n- \n- 22\nexpense:\n- \n- 9.0\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-09 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 22:51:07.000000000 +05:00\n'),(319,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.692e3\nid: 2\ntitle: ADDEL CARD\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-14 22:51:07.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-14 22:52:19','---\namount:\n- !ruby/object:BigDecimal 18:-0.692e3\n- !ruby/object:BigDecimal 18:-0.714e3\nupdated_at:\n- 2021-09-14 22:51:07.000000000 +05:00\n- 2021-09-14 22:52:19.000000000 +05:00\n'),(320,'Payment',28,'update','192','---\nid: 28\ndebit: !ruby/object:BigDecimal 18:0.22e2\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 23\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-14 22:52:19.000000000 +05:00\nupdated_at: 2021-09-14 22:52:19.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-14 22:52:19','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.714e3\n'),(321,'Payment',28,'create','192',NULL,'2021-09-14 22:52:19','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.714e3\n'),(322,'ExpenseEntry',23,'create','192',NULL,'2021-09-14 22:52:19','---\nid:\n- \n- 23\namount:\n- \n- 22.88\nexpense_id:\n- \n- 23\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 2\ncomment:\n- \n- MINI MART\ncreated_at:\n- \n- 2021-09-14 22:52:19.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 22:52:19.000000000 +05:00\n'),(323,'Expense',23,'create','192',NULL,'2021-09-14 22:52:19','---\nid:\n- \n- 23\nexpense:\n- \n- 22.88\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-10 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 22:52:19.000000000 +05:00\n'),(324,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.714e3\nid: 2\ntitle: ADDEL CARD\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-14 22:52:19.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-14 22:53:10','---\namount:\n- !ruby/object:BigDecimal 18:-0.714e3\n- !ruby/object:BigDecimal 18:-0.722e3\nupdated_at:\n- 2021-09-14 22:52:19.000000000 +05:00\n- 2021-09-14 22:53:10.000000000 +05:00\n'),(325,'Payment',29,'update','192','---\nid: 29\ndebit: !ruby/object:BigDecimal 18:0.8e1\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 24\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-14 22:53:10.000000000 +05:00\nupdated_at: 2021-09-14 22:53:10.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-14 22:53:10','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.722e3\n'),(326,'Payment',29,'create','192',NULL,'2021-09-14 22:53:10','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.722e3\n'),(327,'ExpenseEntry',24,'create','192',NULL,'2021-09-14 22:53:10','---\nid:\n- \n- 24\namount:\n- \n- 8.14\nexpense_id:\n- \n- 24\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 2\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-14 22:53:10.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 22:53:10.000000000 +05:00\n'),(328,'Expense',24,'create','192',NULL,'2021-09-14 22:53:10','---\nid:\n- \n- 24\nexpense:\n- \n- 8.14\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-14 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 22:53:10.000000000 +05:00\n'),(329,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.722e3\nid: 2\ntitle: ADDEL CARD\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-14 22:53:10.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-14 22:58:53','---\namount:\n- !ruby/object:BigDecimal 18:-0.722e3\n- !ruby/object:BigDecimal 18:-0.803e3\nupdated_at:\n- 2021-09-14 22:53:10.000000000 +05:00\n- 2021-09-14 22:58:53.000000000 +05:00\n'),(330,'Payment',30,'update','192','---\nid: 30\ndebit: !ruby/object:BigDecimal 18:0.81e2\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 25\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-14 22:58:53.000000000 +05:00\nupdated_at: 2021-09-14 22:58:53.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-14 22:58:53','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.803e3\n'),(331,'Payment',30,'create','192',NULL,'2021-09-14 22:58:53','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.803e3\n'),(332,'ExpenseEntry',25,'create','192',NULL,'2021-09-14 22:58:53','---\nid:\n- \n- 25\namount:\n- \n- 81.35\nexpense_id:\n- \n- 25\nexpense_type_id:\n- \n- 3\naccount_id:\n- \n- 2\ncomment:\n- \n- 1346 beach channel\ncreated_at:\n- \n- 2021-09-14 22:58:53.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 22:58:53.000000000 +05:00\n'),(333,'Expense',25,'create','192',NULL,'2021-09-14 22:58:53','---\nid:\n- \n- 25\nexpense:\n- \n- 81.35\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-13 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 22:58:53.000000000 +05:00\n'),(334,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.803e3\nid: 2\ntitle: ADDEL CARD\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-14 22:58:53.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-14 23:00:05','---\namount:\n- !ruby/object:BigDecimal 18:-0.803e3\n- !ruby/object:BigDecimal 18:-0.834e3\nupdated_at:\n- 2021-09-14 22:58:53.000000000 +05:00\n- 2021-09-14 23:00:05.000000000 +05:00\n'),(335,'Payment',31,'update','192','---\nid: 31\ndebit: !ruby/object:BigDecimal 18:0.31e2\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 26\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-14 23:00:05.000000000 +05:00\nupdated_at: 2021-09-14 23:00:05.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-14 23:00:05','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.834e3\n'),(336,'Payment',31,'create','192',NULL,'2021-09-14 23:00:05','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.834e3\n'),(337,'ExpenseEntry',26,'create','192',NULL,'2021-09-14 23:00:05','---\nid:\n- \n- 26\namount:\n- \n- 31.16\nexpense_id:\n- \n- 26\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 2\ncomment:\n- \n- METRO BUILDING SUPPLY\ncreated_at:\n- \n- 2021-09-14 23:00:05.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 23:00:05.000000000 +05:00\n'),(338,'Expense',26,'create','192',NULL,'2021-09-14 23:00:05','---\nid:\n- \n- 26\nexpense:\n- \n- 31.16\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-13 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 23:00:05.000000000 +05:00\n'),(339,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.834e3\nid: 2\ntitle: ADDEL CARD\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-14 23:00:05.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-14 23:35:21','---\namount:\n- !ruby/object:BigDecimal 18:-0.834e3\n- !ruby/object:BigDecimal 18:-0.85e3\nupdated_at:\n- 2021-09-14 23:00:05.000000000 +05:00\n- 2021-09-14 23:35:21.000000000 +05:00\n'),(340,'Payment',32,'update','192','---\nid: 32\ndebit: !ruby/object:BigDecimal 18:0.16e2\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 27\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-14 23:35:21.000000000 +05:00\nupdated_at: 2021-09-14 23:35:21.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-14 23:35:21','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.85e3\n'),(341,'Payment',32,'create','192',NULL,'2021-09-14 23:35:21','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.85e3\n'),(342,'ExpenseEntry',27,'create','192',NULL,'2021-09-14 23:35:21','---\nid:\n- \n- 27\namount:\n- \n- 16.64\nexpense_id:\n- \n- 27\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 2\ncomment:\n- \n- seagirt deli and grill\ncreated_at:\n- \n- 2021-09-14 23:35:21.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 23:35:21.000000000 +05:00\n'),(343,'Expense',27,'create','192',NULL,'2021-09-14 23:35:21','---\nid:\n- \n- 27\nexpense:\n- \n- 16.64\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-14 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 23:35:21.000000000 +05:00\n'),(344,'Account',4,'update','192','---\namount: !ruby/object:BigDecimal 18:0.0\nid: 4\ntitle: Abdul Card\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:46:34.000000000 +05:00\nupdated_at: 2021-09-14 22:46:34.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-14 23:36:42','---\namount:\n- !ruby/object:BigDecimal 18:0.0\n- !ruby/object:BigDecimal 18:-0.1e2\nupdated_at:\n- 2021-09-14 22:46:34.000000000 +05:00\n- 2021-09-14 23:36:42.000000000 +05:00\n'),(345,'Payment',33,'update','192','---\nid: 33\ndebit: !ruby/object:BigDecimal 18:0.1e2\ncredit: \naccount_id: 4\npaymentable_type: ExpenseEntry\npaymentable_id: 28\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-14 23:36:42.000000000 +05:00\nupdated_at: 2021-09-14 23:36:42.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-14 23:36:42','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.1e2\n'),(346,'Payment',33,'create','192',NULL,'2021-09-14 23:36:42','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.1e2\n'),(347,'ExpenseEntry',28,'create','192',NULL,'2021-09-14 23:36:42','---\nid:\n- \n- 28\namount:\n- \n- 10.92\nexpense_id:\n- \n- 28\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 4\ncomment:\n- \n- Milano Italian\ncreated_at:\n- \n- 2021-09-14 23:36:42.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 23:36:42.000000000 +05:00\n'),(348,'Expense',28,'create','192',NULL,'2021-09-14 23:36:42','---\nid:\n- \n- 28\nexpense:\n- \n- 10.92\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-14 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-14 23:36:42.000000000 +05:00\n'),(349,'User',192,'update','192','---\nencrypted_password: \"$2a$11$FcErLWjlKdOZtpcByWOrS.o.7nQpa4fZuIdeWISeGEsSG2BmjD466\"\nid: 192\nroles_mask: 2\ncompany_type: alarsh\nremember_created_at: 2021-09-01 23:17:45.000000000 +05:00\nemail: alarsh_super_admin@gmail.com\nreset_password_token: \nreset_password_sent_at: \nsign_in_count: 0\ncurrent_sign_in_at: \nlast_sign_in_at: \nfailed_attempts: 0\nunlock_token: \nlocked_at: \ncreated_at: 2021-08-31 18:49:17.000000000 +05:00\nupdated_at: 2021-09-01 23:50:56.000000000 +05:00\nname: SuperAdmin\nuser_name: alarsh_super_admin\nfather_name: \'\'\ncity: Ronkonkoma\nphone: \'7184315203\'\nfax: \'\'\naddress: 309 Deer Road\ncreated_by_id: 99\nemail_to: alarshny@yahoo.com,info@alarshconstruction.com\nemail_cc: info@alarshconstruction.com\nemail_bcc: alarshny@yahoo.com\n','2021-09-15 20:35:47','---\nremember_created_at:\n- 2021-09-01 23:17:45.000000000 +05:00\n- \nupdated_at:\n- 2021-09-01 23:50:56.000000000 +05:00\n- 2021-09-15 20:35:47.000000000 +05:00\n'),(350,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.85e3\nid: 2\ntitle: ADDEL CARD\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-14 23:35:21.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-15 21:30:47','---\namount:\n- !ruby/object:BigDecimal 18:-0.85e3\n- !ruby/object:BigDecimal 18:-0.1546e4\nupdated_at:\n- 2021-09-14 23:35:21.000000000 +05:00\n- 2021-09-15 21:30:47.000000000 +05:00\n'),(351,'Payment',34,'update','192','---\nid: 34\ndebit: !ruby/object:BigDecimal 18:0.696e3\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 29\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-15 21:30:47.000000000 +05:00\nupdated_at: 2021-09-15 21:30:47.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-15 21:30:47','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.1546e4\n'),(352,'Payment',34,'create','192',NULL,'2021-09-15 21:30:47','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.1546e4\n'),(353,'ExpenseEntry',29,'create','192',NULL,'2021-09-15 21:30:47','---\nid:\n- \n- 29\namount:\n- \n- 696.9\nexpense_id:\n- \n- 29\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 2\ncomment:\n- \n- New Castle building material\ncreated_at:\n- \n- 2021-09-15 21:30:47.000000000 +05:00\nupdated_at:\n- \n- 2021-09-15 21:30:47.000000000 +05:00\n'),(354,'Expense',29,'create','192',NULL,'2021-09-15 21:30:47','---\nid:\n- \n- 29\nexpense:\n- \n- 696.9\ncomment:\n- \n- Brooklyn 836 Washington ave\ncreated_at:\n- \n- 2021-09-15 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-15 21:30:47.000000000 +05:00\n'),(355,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.1546e4\nid: 2\ntitle: ADDEL CARD\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-15 21:30:47.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-20 20:26:00','---\namount:\n- !ruby/object:BigDecimal 18:-0.1546e4\n- !ruby/object:BigDecimal 18:-0.197e4\nupdated_at:\n- 2021-09-15 21:30:47.000000000 +05:00\n- 2021-09-20 20:26:00.000000000 +05:00\n'),(356,'Payment',35,'update','192','---\nid: 35\ndebit: !ruby/object:BigDecimal 18:0.424e3\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 30\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-20 20:26:00.000000000 +05:00\nupdated_at: 2021-09-20 20:26:00.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-20 20:26:00','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.197e4\n'),(357,'Payment',35,'create','192',NULL,'2021-09-20 20:26:00','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.197e4\n'),(358,'ExpenseEntry',30,'create','192',NULL,'2021-09-20 20:26:00','---\nid:\n- \n- 30\namount:\n- \n- 424.61\nexpense_id:\n- \n- 30\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 2\ncomment:\n- \n- NEW CASTLE BUILDING PRODUCTS\ncreated_at:\n- \n- 2021-09-20 20:26:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-20 20:26:00.000000000 +05:00\n'),(359,'Expense',30,'create','192',NULL,'2021-09-20 20:26:00','---\nid:\n- \n- 30\nexpense:\n- \n- 424.61\ncomment:\n- \n- BROOKLYN JOBSITE\ncreated_at:\n- \n- 2021-09-20 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-20 20:26:00.000000000 +05:00\n'),(360,'ExpenseEntry',29,'update','192','---\nexpense_id: 29\nid: 29\namount: 696.9\ncomment: New Castle building material\naccount_id: 2\nexpense_type_id: 7\nstatus: \ncreated_at: 2021-09-15 21:30:47.000000000 +05:00\nupdated_at: 2021-09-15 21:30:47.000000000 +05:00\nexpenseable_type: \nexpenseable_id: \n','2021-09-20 20:29:17','---\ncomment:\n- New Castle building material\n- \'Brooklyn 836 Washington ave \'\nupdated_at:\n- 2021-09-15 21:30:47.000000000 +05:00\n- 2021-09-20 20:29:17.000000000 +05:00\n'),(361,'Expense',29,'update','192','---\nid: 29\nexpense: 696.9\ncomment: Brooklyn 836 Washington ave\ncreated_at: 2021-09-15 00:00:00.000000000 +05:00\nexpense_type_id: \nupdated_at: 2021-09-15 21:30:47.000000000 +05:00\naccount_id: \n','2021-09-20 20:29:17','---\ncomment:\n- Brooklyn 836 Washington ave\n- New Castle building material\nupdated_at:\n- 2021-09-15 21:30:47.000000000 +05:00\n- 2021-09-20 20:29:17.000000000 +05:00\n'),(362,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.197e4\nid: 2\ntitle: ADDEL CARD\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-20 20:26:00.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-20 21:08:22','---\namount:\n- !ruby/object:BigDecimal 18:-0.197e4\n- !ruby/object:BigDecimal 18:-0.2555e4\nupdated_at:\n- 2021-09-20 20:26:00.000000000 +05:00\n- 2021-09-20 21:08:22.000000000 +05:00\n'),(363,'Payment',36,'update','192','---\nid: 36\ndebit: !ruby/object:BigDecimal 18:0.585e3\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 31\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-20 21:08:22.000000000 +05:00\nupdated_at: 2021-09-20 21:08:22.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-20 21:08:22','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2555e4\n'),(364,'Payment',36,'create','192',NULL,'2021-09-20 21:08:22','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2555e4\n'),(365,'ExpenseEntry',31,'create','192',NULL,'2021-09-20 21:08:22','---\nid:\n- \n- 31\namount:\n- \n- 585.71\nexpense_id:\n- \n- 31\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 2\ncomment:\n- \n- HOME DEPOT\ncreated_at:\n- \n- 2021-09-20 21:08:22.000000000 +05:00\nupdated_at:\n- \n- 2021-09-20 21:08:22.000000000 +05:00\n'),(366,'Expense',31,'create','192',NULL,'2021-09-20 21:08:22','---\nid:\n- \n- 31\nexpense:\n- \n- 585.71\ncomment:\n- \n- BROOKLYN JOB\ncreated_at:\n- \n- 2021-09-20 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-20 21:08:22.000000000 +05:00\n'),(367,'Account',1,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.2636e4\nid: 1\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-07 22:00:31.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-21 21:06:51','---\namount:\n- !ruby/object:BigDecimal 18:-0.2636e4\n- !ruby/object:BigDecimal 18:-0.3586e4\nupdated_at:\n- 2021-09-07 22:00:31.000000000 +05:00\n- 2021-09-21 21:06:51.000000000 +05:00\n'),(368,'Payment',37,'update','192','---\nid: 37\ndebit: !ruby/object:BigDecimal 18:0.95e3\ncredit: \naccount_id: 1\npaymentable_type: ExpenseEntry\npaymentable_id: 32\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-21 21:06:51.000000000 +05:00\nupdated_at: 2021-09-21 21:06:51.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-21 21:06:51','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.3586e4\n'),(369,'Payment',37,'create','192',NULL,'2021-09-21 21:06:51','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.3586e4\n'),(370,'ExpenseEntry',32,'create','192',NULL,'2021-09-21 21:06:51','---\nid:\n- \n- 32\namount:\n- \n- 950.96\nexpense_id:\n- \n- 32\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 1\ncomment:\n- \n- 1135 PHELAM PARKWAY\ncreated_at:\n- \n- 2021-09-21 21:06:51.000000000 +05:00\nupdated_at:\n- \n- 2021-09-21 21:06:51.000000000 +05:00\n'),(371,'Expense',32,'create','192',NULL,'2021-09-21 21:06:51','---\nid:\n- \n- 32\nexpense:\n- \n- 950.96\ncomment:\n- \n- GLENWOOD MASON SUPPLY\ncreated_at:\n- \n- 2021-09-21 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-21 21:06:51.000000000 +05:00\n'),(372,'Payment',38,'update','192','---\nid: 38\ndebit: \ncredit: !ruby/object:BigDecimal 18:0.0\naccount_id: 5\npaymentable_type: \npaymentable_id: \namount: \nstatus: \ncomment: Opening Balance\ncreated_at: 2021-09-21 21:15:22.000000000 +05:00\nupdated_at: 2021-09-21 21:15:22.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-21 21:15:22','---\namount:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(373,'Payment',38,'create','192',NULL,'2021-09-21 21:15:22','---\namount:\n- \n- !ruby/object:BigDecimal 18:0.0\n'),(374,'Account',5,'create','192',NULL,'2021-09-21 21:15:22',NULL),(375,'Account',2,'update','192','---\nid: 2\ntitle: ADDEL CARD\nbank_name: American Express\niban_number: \'\'\namount: !ruby/object:BigDecimal 18:-0.2555e4\nuser_id: 194\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-20 21:08:22.000000000 +05:00\ncomment: \n','2021-09-21 21:25:20','---\ntitle:\n- ADDEL CARD\n- Addel Card\nupdated_at:\n- 2021-09-20 21:08:22.000000000 +05:00\n- 2021-09-21 21:25:20.000000000 +05:00\n'),(376,'Account',1,'update','192','---\nid: 1\namount: !ruby/object:BigDecimal 18:-0.3586e4\ntitle: Company Cash\nbank_name: \'\'\niban_number: \'\'\ncreated_at: 2021-08-31 14:04:23.000000000 +05:00\nupdated_at: 2021-09-21 21:06:51.000000000 +05:00\ncomment: \nuser_id: \n','2021-09-21 21:25:53','---\namount:\n- !ruby/object:BigDecimal 18:-0.3586e4\n- !ruby/object:BigDecimal 18:0.0\nupdated_at:\n- 2021-09-21 21:06:51.000000000 +05:00\n- 2021-09-21 21:25:53.000000000 +05:00\n'),(377,'ExpenseEntry',32,'update','192','---\nexpense_id: 32\nid: 32\namount: 950.96\ncomment: 1135 PHELAM PARKWAY\naccount_id: 1\nexpense_type_id: 7\nstatus: \ncreated_at: 2021-09-21 21:06:51.000000000 +05:00\nupdated_at: 2021-09-21 21:06:51.000000000 +05:00\nexpenseable_type: \nexpenseable_id: \n','2021-09-21 21:25:53','---\naccount_id:\n- 1\n- 5\nupdated_at:\n- 2021-09-21 21:06:51.000000000 +05:00\n- 2021-09-21 21:25:53.000000000 +05:00\n'),(378,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.2555e4\nid: 2\ntitle: Addel Card\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-21 21:25:20.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-27 21:06:37','---\namount:\n- !ruby/object:BigDecimal 18:-0.2555e4\n- !ruby/object:BigDecimal 18:-0.2651e4\nupdated_at:\n- 2021-09-21 21:25:20.000000000 +05:00\n- 2021-09-27 21:06:37.000000000 +05:00\n'),(379,'Payment',39,'update','192','---\nid: 39\ndebit: !ruby/object:BigDecimal 18:0.96e2\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 33\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-27 21:06:37.000000000 +05:00\nupdated_at: 2021-09-27 21:06:37.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-27 21:06:37','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2651e4\n'),(380,'Payment',39,'create','192',NULL,'2021-09-27 21:06:37','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2651e4\n'),(381,'ExpenseEntry',33,'create','192',NULL,'2021-09-27 21:06:37','---\nid:\n- \n- 33\namount:\n- \n- 96.76\nexpense_id:\n- \n- 33\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 2\ncomment:\n- \n- Far Rockaway\ncreated_at:\n- \n- 2021-09-27 21:06:37.000000000 +05:00\nupdated_at:\n- \n- 2021-09-27 21:06:37.000000000 +05:00\n'),(382,'Expense',33,'create','192',NULL,'2021-09-27 21:06:37','---\nid:\n- \n- 33\nexpense:\n- \n- 96.76\ncomment:\n- \n- Materials\ncreated_at:\n- \n- 2021-09-27 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-27 21:06:37.000000000 +05:00\n'),(383,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.2651e4\nid: 2\ntitle: Addel Card\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-27 21:06:37.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-27 21:07:42','---\namount:\n- !ruby/object:BigDecimal 18:-0.2651e4\n- !ruby/object:BigDecimal 18:-0.2671e4\nupdated_at:\n- 2021-09-27 21:06:37.000000000 +05:00\n- 2021-09-27 21:07:42.000000000 +05:00\n'),(384,'Payment',40,'update','192','---\nid: 40\ndebit: !ruby/object:BigDecimal 18:0.2e2\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 34\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-27 21:07:42.000000000 +05:00\nupdated_at: 2021-09-27 21:07:42.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-27 21:07:42','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2671e4\n'),(385,'Payment',40,'create','192',NULL,'2021-09-27 21:07:42','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2671e4\n'),(386,'ExpenseEntry',34,'create','192',NULL,'2021-09-27 21:07:42','---\nid:\n- \n- 34\namount:\n- \n- 20.8\nexpense_id:\n- \n- 34\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 2\ncomment:\n- \n- Breakfast Far Rkwy\ncreated_at:\n- \n- 2021-09-27 21:07:42.000000000 +05:00\nupdated_at:\n- \n- 2021-09-27 21:07:42.000000000 +05:00\n'),(387,'Expense',34,'create','192',NULL,'2021-09-27 21:07:42','---\nid:\n- \n- 34\nexpense:\n- \n- 20.8\ncomment:\n- \n- \'\'\ncreated_at:\n- \n- 2021-09-27 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-27 21:07:42.000000000 +05:00\n'),(388,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.2671e4\nid: 2\ntitle: Addel Card\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-27 21:07:42.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-27 21:17:31','---\namount:\n- !ruby/object:BigDecimal 18:-0.2671e4\n- !ruby/object:BigDecimal 18:-0.2692e4\nupdated_at:\n- 2021-09-27 21:07:42.000000000 +05:00\n- 2021-09-27 21:17:31.000000000 +05:00\n'),(389,'Payment',41,'update','192','---\nid: 41\ndebit: !ruby/object:BigDecimal 18:0.21e2\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 35\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-27 21:17:31.000000000 +05:00\nupdated_at: 2021-09-27 21:17:31.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-27 21:17:31','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2692e4\n'),(390,'Payment',41,'create','192',NULL,'2021-09-27 21:17:31','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2692e4\n'),(391,'ExpenseEntry',35,'create','192',NULL,'2021-09-27 21:17:31','---\nid:\n- \n- 35\namount:\n- \n- 21.4\nexpense_id:\n- \n- 35\nexpense_type_id:\n- \n- 7\naccount_id:\n- \n- 2\ncomment:\n- \n- \'Brooklyn \'\ncreated_at:\n- \n- 2021-09-27 21:17:31.000000000 +05:00\nupdated_at:\n- \n- 2021-09-27 21:17:31.000000000 +05:00\n'),(392,'Expense',35,'create','192',NULL,'2021-09-27 21:17:31','---\nid:\n- \n- 35\nexpense:\n- \n- 21.4\ncomment:\n- \n- \'Home Depot \'\ncreated_at:\n- \n- 2021-09-25 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-27 21:17:31.000000000 +05:00\n'),(393,'Account',2,'update','192','---\nid: 2\ntitle: Addel Card\nbank_name: American Express\niban_number: \'\'\namount: !ruby/object:BigDecimal 18:-0.2692e4\nuser_id: 194\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-27 21:17:31.000000000 +05:00\ncomment: \n','2021-09-27 21:20:01','---\ntitle:\n- Addel Card\n- Adeel Card\nupdated_at:\n- 2021-09-27 21:17:31.000000000 +05:00\n- 2021-09-27 21:20:01.000000000 +05:00\n'),(394,'Staff',3,'update','192','---\nid: 3\ncode: AGC-0003\nname: ADDEL ABBAS\nfather: \'\'\neducation: \'\'\ngender: 0\nphone: \'9292715559\'\naddress: \'\'\ncnic: \'\'\ndate_of_joining: \nyearly_increment: \nmonthly_salary: \nwage_rate: !ruby/object:BigDecimal 18:0.0\nbalance: !ruby/object:BigDecimal 18:0.0\nstaff_department: \'\'\ndepartment_id: \nstaff_type: 0\nwage_debit: !ruby/object:BigDecimal 18:0.0\nadvance_amount: !ruby/object:BigDecimal 18:0.0\nterminated: false\nterminated_at: 2021-09-01 00:36:25.000000000 +05:00\ndeleted: false\ndeleted_at: 2021-09-01 00:36:25.000000000 +05:00\ncreated_at: 2021-09-01 00:36:25.000000000 +05:00\nupdated_at: 2021-09-01 00:36:25.000000000 +05:00\ncomment: \nraw_product_quantity: 0.0\nraw_product_quantity_tile: 0.0\n','2021-09-27 21:21:14','---\nname:\n- ADDEL ABBAS\n- ADEEL ABBAS\nupdated_at:\n- 2021-09-01 00:36:25.000000000 +05:00\n- 2021-09-27 21:21:14.000000000 +05:00\n'),(395,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.2692e4\nid: 2\ntitle: Adeel Card\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-27 21:20:01.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-27 23:20:36','---\namount:\n- !ruby/object:BigDecimal 18:-0.2692e4\n- !ruby/object:BigDecimal 18:-0.271e4\nupdated_at:\n- 2021-09-27 21:20:01.000000000 +05:00\n- 2021-09-27 23:20:36.000000000 +05:00\n'),(396,'Payment',42,'update','192','---\nid: 42\ndebit: !ruby/object:BigDecimal 18:0.18e2\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 36\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-27 23:20:36.000000000 +05:00\nupdated_at: 2021-09-27 23:20:36.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-27 23:20:36','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.271e4\n'),(397,'Payment',42,'create','192',NULL,'2021-09-27 23:20:36','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.271e4\n'),(398,'ExpenseEntry',36,'create','192',NULL,'2021-09-27 23:20:36','---\nid:\n- \n- 36\namount:\n- \n- 18.72\nexpense_id:\n- \n- 36\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 2\ncomment:\n- \n- \'Lunch \'\ncreated_at:\n- \n- 2021-09-27 23:20:36.000000000 +05:00\nupdated_at:\n- \n- 2021-09-27 23:20:36.000000000 +05:00\n'),(399,'Expense',36,'create','192',NULL,'2021-09-27 23:20:36','---\nid:\n- \n- 36\nexpense:\n- \n- 18.72\ncomment:\n- \n- \'Far Rockaway \'\ncreated_at:\n- \n- 2021-09-27 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-27 23:20:36.000000000 +05:00\n'),(400,'ExpenseEntry',35,'update','192','---\nexpense_id: 35\nid: 35\namount: 21.4\ncomment: \'Brooklyn \'\naccount_id: 2\nexpense_type_id: 7\nstatus: \ncreated_at: 2021-09-25 00:00:00.000000000 +05:00\nupdated_at: 2021-09-27 21:17:31.000000000 +05:00\nexpenseable_type: \nexpenseable_id: \n','2021-09-29 19:08:49','---\ncomment:\n- \'Brooklyn \'\n- Home Depot\nupdated_at:\n- 2021-09-27 21:17:31.000000000 +05:00\n- 2021-09-29 19:08:49.000000000 +05:00\n'),(401,'Expense',35,'update','192','---\nid: 35\nexpense: 21.4\ncomment: \'Home Depot \'\ncreated_at: 2021-09-25 00:00:00.000000000 +05:00\nexpense_type_id: \nupdated_at: 2021-09-27 21:17:31.000000000 +05:00\naccount_id: \n','2021-09-29 19:08:49','---\ncomment:\n- \'Home Depot \'\n- Brooklyn\nupdated_at:\n- 2021-09-27 21:17:31.000000000 +05:00\n- 2021-09-29 19:08:49.000000000 +05:00\n'),(402,'ExpenseEntry',34,'update','192','---\nexpense_id: 34\nid: 34\namount: 20.8\ncomment: Breakfast Far Rkwy\naccount_id: 2\nexpense_type_id: 2\nstatus: \ncreated_at: 2021-09-27 21:07:42.000000000 +05:00\nupdated_at: 2021-09-27 21:07:42.000000000 +05:00\nexpenseable_type: \nexpenseable_id: \n','2021-09-29 19:09:31','---\ncomment:\n- Breakfast Far Rkwy\n- \'Breakfast \'\nupdated_at:\n- 2021-09-27 21:07:42.000000000 +05:00\n- 2021-09-29 19:09:31.000000000 +05:00\n'),(403,'Expense',34,'update','192','---\nid: 34\nexpense: 20.8\ncomment: \'\'\ncreated_at: 2021-09-27 00:00:00.000000000 +05:00\nexpense_type_id: \nupdated_at: 2021-09-27 21:07:42.000000000 +05:00\naccount_id: \n','2021-09-29 19:09:31','---\ncomment:\n- \'\'\n- Far Rockaway\nupdated_at:\n- 2021-09-27 21:07:42.000000000 +05:00\n- 2021-09-29 19:09:31.000000000 +05:00\n'),(404,'ExpenseEntry',33,'update','192','---\nexpense_id: 33\nid: 33\namount: 96.76\ncomment: Far Rockaway\naccount_id: 2\nexpense_type_id: 7\nstatus: \ncreated_at: 2021-09-27 21:06:37.000000000 +05:00\nupdated_at: 2021-09-27 21:06:37.000000000 +05:00\nexpenseable_type: \nexpenseable_id: \n','2021-09-29 19:09:54','---\ncomment:\n- Far Rockaway\n- MAterials\nupdated_at:\n- 2021-09-27 21:06:37.000000000 +05:00\n- 2021-09-29 19:09:54.000000000 +05:00\n'),(405,'Expense',33,'update','192','---\nid: 33\nexpense: 96.76\ncomment: Materials\ncreated_at: 2021-09-27 00:00:00.000000000 +05:00\nexpense_type_id: \nupdated_at: 2021-09-27 21:06:37.000000000 +05:00\naccount_id: \n','2021-09-29 19:09:54','---\ncomment:\n- Materials\n- Far Rockaway\nupdated_at:\n- 2021-09-27 21:06:37.000000000 +05:00\n- 2021-09-29 19:09:54.000000000 +05:00\n'),(406,'ExpenseEntry',32,'update','192','---\nexpense_id: 32\nid: 32\namount: 950.96\ncomment: 1135 PHELAM PARKWAY\naccount_id: 5\nexpense_type_id: 7\nstatus: \ncreated_at: 2021-09-21 21:06:51.000000000 +05:00\nupdated_at: 2021-09-21 21:25:53.000000000 +05:00\nexpenseable_type: \nexpenseable_id: \n','2021-09-29 19:10:20','---\ncomment:\n- 1135 PHELAM PARKWAY\n- GLENWOOD MASON SUPPLY\nupdated_at:\n- 2021-09-21 21:25:53.000000000 +05:00\n- 2021-09-29 19:10:20.000000000 +05:00\n'),(407,'Expense',32,'update','192','---\nid: 32\nexpense: 950.96\ncomment: GLENWOOD MASON SUPPLY\ncreated_at: 2021-09-21 00:00:00.000000000 +05:00\nexpense_type_id: \nupdated_at: 2021-09-21 21:06:51.000000000 +05:00\naccount_id: \n','2021-09-29 19:10:20','---\ncomment:\n- GLENWOOD MASON SUPPLY\n- 1135 PHELAM PARKWAY\nupdated_at:\n- 2021-09-21 21:06:51.000000000 +05:00\n- 2021-09-29 19:10:20.000000000 +05:00\n'),(408,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.271e4\nid: 2\ntitle: Adeel Card\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-27 23:20:36.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-29 19:28:24','---\namount:\n- !ruby/object:BigDecimal 18:-0.271e4\n- !ruby/object:BigDecimal 18:-0.2725e4\nupdated_at:\n- 2021-09-27 23:20:36.000000000 +05:00\n- 2021-09-29 19:28:24.000000000 +05:00\n'),(409,'Payment',43,'update','192','---\nid: 43\ndebit: !ruby/object:BigDecimal 18:0.15e2\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 37\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-29 19:28:24.000000000 +05:00\nupdated_at: 2021-09-29 19:28:24.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-29 19:28:24','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2725e4\n'),(410,'Payment',43,'create','192',NULL,'2021-09-29 19:28:24','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2725e4\n'),(411,'ExpenseEntry',37,'create','192',NULL,'2021-09-29 19:28:24','---\nid:\n- \n- 37\namount:\n- \n- 15.34\nexpense_id:\n- \n- 37\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 2\ncomment:\n- \n- lunch\ncreated_at:\n- \n- 2021-09-29 19:28:24.000000000 +05:00\nupdated_at:\n- \n- 2021-09-29 19:28:24.000000000 +05:00\n'),(412,'Expense',37,'create','192',NULL,'2021-09-29 19:28:24','---\nid:\n- \n- 37\nexpense:\n- \n- 15.34\ncomment:\n- \n- Far Rockaway\ncreated_at:\n- \n- 2021-09-22 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-29 19:28:24.000000000 +05:00\n'),(413,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.2725e4\nid: 2\ntitle: Adeel Card\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-29 19:28:24.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-29 19:29:28','---\namount:\n- !ruby/object:BigDecimal 18:-0.2725e4\n- !ruby/object:BigDecimal 18:-0.2745e4\nupdated_at:\n- 2021-09-29 19:28:24.000000000 +05:00\n- 2021-09-29 19:29:28.000000000 +05:00\n'),(414,'Payment',44,'update','192','---\nid: 44\ndebit: !ruby/object:BigDecimal 18:0.2e2\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 38\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-29 19:29:28.000000000 +05:00\nupdated_at: 2021-09-29 19:29:28.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-29 19:29:28','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2745e4\n'),(415,'Payment',44,'create','192',NULL,'2021-09-29 19:29:28','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2745e4\n'),(416,'ExpenseEntry',38,'create','192',NULL,'2021-09-29 19:29:28','---\nid:\n- \n- 38\namount:\n- \n- 20.22\nexpense_id:\n- \n- 38\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 2\ncomment:\n- \n- Lunch\ncreated_at:\n- \n- 2021-09-29 19:29:28.000000000 +05:00\nupdated_at:\n- \n- 2021-09-29 19:29:28.000000000 +05:00\n'),(417,'Expense',38,'create','192',NULL,'2021-09-29 19:29:28','---\nid:\n- \n- 38\nexpense:\n- \n- 20.22\ncomment:\n- \n- Brooklyn\ncreated_at:\n- \n- 2021-09-22 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-29 19:29:28.000000000 +05:00\n'),(418,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.2745e4\nid: 2\ntitle: Adeel Card\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-29 19:29:28.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-29 19:30:43','---\namount:\n- !ruby/object:BigDecimal 18:-0.2745e4\n- !ruby/object:BigDecimal 18:-0.2827e4\nupdated_at:\n- 2021-09-29 19:29:28.000000000 +05:00\n- 2021-09-29 19:30:43.000000000 +05:00\n'),(419,'Payment',45,'update','192','---\nid: 45\ndebit: !ruby/object:BigDecimal 18:0.82e2\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 39\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-29 19:30:43.000000000 +05:00\nupdated_at: 2021-09-29 19:30:43.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-29 19:30:43','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2827e4\n'),(420,'Payment',45,'create','192',NULL,'2021-09-29 19:30:43','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2827e4\n'),(421,'ExpenseEntry',39,'create','192',NULL,'2021-09-29 19:30:43','---\nid:\n- \n- 39\namount:\n- \n- 82.0\nexpense_id:\n- \n- 39\nexpense_type_id:\n- \n- 3\naccount_id:\n- \n- 2\ncomment:\n- \n- Gas\ncreated_at:\n- \n- 2021-09-29 19:30:43.000000000 +05:00\nupdated_at:\n- \n- 2021-09-29 19:30:43.000000000 +05:00\n'),(422,'Expense',39,'create','192',NULL,'2021-09-29 19:30:43','---\nid:\n- \n- 39\nexpense:\n- \n- 82.0\ncomment:\n- \n- Adeel\ncreated_at:\n- \n- 2021-09-25 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-29 19:30:43.000000000 +05:00\n'),(423,'Account',2,'update','192','---\namount: !ruby/object:BigDecimal 18:-0.2827e4\nid: 2\ntitle: Adeel Card\nbank_name: American Express\niban_number: \'\'\ncreated_at: 2021-09-14 22:45:51.000000000 +05:00\nupdated_at: 2021-09-29 19:30:43.000000000 +05:00\ncomment: \nuser_id: 194\n','2021-09-29 19:31:24','---\namount:\n- !ruby/object:BigDecimal 18:-0.2827e4\n- !ruby/object:BigDecimal 18:-0.2843e4\nupdated_at:\n- 2021-09-29 19:30:43.000000000 +05:00\n- 2021-09-29 19:31:24.000000000 +05:00\n'),(424,'Payment',46,'update','192','---\nid: 46\ndebit: !ruby/object:BigDecimal 18:0.16e2\ncredit: \naccount_id: 2\npaymentable_type: ExpenseEntry\npaymentable_id: 40\namount: \nstatus: \ncomment: Expense\ncreated_at: 2021-09-29 19:31:24.000000000 +05:00\nupdated_at: 2021-09-29 19:31:24.000000000 +05:00\nconfirmable: \nconfirmed_by: \nconfirmed_at: \n','2021-09-29 19:31:24','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2843e4\n'),(425,'Payment',46,'create','192',NULL,'2021-09-29 19:31:24','---\namount:\n- \n- !ruby/object:BigDecimal 18:-0.2843e4\n'),(426,'ExpenseEntry',40,'create','192',NULL,'2021-09-29 19:31:24','---\nid:\n- \n- 40\namount:\n- \n- 16.38\nexpense_id:\n- \n- 40\nexpense_type_id:\n- \n- 2\naccount_id:\n- \n- 2\ncomment:\n- \n- Breakfast\ncreated_at:\n- \n- 2021-09-29 19:31:24.000000000 +05:00\nupdated_at:\n- \n- 2021-09-29 19:31:24.000000000 +05:00\n'),(427,'Expense',40,'create','192',NULL,'2021-09-29 19:31:24','---\nid:\n- \n- 40\nexpense:\n- \n- 16.38\ncomment:\n- \n- Brooklyn\ncreated_at:\n- \n- 2021-09-25 00:00:00.000000000 +05:00\nupdated_at:\n- \n- 2021-09-29 19:31:24.000000000 +05:00\n');
/*!40000 ALTER TABLE `versions` ENABLE KEYS */;

--
-- Table structure for table `warranties`
--

DROP TABLE IF EXISTS `warranties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warranties` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `serial_number` text COLLATE utf8mb4_unicode_ci,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `product_id` bigint(20) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_warranties_on_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warranties`
--

/*!40000 ALTER TABLE `warranties` DISABLE KEYS */;
/*!40000 ALTER TABLE `warranties` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-01 23:41:58
